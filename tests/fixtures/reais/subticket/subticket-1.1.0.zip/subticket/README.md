# Plugin Subticket para GLPI 11

Autor: **Manus AI**  
Versão inicial: **0.1.0**  
Compatibilidade alvo: **GLPI 11**

## Visão geral

O **Subticket** é um plugin para GLPI 11 criado para tornar mais prática a criação de chamados vinculados a um chamado principal. A proposta é adicionar um botão **Subticket** na área de ações do chamado, inspirado no comportamento de plugins como o Escalade, evitando que o usuário precise navegar manualmente até a área nativa de tickets relacionados do GLPI.

O plugin oferece dois fluxos principais. O primeiro cria um **ticket relacionado**, copiando as principais informações do chamado de origem e permitindo alterar o requerente. O segundo cria um **subticket**, no qual o usuário escolhe quais informações deseja copiar do chamado principal, como título, descrição, requerente e categoria. Os campos não copiados são apresentados para preenchimento no modal antes da criação do novo chamado.

> O GLPI já possui relacionamento nativo entre tickets; este plugin não substitui esse recurso. Ele apenas cria uma camada de interface e automação para tornar o relacionamento de chamados mais rápido e menos sujeito a erro operacional.

## Funcionalidades implementadas

| Funcionalidade | Situação | Observação |
|---|---:|---|
| Botão **Subticket** na tela do chamado | Implementado | Inserido por JavaScript na tela `ticket.form.php`. |
| Modal para escolher **ticket relacionado** ou **subticket** | Implementado | Usa Bootstrap já disponível no GLPI. |
| Cópia de título, descrição, requerente e categoria | Implementado | O subticket permite selecionar campo a campo. |
| Alteração de requerente no ticket relacionado | Implementado | A versão inicial usa campo de ID do requerente. |
| Criação de vínculo nativo entre tickets | Implementado | Usa `Ticket_Ticket`, mantendo compatibilidade com o GLPI. |
| Fechamento automático quando o principal é fechado/solucionado | Implementado | Controlado por metadado próprio em `glpi_plugin_subticket_links`. |
| Cópia opcional de documentos | Implementado | Configurável por padrão na tela administrativa. |
| Tela administrativa de configuração | Implementado | Disponível em Administração, conforme permissões de configuração. |

## Instalação

Copie a pasta `subticket` para o diretório `plugins/` da sua instalação GLPI. O caminho final deve ficar exatamente assim:

```bash
/path/to/glpi/plugins/subticket
```

Depois, acesse a interface web do GLPI com um usuário administrador, vá até **Configurar > Plugins**, localize **Subticket**, instale e ative o plugin. A instalação cria as tabelas `glpi_plugin_subticket_configs` e `glpi_plugin_subticket_links`, usadas respectivamente para configuração e para armazenar metadados de fechamento automático.

Em ambientes de produção, recomenda-se validar primeiro em uma cópia de desenvolvimento ou homologação do GLPI, especialmente porque o plugin adiciona comportamento de criação e atualização de chamados.

## Uso

Abra um chamado existente no GLPI. Se o usuário possuir permissões de criação e atualização de chamados, o botão **Subticket** será exibido na barra/área de ações. Ao clicar, o plugin abrirá um modal com duas opções.

| Modo | Comportamento |
|---|---|
| **Ticket relacionado** | Copia os principais campos do chamado principal, permite alterar título, descrição, categoria e requerente, e cria um vínculo nativo de ticket relacionado. |
| **Subticket** | Exibe checkboxes para escolher quais campos serão copiados. Campos não selecionados ficam disponíveis para preenchimento manual. |

A opção **Fechar automaticamente quando o chamado principal for fechado/solucionado** faz com que o chamado criado pelo plugin receba o mesmo status de fechamento ou solução quando o chamado principal for atualizado para esse estado.

## Campos copiados

| Campo | Nome técnico no GLPI | Copiado no ticket relacionado | Selecionável no subticket |
|---|---|---:|---:|
| Título | `name` | Sim | Sim |
| Descrição | `content` | Sim | Sim |
| Requerente | `Ticket_User` / `_users_id_requester` | Sim, com troca permitida | Sim |
| Categoria | `itilcategories_id` | Sim | Sim |
| Tipo | `type` | Sim | Sim |
| Urgência | `urgency` | Sim | Sim |
| Impacto | `impact` | Sim | Sim |
| Prioridade | `priority` | Sim | Sim |
| Documentos | `Document_Item` | Opcional | Opcional |

## Arquitetura

A estrutura do plugin segue o padrão convencional de plugins GLPI: `setup.php` registra metadados e hooks, `hook.php` instala/desinstala tabelas, `inc/` concentra as classes de negócio, `ajax/` fornece o endpoint assíncrono e `public/` contém JavaScript e CSS. O GLPI documenta que hooks de plugin são registrados no array global `$PLUGIN_HOOKS`, e a implementação segue esse padrão.[1]

| Arquivo | Responsabilidade |
|---|---|
| `setup.php` | Metadados, compatibilidade, CSS/JS e hook `item_update`. |
| `hook.php` | Instalação, desinstalação e encaminhamento de atualização de ticket. |
| `inc/ticket.class.php` | Criação de tickets relacionados/subtickets e fechamento automático. |
| `inc/config.class.php` | Configuração administrativa e persistência de defaults. |
| `ajax/ticket.php` | Endpoint JSON usado pelo modal. |
| `public/js/subticket.js.php` | Botão, modal e submissão AJAX. |
| `public/css/subticket.css` | Ajustes visuais. |

## Observações importantes

A versão inicial evita alterar arquivos core do GLPI e usa apenas classes nativas do próprio sistema. A posição exata do botão pode variar conforme tema, customizações e outros plugins instalados; por isso, o JavaScript usa uma sequência de seletores com fallback para tentar posicionar o botão em uma área coerente da tela do chamado.

O campo de troca de requerente está implementado como **ID do usuário** para manter a primeira versão independente de componentes avançados de autocomplete do GLPI. Uma melhoria recomendada para a próxima iteração é substituir esse campo por um dropdown/autocomplete nativo de usuários do GLPI, mantendo a mesma lógica de backend.

## Validação local realizada

Os arquivos PHP do plugin foram validados com `php -l` em PHP CLI 8.1 no ambiente de desenvolvimento, sem erros de sintaxe. A validação funcional completa deve ser realizada em uma instância GLPI 11 real, pois ela depende do banco de dados, permissões, tema ativo e versão exata dos componentes JavaScript do GLPI.

## Referências

[1]: https://glpi-developer-documentation.readthedocs.io/en/master/plugins/hooks.html "Hooks - GLPI Developer Documentation"
