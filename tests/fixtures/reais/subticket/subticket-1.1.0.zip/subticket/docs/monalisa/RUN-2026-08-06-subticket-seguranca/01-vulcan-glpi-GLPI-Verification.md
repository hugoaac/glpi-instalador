# GLPI-Verification — subticket 1.1.0 (release de segurança)

| | |
|---|---|
| **Plugin** | subticket |
| **Versão** | 1.0.0 → **1.1.0** |
| **Alvo** | GLPI 11.0.8 (produção TCM-SP). `requirements.glpi.min` continua `11.0.0` |
| **Branch** | `fix/autorizacao-e-vazamentos` — commits locais em 3 levas, **sem push** (`git log --oneline main..HEAD`) |
| **Base** | `737d919 auto: Claude 2026-08-06 16:37` |
| **Data** | 2026-08-06; revisado em 2026-08-07 (busca sob demanda, depois revisão do `@sable-security`) |

Nenhuma migration, nenhuma tabela nova, nenhum campo novo. É release de código puro.
O bump de versão **exige clicar em Atualizar na tela de Plugins** após o deploy — é também o
que invalida o cache de CSS/JS, que usa a versão do `setup.php` no `?v=`.

> **Terceira leva — 2026-08-07, pós-revisão independente.** O `@sable-security` revisou o lote
> e deu **GO COM CONDIÇÕES**, provando por HTTP que a remoção do `checkCSRF` manual do `create`
> estava certa (POST sem token → 403 pelo listener do core nos dois ramos). Achou também um
> endpoint que a auditoria original de 14 itens deixou passar — e que **contradiz** o que ela
> afirmou: ela dizia que "os métodos irmãos já checam `can()`", e
> `checkParentCloseabilityForChild()` **não checava**. Corrigido como **item 8**, junto com o
> comentário falso do `sanitizeFieldValue` (**item 9**) e um reforço de CSRF (**item 10**).
> Versão continua `1.1.0`.

> **Revisão de 2026-08-07 (segunda leva, mesma release).** O item 4 fechou o vazamento mas
> levou junto a busca por login/matrícula no autocomplete de requerente, deixando o plugin
> **mais restritivo que o core** sem ganho proporcional. A raiz não era o campo `login`, era o
> **formato de entrega**. Foi trocado o dump por **busca sob demanda** (`search_users`), o que
> devolve login e matrícula como critério de busca e ainda reduz o payload da página.
> As mudanças estão marcadas como **item 4b** ao longo do documento. Versão continua `1.1.0`.

---

## 1. O que mudou, por arquivo:linha

Linhas referem-se ao estado **final** dos arquivos.

### `inc/ticket.class.php`

| Linha | Mudança | Item |
|---|---|---|
| 15 | `BYPASS_WAITING_TTL = 300` — nova constante | 2 |
| 18, 21 | `USER_SEARCH_MIN_CHARS = 2`, `USER_SEARCH_LIMIT = 20` — novas constantes, fonte única compartilhada com o JS | 4b |
| 33 | `getCopyableFields()`: **`entities_id` removido da lista** | 5 |
| 126 | **`searchUsers()`** — novo. Exige `ticket` CREATE; delega para `User::getSqlSearchResult(right='all')`; pede `LIMIT+1` só para detectar truncamento | 4b |
| 214 | `createFromInput()`: `can($source_id, READ)` → **`can($source_id, UPDATE)`** | 1 |
| 225 | `createFromInput()`: chamada nova a `validateFieldScope()` | 5 |
| 309-312 | `buildTicketFields()`: `entities_id` atribuído **incondicionalmente** a partir do chamado de origem (era `if (!isset(...))`) | 5 |
| 339 | **`validateFieldScope()`** — novo. Valida `itilcategories_id`, `locations_id`, `requesttypes_id`, `type` e `_users_id_requester` | 5 |
| 410 | **`isRequesterAllowed()`** — novo. Ativo, não deletado, dentro da janela `begin_date`/`end_date`, com perfil na entidade de destino | 5 |
| 509 | `sanitizeFieldValue()`: `entities_id` fora da lista de casts (resíduo) | 5 |
| 513-529 | `sanitizeFieldValue()`: **comentário falso corrigido** — o GLPI **não** sanitiza em `Ticket::add()` | 9 |
| 968-985 | `getParentAutoCloseIssues()`: aviso no docblock de que **não autoriza nada**. Comportamento inalterado | 8 |
| 1036 | **`armBypassWaiting()`** — novo. Exige `can(UPDATE)` + pai real com pendências | 2 |
| 1078 | **`consumeBypassWaiting()`** — novo. Uso único, casado com o chamado, TTL 300 s, limpa o formato legado (`bool`) | 2 |
| 1131-1146 | `checkParentCloseabilityForChild()`: exige **`can($tickets_id, READ)` no filho**; `parent_id` **removido da resposta** | 8 |
| 1264 | `handleFollowupAdd()`: `$DB->update('glpi_tickets', ...)` cru → `$parent_after->update([...])` com `_disablenotif` e guard `auto_closing` | 7 |
| 1301 | **`getParentScopeCriteria()`** — novo. Entidade + `Ticket::buildCanViewCondition()` sobre o alias `sbt_parent` | 3 |
| 1343 | `getSubticketStatusMap()`: `INNER JOIN glpi_tickets AS sbt_parent` + critérios de recorte no `WHERE` | 3 |
| 1491 | `handleTicketUpdate()`: `consumeBypassWaiting()` como **primeira instrução**, antes de todos os early returns | 2 |
| (removido) | O bloco antigo `!empty($_SESSION[...]['bypass_waiting'])` + `unset`, que ficava depois do guard `auto_closing` | 2 |

### `ajax/ticket.php`

| Linha | Mudança | Item |
|---|---|---|
| 7-10 | `use Glpi\Error\ErrorHandler` e `use Glpi\Exception\Http\HttpExceptionInterface` | 2, 6 |
| 33-43 | `check_parent_issues`: comentário documentando onde vive o portão (dentro do método, não aqui) | 8 |
| 40-49 | **`search_users`** — nova action. GET, sem CSRF manual | 4b |
| 59-71 | `set_bypass_waiting`: **exige POST**, exige `tickets_id`, delega para `armBypassWaiting()` | 2 |
| 91-100 | `create`: `Session::checkCSRF($_REQUEST)` manual **removido** | extra |
| 105-129 | `catch` final: mensagem genérica para não-HTTP; detalhe via `ErrorHandler::logCaughtException()` com fallback `Toolbox::logInFile('php-errors', ...)` | 6 |

### `public/js/subticket.js.php`

| Linha | Mudança | Item |
|---|---|---|
| 75-93 | **Dump de usuários REMOVIDO.** No lugar, só `$current_user_name` (o `users.find()` de `refreshMode` precisava dele). A primeira leva tinha trocado a query por `User::getSqlSearchResult`; agora a lista não é mais serializada de forma alguma | 4 → 4b |
| 137-147 | 5 labels novos: hint, carregando, vazio, erro, truncado | 4b |
| 161, 167-169 | `const currentUserName`, `const userSearchMinChars` (renderizada da constante PHP), `const userSearchDebounceMs = 300`. **`const users` removida** | 4b |
| 555-676 | `initRequesterAutocomplete()` reescrito: debounce, mínimo de caracteres, `renderMessage()` para os estados, `loginHint` de volta, aviso de truncamento, descarte de resposta fora de ordem | 4b |
| 726-733 | `fillFromSource()`: usa `ticket.requesters[].name` em vez de `users.find()` | 4b |
| 766-769 | `refreshMode()` (subticket): usa `currentUserName` em vez de `users.find()` | 4b |
| 776-780 | `refreshMode()` (relacionado): usa `firstReq.name` em vez de `users.find()` | 4b |
| 946-970 | `set_bypass_waiting`: GET → **POST com `tickets_id`**, via `fetchJSON` (que já injeta `X-Requested-With` e `X-Glpi-Csrf-Token`); `.finally()` → `.catch().then()` | 2 |
| 1005-1007 | `set_bypass_waiting`: `_glpi_csrf_token` passa a ir **também no corpo**, não só no header | 10 |

### `setup.php`

| Linha | Mudança |
|---|---|
| 25-29 | `PLUGIN_SUBTICKET_VERSION` `1.0.0` → `1.1.0` + comentário |

---

## 2. Decisões nos pontos ambíguos

**Recorte do badge = recorte do modal, não o mais estreito possível.** O item 3 pedia que o
recorte coincidisse com o do quadro. Apliquei entidade + visibilidade **ao chamado PAI**
(o card que recebe o badge), **não aos filhos**. Motivo: `getChildrenForParent()` — que o modal
usa — checa `can($parent_id, READ)` no pai e depois lista **todos** os filhos sem filtro. Filtrar
os filhos faria a contagem do badge divergir da lista do modal (badge "3", modal mostra 1).
Filtrando só o pai, as duas concordam. Medido, não suposto: seção 4.

**`is_deleted` não é filtrado no recorte.** `can(READ)` e `getChildrenForParent()` também não
filtram. Filtrar aqui faria o badge sumir na visão de lixeira enquanto o modal continuaria
abrindo — inconsistência nova em troca de nada.

**`getSourcePayload()` continua em `can(READ)`.** É leitura de dados que o usuário já vê no
próprio chamado. O portão está na escrita (`createFromInput`), que é onde a mutação acontece.

**`isRequesterAllowed()` em vez de `User::isValidUserForEntity()`.** A API do core faz exatamente
isto (`glpi/src/User.php:4360`), mas **só existe a partir do 11.0.8**. O plugin declara
`min => 11.0.0`; chamá-la daria fatal em 11.0.0–11.0.7. Não é hipótese: o container de
desenvolvimento local roda **11.0.7** e o smoke test deu
`UndefinedMethodError: isValidUserForEntity`. Reimplementei as mesmas condições com query
própria. Se um dia o `min` subir para 11.0.8, o helper pode virar um alias.

**`_disablenotif` no restore para WAITING (item 7).** O `$DB->update()` cru não disparava
notificação nenhuma. Trocar pelo ORM sem `_disablenotif` passaria a mandar e-mail de "status
alterado" toda vez que um comentário espelhado tirasse o pai de Pendente e o plugin o
devolvesse — ruído novo criado por uma correção de histórico. Com `_disablenotif`, ganhamos
`date_mod` + `Log::history` (o objetivo) sem ganhar o e-mail. `_disablenotif` é lido em
`Ticket::post_updateItem()` (`glpi/src/Ticket.php:1521`).

**Item 8 — checar o filho, NÃO o pai, e cortar o `parent_id`.** Era a pergunta de desenho.
Minha resposta, com o raciocínio à mostra:

*O portão certo é o filho.* `can($tickets_id, READ)` no filho já mata a primitiva de
enumeração: sem ele, um id arbitrário virava um oráculo sobre chamados de qualquer entidade.
Com ele, a consulta fica presa a um chamado que a pessoa já enxerga.

*Checar o pai eu recomendo NÃO fazer*, por três motivos, em ordem de peso:

1. **A informação já vaza pelo caminho legítimo, sem checagem nenhuma.** Quando o técnico
   soluciona o filho, `handleTicketUpdate()` dispara
   `Session::addMessageAfterRedirect(sprintf('Chamado PAI #%d não foi fechado automaticamente: %s', $parent_id, implode('; ', $issues)))`
   — id do pai **e** lista de pendências, para o mesmo usuário, sem `can()`. Barrar no
   pré-check e manter na mensagem pós-ação seria teatro: mudaria o momento, não o alcance.
   Se você quiser fechar de verdade, o lugar é **lá**, e aí é mudança de comportamento de um
   dos três fluxos — território do `@nestor-itil`, não deste lote.
2. **Pela premissa do próprio produto, o pai já autorizou.** `auto_close_parent = 1` é,
   segundo a decisão do Hugo, o dono do pai autorizando explicitamente esse acoplamento. Um
   pai que optou por ser fechado por este filho não tem por que esconder do técnico do filho
   *por que* não fechou.
3. **Quebraria o aviso justo quando ele serve.** O caso de uso é o técnico que trabalha o
   filho e não tem acesso ao pai. Sem o aviso, ele soluciona e nunca descobre que o pai ficou
   para trás — que é exatamente o problema que esse modal existe para evitar.

*Degradação que apliquei no lugar:* **`parent_id` saiu da resposta.** Verifiquei por `grep`
que o cliente **nunca** o consumiu — o modal lê só `has_issues` e `issues`
(`subticket.js.php:927,936,948`). Devolvê-lo era entregar um identificador de objeto de outra
entidade a troco de zero UX. As pendências continuam vindo porque sem elas o aviso não
informa nada acionável.

Efeito colateral verificado: `armBypassWaiting()` também chama esse método, mas já exige
`can(UPDATE)` no mesmo chamado antes — o READ novo é redundante ali, não restritivo.
Caso patológico: perfil com UPDATE e **sem** nenhum direito de leitura em `ticket` passaria no
UPDATE e falharia no READ, e o botão "Solucionar mesmo assim" não armaria. É falha fechada, e
esse perfil não conseguiria abrir o chamado na tela para começo de conversa.

**Item 10 — token no corpo além do header.** O `@sable-security` está certo e vale mandar. O
`CheckCsrfListener` escolhe onde procurar pelo `X-Requested-With`: **com** o header lê
`HTTP_X_GLPI_CSRF_TOKEN` (`preserve_token: true`); **sem** ele cai em
`$request->request->all()`, o corpo do POST. Um WAF que normalize headers joga a requisição no
segundo ramo, onde hoje não havia token → 403. Falha fechada, não abre nada — mas **quebra o
botão "Solucionar mesmo assim" em produção**, e este cliente já teve o F5 interferindo neste
plugin uma vez. O `create` **já** mandava o token no corpo (campo oculto do formulário), então
o `set_bypass_waiting` era o único fora do padrão; isto uniformiza.
Custo do ramo de fallback: `preserve_token: false` **consome** o token. Irrelevante aqui,
porque a ação seguinte é o envio do formulário e a página navega.

**`search_users` é GET (item 4b).** Coerente com as outras leituras do mesmo arquivo
(`list_statuses`, `get_children`): é idempotente, não muta nada, e a resposta é JSON — que
`<img>`/`<script>` de outra origem **não conseguem ler**, e `fetch`/XHR cross-origin esbarra
em CORS. Diferente do `set_bypass_waiting`, que **mutava a sessão** e por isso precisou virar
POST. Sem `Session::checkCSRF()` manual (o listener não valida métodos sem corpo mesmo, e
chamar manualmente reintroduziria o defeito do token queimado). URL curta por causa do WAF:
só `action` e `q`, com o termo em `encodeURIComponent`.

**O endpoint de busca não é portão de autorização.** Ele exige `ticket` CREATE — a mesma
condição que a guarda do JS já impunha — mas quem decide se um `requester_id` pode ser
**gravado** continua sendo `isRequesterAllowed()`, chamado por `validateFieldScope()` no
caminho de criação. Um cliente forjado pode mandar qualquer id sem nunca tocar em
`search_users`; é lá que ele é barrado, não aqui.

**Dois defeitos pré-existentes do autocomplete, corrigidos de passagem (4b).** Não estavam na
lista, mas o código foi reescrito em cima deles e deixá-los seria negligência:
1. **Id fantasma.** Escolher "João" e depois editar o texto para "Maria" mantinha o id do João
   no `hidden` — o chamado saía com um requerente diferente do que estava escrito na tela.
   Agora digitar invalida a seleção (`$hidden.val(0)` no `input`).
2. **Resposta em voo reabria o dropdown** depois de `blur` ou de escolher alguém.
   `closeDropdown()` agora incrementa a sequência de busca, invalidando o que estiver em voo.
   Esse eu introduzi com o AJAX e peguei antes de commitar.

**`Session::checkCSRF()` manual removido do `create`.** Não estava na lista numerada, mas é o
mesmo defeito de raiz do item 2 e está no mesmo bloco. O `CheckCsrfListener` do core já validou
o token com `preserve_token: true`; a segunda chamada usa `preserve_token: false` e **apaga** o
token da sessão (`Session::validateCSRF()`), fazendo o segundo envio do modal falhar até um F5.
Não há perda de proteção — o listener roda sempre, antes do arquivo
(`glpi/src/Glpi/Kernel/Listener/ControllerListener/CheckCsrfListener.php`).

---

## 3. Proposta que NÃO implementei (aguarda decisão do Hugo)

**`auto_close_parent` exigir `canSolve()` além de `can(UPDATE)`.**

Recomendação: **não implementar.** A decisão declarada é que marcar a caixa já é a autorização,
e com `can(UPDATE)` no lugar de `can(READ)` quem marca já é obrigatoriamente alguém que pode
alterar o chamado pai. Exigir `canSolve()` adicionaria um segundo portão que:

- só morde perfis que podem atualizar mas não solucionar (raro no TCM);
- falharia **na criação**, não no fechamento, dando erro num momento em que o usuário não
  entende o motivo;
- não fecha buraco nenhum que o `can(UPDATE)` já não feche — o fechamento automático acontece
  depois, disparado por quem soluciona o **filho**, e essa pessoa passa por `can(UPDATE)` no
  filho de qualquer forma.

Se você discordar, o ponto de enxerto é `inc/ticket.class.php:137`, logo antes de
`validateFieldScope()`, condicionado a `self::boolFromInput($input, 'auto_close_parent')`.

---

## 4. O que foi testado (e onde)

**Ambiente:** container `glpi_app`, **GLPI 11.0.7**, `/var/www/glpi/plugins` é bind mount de
`OneDrive\GLPI\glpi\glpi11\plugins\` — ou seja, o código editado já é o código que roda ali.
`opcache.validate_timestamps = On`, `revalidate_freq = 2` **neste container**, então PHP novo
entra em ~2 s sem restart. Em ambiente com `validate_timestamps=0` (produção), **restart é
obrigatório**.

Tudo abaixo foi executado por CLI, somente `SELECT`. Nenhuma escrita no banco.

### 4.1 Sintaxe

`php -l` (via WSL, PHP 8.x) em `setup.php`, `hook.php`, `ajax/ticket.php`,
`inc/ticket.class.php`, `inc/config.class.php`, `front/config.form.php`,
`public/js/subticket.js.php`, `public/js/subticket-list.js.php` — **8/8 sem erro**.
Não existe `php` no Windows do Hugo; usei o do WSL.

### 4.2 APIs do core que o código novo usa — existem em 11.0.7

```
Ticket::buildCanViewCondition             existe
Ticket::canUpdateItem                     existe
Session::haveAccessToEntity               existe
User::getSqlSearchResult                  existe
User::isValidUserForEntity                AUSENTE   ← por isso isRequesterAllowed()
Glpi\Error\ErrorHandler::logCaughtException  existe
Toolbox::logInFile                        existe
Glpi\Exception\Http\HttpExceptionInterface   existe
Ticket::INCIDENT_TYPE / DEMAND_TYPE       existe
```

### 4.3 SQL do item 3 — gerado e executado

O `INNER JOIN glpi_tickets AS sbt_parent` sai corretamente aliasado e o MySQL aceita a query
nas duas variantes (com e sem `READALL`). Trecho gerado no caso restrito:

```sql
... INNER JOIN `glpi_tickets` AS `sbt_parent`
      ON (`sbt_parent`.`id` = `glpi_plugin_subticket_links`.`tickets_id_parent`)
WHERE ... AND ((`sbt_parent`.`entities_id` IN ('0')))
      AND (0 = 1 OR `sbt_parent`.`id` IN (SELECT `tickets_id` FROM `glpi_tickets_users` ...)
                OR `sbt_parent`.`id` IN (SELECT `id` FROM `glpi_tickets` WHERE `users_id_recipient` = '2')
                OR `sbt_parent`.`id` IN (SELECT `tickets_id` FROM `glpi_groups_tickets` ...) )
```

### 4.4 Item 3 — regressão de badge, medida em dados reais

Base local: **111 chamados pai distintos** em `glpi_plugin_subticket_links` (112 vínculos).

Perfis **com** `READALL` (Analista, Admin, Gestor — todos os perfis da base local):

| usuário | badges ANTES | badges DEPOIS | perdidos |
|---|---|---|---|
| 2 (Analista) | 110 | 110 | **0** |
| 7 (Admin) | 110 | 110 | **0** |
| 8 (Analista) | 110 | 110 | **0** |
| 9 (Gestor) | 110 | 110 | **0** |

Perfis **sem** `READALL` (simulados removendo o bit, mantendo READMY+READGROUP+READASSIGN),
comparando o conjunto do badge com o conjunto que `can($id, READ)` aceita — que é o portão do
modal:

| usuário | grupos | badge | `can(READ)` | badge sem modal | modal sem badge |
|---|---|---|---|---|---|
| 9 | 4,15,16,19,21 | 2 | 2 | **0** | **0** |
| 8 | 2,15,16,19 | 2 | 2 | **0** | **0** |
| 7 | 2,15,16,19 | 2 | 2 | **0** | **0** |

A invariante que importa vale: **badge ⟺ modal**. Nenhum badge aparece que o modal recusaria,
nenhum chamado que o modal aceita perdeu o badge.

Fail-closed conferido: `getLinkStatusMaps()` com sessão vazia devolve `0/0`; com ids
inexistentes devolve `0/0`.

### 4.5 Item 5 — `validateFieldScope()`

| caso | resultado |
|---|---|
| campos vazios | aceita |
| categoria válida | aceita |
| categoria inexistente (999999) | **nega** — "Categoria inválida ou fora das entidades permitidas." |
| localização válida | aceita |
| localização inexistente | **nega** |
| origem ativa | aceita |
| origem inexistente | **nega** |
| `type=1` / `type=2` | aceita |
| `type=99` | **nega** |
| requerente existente | aceita |
| requerente inexistente (999999) | **nega** |

### 4.6 Item 2 — `consumeBypassWaiting()`

| caso | retorno | flag após |
|---|---|---|
| armada para 42, consultada com 7 | `false` | **permanece** (é de outro chamado) |
| armada para 42, consultada com 42 | `true` | **removida** |
| segunda chamada com 42 | `false` | — (uso único confirmado) |
| armada há 1 h, consultada com 42 | `false` | **removida** (TTL) |
| formato legado (`true` booleano) | `false` | **removida** |

### 4.7 Item 4 — lista de usuários (primeira leva, hoje superada pelo 4b)

Base local (entidade única): 5833 usuários no dump antigo → 5832 no novo. A diferença é o
usuário de sistema, que `getSqlSearchResult()` exclui. JSON válido, sem campo `login`,
**271.771 bytes**. Em instância multientidade a redução seria real — não pôde ser medida aqui.

### 4.8 Item 4b — busca sob demanda

**Comportamento** (usuário 2 / perfil Analista, e repetido com usuário 9 / perfil Gestor):

| caso | termo | resultado |
|---|---|---|
| termo vazio | `""` | 0 resultados, **0 ms** (nem vai ao banco) |
| 1 caractere | `"a"` | 0 resultados, **0 ms** |
| limiar (2 caracteres) | `"an"` | 20 resultados, `truncated=true`, 87 ms |
| inexistente | `"zzqqxxnaoexiste"` | 0 resultados, 34 ms |
| **login exato** | `"valida.zimbra6"` | **1 resultado** — o usuário certo, 37 ms |
| **login parcial** | `"valid"` | 20 resultados, todos `valida.*`, 43 ms |
| realname | `" - Migração dados legados ZIMBRA 6"` | 1 resultado, 42 ms |
| âncora de prefixo | `"^ana"` | `ana.mlima`, `ana.pimentel`, `analista.teste`… |
| aspas/traços | `"a'--"` | 0 resultados (termo escapado, sem erro de SQL) |

A busca por **login** é o ponto todo da mudança e está provada: `valida.zimbra6` só casa por
`glpi_users.name`, porque o `realname` dele é outro texto.

**Matrícula:** o caminho existe (`getSqlSearchResult` inclui `registration_number` no `LIKE`),
mas **não foi exercido** — nenhum usuário da base local tem esse campo preenchido. É teste de
homologação, não evidência (H12.3).

**Payload:** a resposta de uma busca é **1.331 bytes**. O arquivo `subticket.js.php` renderizado
caiu para **121.538 bytes** — antes carregava, além disso, os 271.771 bytes da lista de
usuários em toda abertura de chamado. Cerca de **um terço** do que era.

**Autorização:** com o bit `ticket` zerado na sessão, `searchUsers()` devolve
`success=false` + "Você não tem permissão para criar chamados."

**JS gerado:** renderizei `subticket.js.php` com sessão simulada e validei com
`node --check` → **sintaticamente válido**. Confirmado no arquivo gerado: `const users` não
existe mais, `search_users` e `currentUserName` presentes, nenhuma ocorrência de `"login"` no
payload da página, `userSearchMinChars = 2`, e os 5 labels novos com acentuação correta.

### 4.9 Terceira leva (itens 8, 9, 10) — evidência **estática apenas**

> ⚠️ **O Docker Desktop caiu no meio desta leva.** Não subi o daemon por conta própria: há
> 10+ containers de outros projetos nele (sistemas360, ticket_bi, audit-log-platform) e
> reiniciá-lo é ação sobre recurso compartilhado que ninguém me pediu. **Nenhum teste de
> execução foi feito para os itens 8, 9 e 10.** O que segue é leitura de código e verificação
> textual — suficiente para revisão, insuficiente para GO sem homologação.

O que **foi** verificado:

| Verificação | Como | Resultado |
|---|---|---|
| `php -l` nos 3 arquivos | WSL (independe do Docker) | limpo |
| `parent_id` tem consumidor no cliente? | `grep -rn "parent_id" public/` | **nenhum** — só `has_issues` e `issues` são lidos |
| Quem chama `checkParentCloseabilityForChild`? | `grep -rn` em `inc/ ajax/ public/` | 2 chamadores: `armBypassWaiting:1049` (já exige `can(UPDATE)` antes) e `ajax/ticket.php:42` (o vulnerável, agora fechado) |
| O `Sanitizer` é chamado no ciclo de add/update? | `grep -rn "Sanitizer::" src/CommonDBTM.php src/CommonITILObject.php src/Ticket.php` | **nenhuma ocorrência** — comentário era falso |
| O `Sanitizer` está vivo? | `grep "@deprecated" src/Glpi/Toolbox/Sanitizer.php` | `@deprecated 11.0.0` em todos os métodos |
| Onde está a proteção real? | leitura | `timeline.html.twig:203` → `\|safe_html` → `RichText::getSafeHtml`, filtro em `DataHelpersExtension:65` |
| JS do item 10 é sintaticamente válido? | apliquei a mesma troca ao `out.js` já renderizado (a edição **não** introduz interpolação PHP nova) e rodei `node --check` | **válido** |

O que **não** foi verificado e virou teste de homologação: o comportamento em execução do
`can(READ)` novo (R-1), e o ramo de fallback do CSRF (H4.2b).

---

## 5. O que NÃO foi testado

- **Nada em 11.0.8.** O container local é 11.0.7. As diferenças relevantes entre as duas foram
  checadas por `method_exists`, não por execução.
- **Nada em multientidade.** A base local tem uma entidade (`entities_id = 0`). Itens 3 e 4
  dependem exatamente disso.
- **Nenhum fluxo pela interface.** Não criei subticket, não solucionei filho, não fechei pai,
  não abri o modal, não cliquei em "Solucionar mesmo assim", **não digitei uma letra no
  autocomplete**. Todo o roteiro da seção 7 está **por executar**.
- **`ajax/ticket.php` não foi exercido por HTTP.** Não validei na prática que o
  `CheckCsrfListener` aceita o POST novo de `set_bypass_waiting` — a inferência vem da leitura
  do listener, não de uma requisição. **É o teste H4 e é o mais importante do roteiro.**
  Vale igual para `search_users`: chamei `searchUsers()` direto por CLI, **não** por HTTP.
- **Busca por matrícula (`registration_number`) não exercida** — o campo está vazio em toda a
  base local. O caminho está no código do core, mas é inferência (H12.3).
- **Comportamento do autocomplete com latência real** (debounce, corrida de respostas, estado
  de carregando) só foi raciocinado, nunca visto. Rede local de container não reproduz o F5.
- **Itens 8, 9 e 10 não têm NENHUM teste de execução.** O Docker Desktop caiu no meio da
  terceira leva e eu não subi o daemon (10+ containers de outros projetos). Só há `php -l`,
  `node --check` sobre o JS spliced, e verificação textual por `grep`. Os blocos **R** e
  **H4.2b/H4.2c** do roteiro cobrem exatamente essa lacuna — são os testes que ninguém rodou.
- **O ramo de fallback do CSRF (sem `X-Requested-With`) nunca foi exercido**, nem antes nem
  depois do item 10. A descrição do mecanismo vem da leitura do `CheckCsrfListener`; quem o
  exercitou por HTTP foi o `@sable-security`, e só no ramo **com** header.
- **`plugin:install` / `plugin:activate` / botão Atualizar** — não executados.
- **Nenhum teste automatizado.** O plugin continua sem `tests/`, sem phpunit, sem CI. Este lote
  não mudou isso.

---

## 6. Riscos de regressão

### 6.1 `READ` → `UPDATE`: quem perde acesso — risco **baixo**, mas confira

`Ticket::canUpdateItem()` (`glpi/src/Ticket.php:613`) aprova quem satisfizer:

1. `checkEntity()` passa (entidade do chamado ∈ entidades ativas) — **e**
2. é requerente/recipient, chamado não solucionado/fechado, **zero** followups e **zero** tasks
   (`canRequesterUpdateItem`, `Ticket.php:642`); **ou**
3. tem `ticket` UPDATE global, **ou** tem `OWN` e é o técnico atribuído (`ownItem`,
   `Ticket.php:657`); e nesse caso ainda passa por
   `haveRightsOr('ticket', [UPDATE, ASSIGN, STEAL, OWN, CHANGEPRIORITY])`.

**Por que o impacto prático tende a zero:** `public/js/subticket.js.php:18-19` já exigia
`Session::haveRight('ticket', CREATE)` **e** `Session::haveRight('ticket', UPDATE)` para sequer
injetar o botão. Quem enxerga o botão hoje já tem UPDATE global e passa no item 3 acima. A
mudança fecha o caminho de API (POST direto em `ajax/ticket.php`), não o caminho da tela.

**O que conferir mesmo assim:**
- Perfil que tenha `ticket` READALL mas **não** UPDATE (tipo "Observador"/"Supervisor"/leitura):
  já não via o botão; confirme que continua não vendo e que nada quebrou.
- Perfil que só tem `OWN` (sem UPDATE global): **nunca viu o botão** por causa da guarda do JS,
  antes e depois. Se alguém no TCM depende disso, é um bug pré-existente — e a correção seria
  afrouxar a guarda do JS, não o `can()`.
- Chamado pai já **fechado**: continua permitindo criar subticket (o item 3 aprova mesmo com
  status SOLVED/CLOSED). Confirme que isso é o desejado.

### 6.2 Badges do Kanban / lista — risco **baixo**, mas é o que dói se estiver errado

Medido em 111 pais e 4 usuários (seção 4.4): zero perda para `READALL`, coincidência exata com
`can(READ)` sem `READALL`. O que não foi medido:

- **Multientidade.** `getEntitiesRestrictCriteria('sbt_parent', 'entities_id', '', false)` usa
  `$_SESSION['glpiactiveentities']`, que já vem com as subentidades materializadas — mesmo
  contrato do operationalkanban (C-1/C-3). O 4º argumento é `false` de propósito:
  `glpi_tickets` **não tem** `is_recursive`. Se algum badge sumir no TCM, é aqui que se olha.
- **`glpishowallentities`.** Com essa flag, `getEntitiesRestrictCriteria` devolve
  `QueryExpression('true')` e o recorte de entidade some — igual ao core. Comportamento
  correto, mas vale ver com um perfil que use "ver todas as entidades".
- **Divergência com o operationalkanban.** O quadro dele também filtra
  `is_deleted = 0` e `status IN (1,2,3,4)`; o badge **não** filtra nenhum dos dois. Isso é
  intencional (o badge também roda na lista nativa de chamados, que mostra solucionados e
  lixeira) e só torna o badge **mais permissivo** que o quadro — nunca menos. Não pode causar
  badge faltando; pode causar badge presente num card que o quadro não mostra, o que é
  irrelevante porque o card não está lá.

### 6.3 `validateFieldScope()` pode recusar criação que antes passava — risco **médio**

É a mudança com maior chance de regressão visível, e vem de um caminho legítimo:

**Cenário:** o usuário marca "copiar categoria" (ou localização), e a categoria do chamado de
**origem** está numa entidade fora das entidades ativas dele. Antes, o valor era copiado sem
pergunta. Agora `Session::haveAccessToEntity()` recusa e a criação inteira falha com
"Categoria inválida ou fora das entidades permitidas."

Isso é raro numa instância de entidade única, mas o TCM pode ter categorias herdadas da migração
10→11 com `entities_id` inesperado. **Teste H7 do roteiro cobre isso.** Se aparecer, a correção
não é remover a validação — é aceitar também categorias recursivas de ancestrais (já aceito) ou
copiar `0` em vez de falhar. Me chame antes de mexer.

Mesmo raciocínio para o requerente: `isRequesterAllowed()` exige perfil na entidade de destino.
Um requerente sem perfil algum (usuário só importado do LDAP, sem `glpi_profiles_users`) passa a
ser recusado. Teste H8.

### 6.4 `date_mod` do chamado pai passa a mudar — risco **baixo**, mas afeta relatório

Item 7: o restore do status para Pendente agora vai pelo ORM, então **atualiza `date_mod` e
grava `Log::history`**. Antes não fazia nem um nem outro. Qualquer relatório ou SLA que use
`glpi_tickets.date_mod` do pai vai ver movimentação onde antes não via. Isso é a correção, não
o efeito colateral — mas o `@kepler-bi` precisa saber se algum indicador do faturamento depende
disso.

### 6.5 Autocomplete de requerente virou AJAX — risco **médio**, é o novo

Resolvido o que a primeira leva quebrou (busca por login), mas o mecanismo mudou de local para
remoto e isso traz riscos próprios:

- **Depende da rede.** Antes a filtragem era instantânea em memória; agora cada busca é uma
  requisição atrás do F5. Latência medida no container: **32–217 ms** por busca. Com o debounce
  de 300 ms, o usuário sente ~0,4 s até a lista aparecer. Se o F5 acrescentar latência
  perceptível, o número a ajustar é `userSearchDebounceMs` (`subticket.js.php:169`).
- **Falha de rede degrada, não trava.** O `catch` mostra "Erro ao buscar usuários. Tente
  novamente." e o modal continua utilizável — mas em modo Subticket o requerente é
  **obrigatório**, então uma falha persistente da busca **impede criar subticket**. Não impede
  criar chamado relacionado (que copia o requerente da origem). Testar em H12.7.
- **Ordenação é alfabética, não por relevância.** Com mais de 20 resultados, o teto mostra os
  20 primeiros por `realname`/`firstname`/`name` — o usuário procurado pode não estar entre
  eles. É por isso que existe o aviso "Muitos resultados — refine a busca". É exatamente o
  comportamento do dropdown nativo, que usa o mesmo backend.
- **`%` funciona como curinga.** `Search::makeTextSearchValue()` escapa `_` e barras invertidas,
  mas **não** escapa `%`. Digitar `a%b` casa "a…b". Não é vulnerabilidade — o LIKE roda dentro
  do recorte de entidade, é comportamento do core e vale para qualquer busca do GLPI. Só não se
  assuste ao ver.
- **Mudança de comportamento deliberada:** digitar depois de ter escolhido alguém **limpa** a
  seleção. Antes o id antigo permanecia (defeito 1 da seção 2). Se um técnico reclamar que
  "sumiu o requerente que eu tinha escolhido", é isto, e está correto.

A classe CSS `.sbt-ac-login` voltou a ser usada — bom não a ter removido.

### 6.6 O que **não** mudou e continua valendo

- `list_statuses` continua **GET sem CSRF**. É leitura, o contrato está em produção validado
  contra o F5, e estava fora de escopo. Agora ao menos está recortado.
- Todo o resto dos achados da auditoria que não estavam nos 7 itens (S-05 DOM XSS em
  `subticket.js.php:648`, S-08 `copyDocuments` sem `can(READ)`, `handleTicketUpdate` com 20
  filhos ≈ 100-200 queries síncronas) **continua aberto**.

---

## 7. Roteiro de teste manual — homologação

Nada aqui foi executado. Faça na ordem; H0 e H1 são pré-requisito dos demais.

**Antes de começar:** copiar o plugin para o ambiente, **reiniciar o PHP/container**
(obrigatório se `opcache.validate_timestamps=0` — sem isso você testa o código antigo),
clicar em **Atualizar** na tela de Plugins e confirmar que aparece **1.1.0**. Depois **Ctrl+F5**
no navegador, senão o JS antigo (com o dump de login) continua em cache.

### H0 — sanidade

| # | Passo | Esperado |
|---|---|---|
| H0.1 | Tela de Plugins | Versão **1.1.0**, plugin ativo, sem erro |
| H0.2 | Abrir um chamado | Botão **Subticket** aparece na barra de ações |
| H0.3 | DevTools → Network → recarregar `ticket.form.php` | `subticket.js.php` HTTP 200, **~120 KB** (era ~390 KB). **Ctrl+F no corpo por `const users` e por `"login"`: nenhuma ocorrência** |
| H0.4 | Abrir a lista de chamados | Badges de subticket aparecem nos mesmos cards de antes |

### H1 — fluxo 1: criação (não pode ter mudado)

| # | Passo | Esperado |
|---|---|---|
| H1.1 | Chamado A → Subticket → tipo **Subticket** → preencher título, requerente, categoria → Criar | Redireciona para o novo chamado B |
| H1.2 | Voltar ao chamado A | Status **Pendente**; followup **público** "Chamado Pausado Automaticamente" com link para B |
| H1.3 | Chamado B | Followup **privado** "criado como subticket do chamado #A"; vínculo nativo com A |
| H1.4 | Entidade de B | **Igual à de A** (mesmo se você forjar `entities_id` — ver H6) |
| H1.5 | Repetir com tipo **Ticket relacionado** | Cria vinculado, **sem** pausar A |
| H1.6 | Marcar "Copiar documentos anexados" | Anexos de A aparecem em B |
| H1.7 | Abrir o modal, cancelar, abrir de novo e **criar** | Funciona no segundo clique **sem F5** (regressão do `checkCSRF` duplicado — antes falhava) |

### H2 — fluxo 2: filho solucionado → pai fechado

| # | Passo | Esperado |
|---|---|---|
| H2.1 | Criar B a partir de A com **"Fechar o chamado de origem automaticamente"** marcado. A precisa ter técnico, grupo, categoria e localização | — |
| H2.2 | Solucionar B | A sai de Pendente e é **solucionado**, com solução mencionando B |
| H2.3 | Repetir com A **sem categoria** | A **não** fecha; aviso "Chamado PAI #A não foi fechado automaticamente: Sem categoria definida" |

### H3 — fluxo 3: pai fechado → filhos fechados

| # | Passo | Esperado |
|---|---|---|
| H3.1 | Criar B a partir de A com **"Fechar este chamado automaticamente"** marcado | — |
| H3.2 | Solucionar A | B é solucionado com solução referenciando A |

### H4 — bypass das travas (o teste mais importante deste lote)

| # | Passo | Esperado |
|---|---|---|
| H4.1 | A **sem localização**; criar B com "fechar o chamado de origem" marcado; solucionar B | Modal "Atenção: Chamado PAI com pendências" listando "Sem localização definida" |
| H4.2 | Clicar **"Solucionar mesmo assim"**. DevTools → Network | Requisição a `ajax/ticket.php` é **POST**, corpo `action=set_bypass_waiting&tickets_id=<B>`, headers `X-Requested-With` e `X-Glpi-Csrf-Token`. Resposta **200 `{"success":true}`** — se vier 4xx com "not allowed", o CSRF quebrou e o lote está **NO-GO** |
| H4.2b | **WAF que normaliza headers.** Repetir o POST de H4.2 **sem** o header `X-Requested-With` (DevTools → Copy as fetch, remover a linha, reenviar). O token vai no corpo desde o item 10 | **200 `{"success":true}`.** Se der **403**, o item 10 não está em vigor (cache de JS antigo?) e o botão "Solucionar mesmo assim" **quebra atrás do F5** |
| H4.2c | Repetir H4.2b **também sem** o `_glpi_csrf_token` no corpo | **403.** Confirma que o token continua sendo exigido — o item 10 adiciona robustez, não afrouxa nada |
| H4.3 | Resultado do H4.2 | B solucionado **e** A fechado apesar da pendência |
| H4.4 | **Flag presa (o bug corrigido).** Repetir H4.1, clicar "Solucionar mesmo assim", **fechar o modal do navegador antes** de o form enviar (ou cancelar). Depois, na **mesma sessão**, solucionar um outro filho C cujo pai D tenha pendências | D **NÃO** pode fechar sozinho — tem que aparecer o aviso das pendências. Antes desta versão, D fechava indevidamente |
| H4.5 | **Bypass forjado por GET.** Colar na barra do navegador, logado: `/plugins/subticket/ajax/ticket.php?action=set_bypass_waiting` | HTTP **400** `Invalid request method.` |
| H4.6 | **Bypass por `<img>`.** Criar um chamado cuja descrição contenha `<img src="/plugins/subticket/ajax/ticket.php?action=set_bypass_waiting">`, abrir com outro técnico e em seguida solucionar um filho com pai pendente | Aviso das pendências aparece normalmente (a flag **não** foi armada) |

### H5 — autorização negada (item 1)

Precisa de um perfil de teste com `ticket` READALL **sem** UPDATE, e de um técnico comum.

| # | Passo | Esperado |
|---|---|---|
| H5.1 | Logar com o perfil sem UPDATE, abrir um chamado | Botão Subticket **não aparece** (guarda do JS, comportamento anterior) |
| H5.2 | Com esse perfil, POST direto em `ajax/ticket.php` com `action=create&tickets_id=<A>&...` (use o DevTools de outra aba logada para pegar o token CSRF) | `{"success":false,"message":"Você não tem permissão para alterar o chamado de origem..."}` e o chamado A **não** vai para Pendente |
| H5.3 | Técnico comum (com UPDATE) que **não** é ator de A | Cria normalmente — `UPDATE` global basta, é a regra do core |

### H6 — injeção de entidade (item 5)

| # | Passo | Esperado |
|---|---|---|
| H6.1 | POST em `ajax/ticket.php` com `action=create`, `tickets_id=<A da entidade X>` e `entities_id=<Y>` | Novo chamado criado na entidade **X** (a de A), nunca em Y |
| H6.2 | Mesmo POST com `itilcategories_id=999999` | `{"success":false,...,"Categoria inválida..."}`, nenhum chamado criado |
| H6.3 | Mesmo POST com `requester_id=999999` | `{"success":false,...,"Requerente inválido..."}` |
| H6.4 | Mesmo POST com `type=99` | `{"success":false,...,"Tipo de chamado inválido."}` |

### H7 — regressão de categoria/localização copiada (risco 6.3)

| # | Passo | Esperado |
|---|---|---|
| H7.1 | Achar um chamado cuja categoria esteja numa entidade diferente da sua (`SELECT t.id, t.entities_id, c.entities_id, c.is_recursive FROM glpi_tickets t JOIN glpi_itilcategories c ON c.id = t.itilcategories_id WHERE c.entities_id <> t.entities_id LIMIT 20`) | — |
| H7.2 | Criar subticket a partir dele marcando "copiar categoria" | **Deve criar normalmente.** Se recusar com "Categoria inválida", é a regressão 6.3 → **anote e me avise, não remova a validação** |
| H7.3 | Mesmo teste com localização | Idem |

### H8 — requerente sem perfil (risco 6.3)

| # | Passo | Esperado |
|---|---|---|
| H8.1 | `SELECT u.id FROM glpi_users u LEFT JOIN glpi_profiles_users pu ON pu.users_id = u.id WHERE pu.id IS NULL AND u.is_active = 1 LIMIT 5` | Lista de usuários sem perfil |
| H8.2 | Tentar criar subticket com um deles como requerente | Recusado ("Requerente inválido"). **Se isso for comum no TCM, é regressão** — anote quantos usuários a query devolveu |

### H9 — recorte de badges (item 3, o que mais dói)

| # | Passo | Esperado |
|---|---|---|
| H9.1 | Com um técnico **restrito** (sem READALL), abrir a lista de chamados e o Kanban | Os badges que ele via antes continuam aparecendo. Compare com um print de antes do deploy, se tiver |
| H9.2 | Clicar em cada badge visível | O modal abre e lista os filhos — **badge sem modal é o defeito a caçar** |
| H9.3 | Em instância **multientidade**: técnico da entidade X | Vê badges de chamados de X e das subentidades de X; **não** vê de Y |
| H9.4 | **Enumeração.** GET `ajax/ticket.php?action=list_statuses&ids=<200 ids de chamados de outra entidade>` | `{"subtickets":{},"related":{}}` — vazio. Antes devolvia contagem e status |
| H9.5 | Perfil com "ver todas as entidades" ligado | Vê todos os badges (comportamento do core, esperado) |

### H10 — erro não vaza SQL (item 6)

| # | Passo | Esperado |
|---|---|---|
| H10.1 | Provocar um erro de banco (ex.: renomear temporariamente `glpi_plugin_subticket_links` em ambiente de homologação **apenas**) e chamar `action=get_children` | Resposta: `{"success":false,"message":"Erro ao processar a solicitação. O detalhe foi registrado no log do GLPI."}` — **sem nenhuma query SQL** |
| H10.2 | Conferir `files/_log/php-errors.log` | O detalhe (classe, mensagem, arquivo, linha) **está lá** |
| H10.3 | `action=inexistente` | HTTP 400, `"Invalid action."` (mensagem controlada, pode aparecer) |

### H11 — item 7: histórico do pai

| # | Passo | Esperado |
|---|---|---|
| H11.1 | Criar B a partir de A com "Espelhar comentários" marcado; A em Pendente | — |
| H11.2 | Comentar em B | Comentário espelhado em A; A **continua Pendente** |
| H11.3 | Aba **Histórico** de A | Aparece o registro da mudança de status (antes **não aparecia** — era `$DB->update()` cru) |
| H11.4 | Caixa de e-mail dos atores de A | **Nenhuma** notificação de "status alterado" pelo restore (`_disablenotif`) |

### H12 — busca de requerente sob demanda (item 4b)

Escolha antes uma **cobaia**: um usuário com `realname` preenchido **e** login diferente do
nome, para que a busca por login prove alguma coisa.
`SELECT id, name AS login, realname, firstname, registration_number FROM glpi_users WHERE is_active=1 AND is_deleted=0 AND realname <> '' LIMIT 10`

| # | Passo | Esperado |
|---|---|---|
| H12.0 | Abrir a modal Subticket. DevTools → Network | **Nenhuma** requisição de usuários ao abrir. `subticket.js.php` **não** contém a lista (Ctrl+F por `const users` → nada) |
| H12.1 | Campo Requerente: digitar **1 caractere** | Nenhuma requisição. Aviso "Digite ao menos 2 caracteres para buscar (nome, login ou matrícula)." |
| H12.2 | Digitar o **login** da cobaia (2+ caracteres) | Uma requisição `GET ...action=search_users&q=...`. A cobaia aparece, com o login entre parênteses ao lado do nome |
| H12.3 | Digitar a **matrícula** de alguém que tenha `registration_number` | O usuário aparece. **Se não aparecer, anote — esse caminho não foi testado por mim** |
| H12.4 | Digitar parte do **nome** (ex.: "silva") | Resultados por nome, como antes |
| H12.5 | Digitar termo muito genérico (ex.: "a") depois "an" | No máximo 20 resultados + linha "Muitos resultados — refine a busca." |
| H12.6 | Digitar algo inexistente ("zzqqxx") | "Nenhum usuário encontrado." — a modal continua utilizável |
| H12.7 | **Falha de rede.** DevTools → Network → Offline; digitar 3 caracteres | "Erro ao buscar usuários. Tente novamente." A modal **não** trava; voltar online e digitar de novo funciona |
| H12.8 | Digitar rápido e apagar rápido várias vezes | Uma requisição por pausa (debounce 300 ms), não uma por tecla. O resultado exibido é o do **último** termo, nunca o de um anterior |
| H12.9 | Escolher um usuário e **depois digitar mais uma letra** | A seleção é limpa (comportamento novo e intencional — ver 6.5). Escolher de novo antes de criar |
| H12.10 | Escolher um usuário, então clicar fora do campo | Dropdown fecha e **não reabre** sozinho |
| H12.11 | **Criar de fato** um subticket com requerente escolhido pela busca | Chamado criado; o requerente do novo chamado é **o escolhido** |
| H12.12 | **Outra entidade.** Instância multientidade: buscar por alguém que só tem perfil em outra entidade | **Não pode aparecer.** Este é o teste que prova que o recorte sobreviveu à troca de mecanismo |
| H12.13 | Chamar direto `/plugins/subticket/ajax/ticket.php?action=search_users&q=a` na barra do navegador | JSON com `users: []` (termo de 1 caractere) |
| H12.14 | Idem com `q=<termo válido>`, logado com um perfil **sem** `ticket` CREATE | `{"success":false,...,"Você não tem permissão para criar chamados."}` |
| H12.15 | Modo **Ticket relacionado** com "copiar requerente" | Requerente da origem preenchido automaticamente, **sem** precisar buscar (vem de `ticket.requesters`) |
| H12.16 | Modo **Subticket** recém-aberto | Requerente pré-preenchido com **você mesmo** (constante `currentUserName`) |

### R — `check_parent_issues` com autorização por objeto (item 8)

**Nada disto foi executado por mim** — o Docker caiu antes. É o bloco com maior lacuna de
evidência do lote.

Prepare antes: um chamado **B** que seja filho com `auto_close_parent = 1` de um pai **A** com
pendências (ex.: A sem localização), e um **usuário de teste** que não enxergue B.
`SELECT tickets_id_child, tickets_id_parent FROM glpi_plugin_subticket_links WHERE auto_close_parent = 1 LIMIT 20`

| # | Passo | Esperado |
|---|---|---|
| R-1 | Logado com o usuário de teste, chamar `GET /plugins/subticket/ajax/ticket.php?action=check_parent_issues&tickets_id=<B que ele NÃO enxerga>` | `{"has_issues":false}` e **nada mais**. Sem `parent_id`, sem lista de pendências |
| R-2 | Repetir com **id de outra entidade**, e com ids varridos em sequência (ex.: 1000 a 1050) | Sempre `{"has_issues":false}`. Nenhum id pode diferenciar "existe e tem pai" de "não existe" |
| R-3 | Chamar com `tickets_id=0`, `-1` e um id inexistente | `{"has_issues":false}`, sem erro 500 |
| R-4 | **Fluxo legítimo não pode ter quebrado.** Logado como o técnico de B, abrir `ticket.form.php?id=<B>` | A requisição `check_parent_issues` retorna `has_issues:true` com a lista de pendências |
| R-5 | Solucionar B a partir dessa tela | O modal "Chamado PAI com pendências" aparece, **listando as pendências** |
| R-6 | Inspecionar a resposta de R-4 no DevTools | **Não pode conter `parent_id`.** Se contiver, o deploy está com código antigo |
| R-7 | Técnico que enxerga B mas **não** enxerga o pai A | O aviso **deve** aparecer normalmente — é a decisão de desenho da seção 2, e quebrar isso é regressão, não segurança |

---

## 8. Dívida registrada, fora deste lote

- **`setup.php:52-66` roda `ALTER TABLE` em toda requisição da instância** (dois
  `fieldExists` + eventual `ALTER`). Pertence ao `plugin_subticket_install()`, não ao
  `plugin_init_subticket()`. Explicitamente fora de escopo neste lote — **registrado**.
- `list_statuses` continua GET (o próprio histórico do plugin já registra que "POST teria sido
  a correção certa": mata chunking, `MAX_STATUS_IDS` e merge parcial de uma vez).
- **Os combos de categoria, localização e origem continuam sendo dump.** O item 4b tratou só a
  lista de usuários, que era de longe a maior. Categorias e localizações já são recortadas por
  entidade e são ordens de grandeza menores, mas em instância grande também mereceriam busca
  sob demanda — hoje as três queries rodam em toda abertura de chamado, mesmo que a modal nunca
  abra. Mesmo motivo do JS-como-PHP abaixo.
- **S-05 (DOM XSS) — próximo lote, com escopo próprio.** `innerHTML = ticket.content` em
  `subticket.js.php` recebe o `content` **cru** do chamado. O comentário que afirmava
  "GLPI sanitiza em `Ticket::add()`" **foi corrigido** no item 9 (era falso: a proteção é de
  saída, `timeline.html.twig:203` com `|safe_html`), mas o **defeito continua aberto** — só a
  desinformação que o escondia é que saiu do caminho.
- **S-08** (`copyDocuments` religa anexo sem `can(READ)`, o que **concede download** via
  `Document::canViewFileFromItilObject`) e o custo de `handleTicketUpdate` com muitos filhos:
  ainda abertos.
- **`handleTicketUpdate()` divulga `parent_id` + pendências do pai sem `can()`**, via
  `Session::addMessageAfterRedirect`. Deixado de propósito (ver decisão do item 8 na seção 2):
  fechar isso é mudar o comportamento de um dos três fluxos e precisa passar pelo
  `@nestor-itil` antes. **Registrado como decisão consciente, não como esquecimento.**
- **JS-como-PHP** (pitfalls §12): `subticket.js.php` continua fazendo um segundo boot completo
  do GLPI em toda visualização de chamado. Os ~270 KB de usuários **saíram** (item 4b), mas o
  boot e as 3 queries de dropdown permanecem. O caminho definitivo é o JS virar estático e as
  variáveis irem por `data-*` ou por um endpoint de configuração.
- `hook.php:37,68` tem charset `utf8mb4` **hardcoded** no `CREATE TABLE`. TCM-SP veio de
  migração 10→11: conferir `SELECT @@collation_database` antes de qualquer install novo.
- Índices de `glpi_plugin_subticket_links` só são criados em **install novo**, sem migration
  retroativa. Rodar `SHOW INDEX FROM glpi_plugin_subticket_links` na produção do TCM.
- O plugin continua **sem nenhum teste automatizado**. Este lote deveria ter sido o gatilho
  para criar `tests/` — não foi, e o roteiro manual acima é o que existe no lugar.

---

## 9. Veredito

**GO COM RESSALVAS.** O código está implementado, lintado (PHP e JS) e com as invariantes de
recorte medidas em dados reais — mas em **11.0.7**, entidade única, e **sem nenhum fluxo
exercido pela interface**. O lote não pode ir para produção antes do roteiro da seção 7.

A terceira leva (itens 8, 9, 10) tem **cobertura de execução zero** — o Docker caiu antes.
Isso não muda o veredito, mas concentra o risco: os blocos **R** e **H4.2b** deixaram de ser
confirmação e passaram a ser descoberta.

Quatro testes derrubam o lote se falharem:

- **H4.2** — o POST de `set_bypass_waiting` passar pelo `CheckCsrfListener`. Se der 4xx com
  "not allowed", o fluxo de "Solucionar mesmo assim" está quebrado.
- **H4.2b** — o mesmo POST **sem** `X-Requested-With` (WAF que normaliza headers). Deve passar
  pelo token no corpo. É o cenário que o F5 do cliente torna plausível.
- **H12.12** — usuário de outra entidade **não** aparecer na busca de requerente. É o que prova
  que o recorte de entidade sobreviveu à troca de dump por AJAX, e é justamente o que a base
  local (entidade única) não conseguiu demonstrar.
- **R-4/R-7** — o aviso de pendências do pai **continuar aparecendo** para o técnico do filho,
  inclusive quando ele não enxerga o pai. Se sumir, o `can(READ)` do item 8 virou regressão de
  fluxo, não correção de segurança.
