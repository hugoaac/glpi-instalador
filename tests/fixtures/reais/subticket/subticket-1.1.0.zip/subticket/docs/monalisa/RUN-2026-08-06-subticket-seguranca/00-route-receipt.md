# Recibo de rota — RUN-2026-08-06-subticket-seguranca

**Acionamento:** direto em `@vulcan-glpi`, sem chief. Recibo obrigatório pelo protocolo MONALISA V6.

## Pedido recebido

Implementar o lote de 7 correções de segurança do plugin **subticket** (GLPI 11, produção no
TCM-SP, atrás de F5), a partir de auditoria já realizada (sable-security + vulcan) e já
verificada no código pelo solicitante. Escopo fechado, sem re-auditoria.

Decisões declaradas como **não reabríveis** no briefing e respeitadas:

- Os três fluxos que mutam o chamado pai (criação → Pendente + followup; filho solucionado →
  pai fechado; pai fechado → filhos fechados) ficam **como estão**. A tarefa era fazer o código
  exigir a premissa de autorização, não mudar comportamento.
- `getParentAutoCloseIssues()` e as 4 travas (sem técnico / sem grupo / sem categoria / sem
  localização) — intocadas.
- `ajax/ticket.php` case `list_statuses` (contrato CSV/`ids[]`, `MAX_STATUS_IDS`) e
  `public/js/subticket-list.js.php` (lógica de lotes) — correção de WAF já em produção,
  intocada. Alterei apenas a função que o endpoint chama.

## Terceira leva — 2026-08-07 (pós-revisão do @sable-security)

Revisão independente deu **GO COM CONDIÇÕES** e achou um endpoint que a auditoria original de
14 itens deixou passar: `check_parent_issues` sem autorização por objeto. **A auditoria original
afirmou que "os métodos irmãos já checam `can()`" — era falso**, e eu repassei a afirmação
adiante no artefato da primeira leva. Corrigido.

Implementado: `can(READ)` no chamado **filho** + remoção do `parent_id` da resposta (item 8);
comentário falso sobre sanitização removido (item 9); token CSRF também no corpo do
`set_bypass_waiting` (item 10). Contestei a sugestão de checar também o **pai** e não a
implementei — justificativa em §2 do artefato e em D-17 do decision log.

**Não verificado nesta leva: absolutamente nada em execução.** O Docker Desktop caiu no meio e
eu não subi o daemon (10+ containers de outros projetos). Só `php -l`, `node --check` sobre o JS
spliced e verificação textual por `grep`. Os blocos **R** (7 casos) e **H4.2b/H4.2c** do roteiro
existem exatamente para cobrir essa lacuna.

## Segunda leva — 2026-08-07 (mesma branch, mesma release)

Aprovada pelo Hugo: **trocar o dump de usuários por busca sob demanda**. O item 4 tinha fechado
o vazamento mas levado junto a busca por login/matrícula, deixando o plugin mais restritivo que
o core. Implementado como **item 4b**: nova action `search_users`, `PluginSubticketTicket::searchUsers()`
sobre `User::getSqlSearchResult(right='all')`, autocomplete do cliente reescrito com debounce,
mínimo de caracteres, teto de resultados e `loginHint` de volta. Versão permanece `1.1.0`.

Não verificado nesta leva: nenhuma requisição HTTP real ao endpoint novo; busca por matrícula
(campo vazio em toda a base local); comportamento do autocomplete com latência de rede real;
recorte de entidade na busca (a base local tem uma entidade só) — **este último é o H12.12 e é
o teste que prova que a troca de mecanismo não reabriu o vazamento**.

## O que fiz

Branch `fix/autorizacao-e-vazamentos`, commits locais em 3 levas, **sem push**. Itens 1 a 7 da primeira
leva, 4b da segunda, 8/9/10 da terceira.
Detalhe por arquivo:linha, decisões, riscos e roteiro de homologação em
`01-vulcan-glpi-GLPI-Verification.md`.

Extras fora da lista numerada, ambos declarados no artefato:

- Removido o `Session::checkCSRF($_REQUEST)` manual do case `create` (queimava o token
  validado pelo listener — pitfalls §14). Adjacente ao item 2, mesmo defeito de raiz.
- `isRequesterAllowed()` reimplementa `User::isValidUserForEntity()` porque essa API só existe
  a partir do 11.0.8 e o plugin declara `min => 11.0.0`. Descoberto em execução: o container de
  desenvolvimento local roda **11.0.7** e deu fatal.

## O que NÃO verifiquei

- Nada foi executado em homologação nem em produção. Toda a evidência vem do container de
  desenvolvimento local `glpi_app`, que roda **GLPI 11.0.7**, não 11.0.8.
- Nenhum fluxo foi exercido pela interface (criar subticket, solucionar filho, fechar pai).
  Só chamei os validadores e as queries por CLI, em modo somente leitura.
- Não testei instância multientidade — a base local tem uma entidade só (`entities_id = 0`).
  É exatamente onde os itens 3 e 4 têm mais efeito e mais risco de regressão.
- Não rodei `plugin:install`/`plugin:activate` nem cliquei em Atualizar.

## Próximo responsável

**Hugo** — executar o roteiro de homologação do artefato antes de considerar o lote fechado.
Se algum dos três fluxos de negócio precisar mudar de desenho a partir do que a homologação
mostrar, o dono da decisão é `@nestor-itil`, não eu.
