<?php

/**
 * AJAX endpoint for Subticket plugin.
 */

use Glpi\Error\ErrorHandler;
use Glpi\Exception\Http\AccessDeniedHttpException;
use Glpi\Exception\Http\BadRequestHttpException;
use Glpi\Exception\Http\HttpExceptionInterface;

include('../../../inc/includes.php');

header('Content-Type: application/json; charset=UTF-8');
Html::header_nocache();
Session::checkLoginUser();

if (($_SESSION['glpiactiveprofile']['interface'] ?? '') !== 'central') {
    throw new AccessDeniedHttpException('Subticket is only available in central interface.');
}

$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {
        case 'source':
            if (!isset($_REQUEST['tickets_id'])) {
                throw new BadRequestHttpException('Missing tickets_id.');
            }
            echo json_encode(PluginSubticketTicket::getSourcePayload((int) $_REQUEST['tickets_id']));
            break;

        case 'check_parent_issues':
            // A autorizacao por objeto vive dentro de checkParentCloseabilityForChild():
            // exige can(READ) no chamado FILHO. Sem isso, um id arbitrario devolvia
            // metadados de completude do PAI atravessando entidade — mesmo padrao BOLA
            // fechado em getSubticketStatusMap(). O `parent_id` tambem saiu da resposta:
            // o cliente nunca o usou. Nao repita a checagem aqui; o portao e um so.
            if (!isset($_REQUEST['tickets_id'])) {
                throw new BadRequestHttpException('Missing tickets_id.');
            }
            echo json_encode(PluginSubticketTicket::checkParentCloseabilityForChild((int) $_REQUEST['tickets_id']));
            break;

        case 'search_users':
            // GET de proposito, coerente com as outras leituras deste arquivo
            // (list_statuses, get_children): e idempotente, nao muta nada e a resposta e
            // JSON — <img>/<script> de outra origem nao conseguem ler o corpo, e fetch/XHR
            // cross-origin esbarra em CORS. Sem CSRF, portanto, e SEM Session::checkCSRF()
            // manual (que quebraria o token, ver o case 'create').
            // URL curta por causa do WAF do cliente: so `action` e `q`.
            $term = (string) ($_REQUEST['q'] ?? '');
            echo json_encode(PluginSubticketTicket::searchUsers($term));
            break;

        case 'get_children':
            if (!isset($_REQUEST['tickets_id'])) {
                throw new BadRequestHttpException('Missing tickets_id.');
            }
            $type = (string) ($_REQUEST['type'] ?? PluginSubticketTicket::TYPE_SUBTICKET);
            echo json_encode(PluginSubticketTicket::getChildrenForParent((int) $_REQUEST['tickets_id'], $type));
            break;

        case 'set_bypass_waiting':
            // POST obrigatorio: em GET esta acao era armavel por <img src="...">
            // embutido na descricao de um chamado (o sanitizador do GLPI preserva src
            // relativo), disparando na sessao de qualquer tecnico que abrisse o chamado.
            // Com POST, o CheckCsrfListener do core valida o X-Glpi-Csrf-Token antes de
            // este arquivo executar (glpi/src/Glpi/Kernel/Listener/ControllerListener/CheckCsrfListener.php).
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new BadRequestHttpException('Invalid request method.');
            }
            if (!isset($_POST['tickets_id'])) {
                throw new BadRequestHttpException('Missing tickets_id.');
            }
            echo json_encode(PluginSubticketTicket::armBypassWaiting((int) $_POST['tickets_id']));
            break;

        case 'list_statuses':
            // 'ids' aceita ids[]=1&ids[]=2 (legado) ou ids=1,2,3. A forma CSV mantem a URL
            // curta: com ids[] repetido uma lista grande passa de 2048 chars e e barrada
            // por WAF (F5 ASM: "HTTP protocol compliance failed / URL length exceeded").
            $raw     = $_REQUEST['ids'] ?? [];
            $raw_ids = is_array($raw) ? $raw : explode(',', (string) $raw);
            $ids     = array_values(array_unique(array_filter(array_map('intval', $raw_ids))));
            $ids     = array_slice($ids, 0, PluginSubticketTicket::MAX_STATUS_IDS);
            $maps    = PluginSubticketTicket::getLinkStatusMaps($ids);
            echo json_encode([
                'success'    => true,
                'subtickets' => $maps[PluginSubticketTicket::TYPE_SUBTICKET],
                'related'    => $maps[PluginSubticketTicket::TYPE_RELATED],
            ]);
            break;

        case 'create':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new BadRequestHttpException('Invalid request method.');
            }
            // SEM Session::checkCSRF() aqui: o CheckCsrfListener ja validou o token do
            // header X-Glpi-Csrf-Token com preserve_token=true. Uma segunda chamada usaria
            // preserve_token=false e APAGARIA o token da sessao (glpi/src/Session.php,
            // validateCSRF()), fazendo o segundo envio do modal falhar ate um F5.
            // Ver glpi11_pitfalls.md secao 14.
            echo json_encode(PluginSubticketTicket::createFromInput($_POST));
            break;

        default:
            throw new BadRequestHttpException('Invalid action.');
    }
} catch (Throwable $e) {
    // So as excecoes HTTP levantadas por este arquivo tem mensagem segura para o cliente.
    // Qualquer outra (tipicamente RuntimeException do DBmysql) carrega a query SQL inteira
    // com os valores interpolados no getMessage() — isso fica so no log.
    $is_http_exception = $e instanceof HttpExceptionInterface;
    http_response_code($is_http_exception ? $e->getStatusCode() : 400);

    try {
        ErrorHandler::logCaughtException($e);
    } catch (Throwable) {
        // ErrorHandler pode nao ter logger registrado neste contexto: cai no log de arquivo.
        Toolbox::logInFile('php-errors', sprintf(
            "[subticket] action=%s %s: %s (%s:%d)\n",
            is_string($action) ? $action : '',
            $e::class,
            $e->getMessage(),
            $e->getFile(),
            $e->getLine()
        ));
    }

    echo json_encode([
        'success' => false,
        'message' => $is_http_exception
            ? $e->getMessage()
            : __s('Erro ao processar a solicitação. O detalhe foi registrado no log do GLPI.', 'subticket'),
    ]);
}
