<?php

/**
 * Subticket badge injection for the GLPI ticket list page.
 * Served as a JS file by the web server.
 */

if (!defined('GLPI_ROOT')) {
    include(dirname(__FILE__, 5) . '/inc/includes.php');
}

header('Content-Type: application/javascript; charset=UTF-8');
Html::header_nocache();

$status_labels = json_encode([
    1 => __s('Novo', 'subticket'),
    2 => __s('Em andamento', 'subticket'),
    3 => __s('Planejado', 'subticket'),
    4 => __s('Pendente', 'subticket'),
    5 => __s('Solucionado', 'subticket'),
    6 => __s('Fechado', 'subticket'),
], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);

?>
(function () {
    'use strict';

    const AJAX_URL    = CFG_GLPI.root_doc + '/plugins/subticket/ajax/ticket.php';
    const ST_LABELS   = <?= $status_labels ?>;
    const DEBOUNCE_MS = 400;
    const IDS_MAX_CHARS = 1200;

    let debounceTimer = null;

    function statusClass(s) {
        if (s === 1)            return 'new';
        if (s === 2 || s === 3) return 'processing';
        if (s === 4)            return 'waiting';
        if (s === 5)            return 'solved';
        if (s === 6)            return 'closed';
        return 'unknown';
    }

    function makeBadge(data, type) {
        const cls   = statusClass(data.worst_status);
        const label = ST_LABELS[data.worst_status] || '?';
        const icon  = type === 'subticket' ? 'ti-subtask' : 'ti-link';
        const nouns = type === 'subticket' ? ['subticket', 'subtickets'] : ['relacionado', 'relacionados'];
        const el    = document.createElement('span');
        el.className    = 'sbt-list-badge sbt-list-badge--' + cls;
        el.dataset.type = type;
        el.title        = data.count + ' ' + (data.count === 1 ? nouns[0] : nouns[1]) + ' · ' + label;
        el.innerHTML    = '<i class="ti ' + icon + ' sbt-badge-icon"></i>' + data.count + ' · ' + label;
        return el;
    }

    function getIdFromRow(row) {
        // Primary: link to ticket form (most reliable)
        const a = row.querySelector('a[href*="ticket.form.php?id="]');
        if (a) {
            const m = a.href.match(/ticket\.form\.php\?id=(\d+)/);
            if (m) return parseInt(m[1], 10);
        }
        // Fallback: checkbox name="item[Ticket][123]"
        const cb = row.querySelector('input[type="checkbox"][name*="[Ticket]"]');
        if (cb) {
            const m = (cb.name || '').match(/\[Ticket\]\[(\d+)\]/);
            if (m) return parseInt(m[1], 10);
        }
        return null;
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function openChildrenModal(parentId, type) {
        type = type || 'subticket';
        var icon  = type === 'subticket' ? 'ti-subtask' : 'ti-link';
        var title = type === 'subticket'
            ? 'Subtickets do chamado #' + parentId
            : 'Chamados relacionados ao chamado #' + parentId;
        var emptyMsg = type === 'subticket'
            ? 'Nenhum subticket encontrado.'
            : 'Nenhum chamado relacionado encontrado.';
        var errorMsg = type === 'subticket'
            ? 'Erro ao carregar subtickets.'
            : 'Erro ao carregar chamados relacionados.';

        var existing = document.getElementById('sbt-children-overlay');
        if (existing) existing.remove();

        var overlay = document.createElement('div');
        overlay.id = 'sbt-children-overlay';
        overlay.innerHTML =
            '<div class="sbt-children-modal" role="dialog" aria-modal="true">' +
                '<div class="sbt-children-header">' +
                    '<span class="sbt-children-header-icon"><i class="ti ' + icon + '"></i></span>' +
                    '<span class="sbt-children-title">' + title + '</span>' +
                    '<button class="sbt-children-close" aria-label="Fechar">&times;</button>' +
                '</div>' +
                '<div class="sbt-children-body" id="sbt-cb-' + parentId + '">' +
                    '<div class="sbt-children-loading">Carregando&hellip;</div>' +
                '</div>' +
            '</div>';
        document.body.appendChild(overlay);

        function close() { overlay.remove(); }

        overlay.querySelector('.sbt-children-close').addEventListener('click', close);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });

        function onKey(e) {
            if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onKey); }
        }
        document.addEventListener('keydown', onKey);
        overlay.addEventListener('remove', function () { document.removeEventListener('keydown', onKey); });

        var root = (typeof CFG_GLPI !== 'undefined' && CFG_GLPI.root_doc) ? CFG_GLPI.root_doc : '';
        fetch(AJAX_URL + '?action=get_children&tickets_id=' + parentId + '&type=' + type, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (data) {
            var body = document.getElementById('sbt-cb-' + parentId);
            if (!body) return;
            if (!data || !data.success || !data.children || !data.children.length) {
                body.innerHTML = '<div class="sbt-children-empty">' + emptyMsg + '</div>';
                return;
            }
            body.innerHTML = data.children.map(function (c) {
                var cls   = statusClass(c.status);
                var label = ST_LABELS[c.status] || '?';
                return '<a href="' + root + '/front/ticket.form.php?id=' + c.id +
                    '" class="sbt-children-item" target="_blank" rel="noopener">' +
                    '<span class="sbt-children-id">#' + c.id + '</span>' +
                    '<span class="sbt-children-name">' + escHtml(c.title) + '</span>' +
                    '<span class="sbt-list-badge sbt-list-badge--' + cls + '">' + label + '</span>' +
                    '</a>';
            }).join('');
        })
        .catch(function () {
            var body = document.getElementById('sbt-cb-' + parentId);
            if (body) body.innerHTML = '<div class="sbt-children-empty">' + errorMsg + '</div>';
        });
    }

    function injectBadges(subticketMap, relatedMap) {
        document.querySelectorAll('table tr').forEach(function (row) {
            const id = getIdFromRow(row);
            if (!id) return;

            const a = row.querySelector('a[href*="ticket.form.php?id=' + id + '"]');
            if (!a) return;

            var anchor = a;

            if (subticketMap[id] && !row.querySelector('.sbt-list-badge[data-type="subticket"]')) {
                var sb = makeBadge(subticketMap[id], 'subticket');
                sb.addEventListener('click', function (e) {
                    e.preventDefault(); e.stopPropagation();
                    openChildrenModal(id, 'subticket');
                });
                anchor.after(sb);
                anchor = sb;
            } else {
                var existing = row.querySelector('.sbt-list-badge[data-type="subticket"]');
                if (existing) anchor = existing;
            }

            if (relatedMap[id] && !row.querySelector('.sbt-list-badge[data-type="related"]')) {
                var rb = makeBadge(relatedMap[id], 'related');
                rb.addEventListener('click', function (e) {
                    e.preventDefault(); e.stopPropagation();
                    openChildrenModal(id, 'related');
                });
                anchor.after(rb);
            }
        });
    }

    // Ids em CSV e em lotes: com ids[] repetido uma lista longa estoura 2048 chars
    // na URL e o WAF (F5 ASM) barra a requisicao antes de ela chegar ao GLPI.
    function chunkIds(ids, maxChars) {
        const chunks = [];
        let current  = [];
        let length   = 0;
        ids.forEach(function (id) {
            const cost = String(id).length + 1;
            if (current.length && length + cost > maxChars) {
                chunks.push(current);
                current = [];
                length  = 0;
            }
            current.push(id);
            length += cost;
        });
        if (current.length) chunks.push(current);
        return chunks;
    }

    function scanAndFetch() {
        var ids = [];
        document.querySelectorAll('table tr').forEach(function (row) {
            var id = getIdFromRow(row);
            if (id) ids.push(id);
        });

        ids = ids.filter(function (v, i, a) { return a.indexOf(v) === i; });
        if (!ids.length) return;

        const requests = chunkIds(ids, IDS_MAX_CHARS).map(function (chunk) {
            return fetch(AJAX_URL + '?action=list_statuses&ids=' + chunk.join(','), {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
            }).then(function (r) {
                if (!r.ok) throw new Error('HTTP ' + r.status);
                return r.json();
            });
        });

        // Tudo ou nada de proposito: se um lote falhar e os demais forem exibidos, os
        // cards sem badge parecem "sem subticket" — errado e indistinguivel do normal.
        Promise.all(requests).then(function (parts) {
            const subMap = {};
            const relMap = {};
            parts.forEach(function (data) {
                if (!data || !data.success) throw new Error('lote invalido');
                Object.assign(subMap, data.subtickets || {});
                Object.assign(relMap, data.related    || {});
            });
            injectBadges(subMap, relMap);
        }).catch(function () {});
    }

    function debouncedScan() {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(scanAndFetch, DEBOUNCE_MS);
    }

    // Initial scan after DOM settles
    debouncedScan();

    // Re-scan whenever the ticket list is refreshed via AJAX
    new MutationObserver(debouncedScan).observe(document.body, { childList: true, subtree: true });
})();
