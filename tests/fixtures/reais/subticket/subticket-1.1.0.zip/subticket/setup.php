<?php

/**
 * -------------------------------------------------------------------------
 * Subticket plugin for GLPI
 * -------------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of Subticket.
 *
 * Subticket is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * -------------------------------------------------------------------------
 */

use Glpi\Plugin\Hooks;

if (!defined('GLPI_ROOT')) {
    die('Sorry. You cannot access this file directly');
}

// 1.1.0 — release de segurança (autorização de escrita, recorte de entidade/visibilidade,
// CSRF em set_bypass_waiting, fim do vazamento de erro SQL e do dump nominal de usuários).
// hook.php usa esta MESMA constante em `new Migration(...)`, então as duas ficam em sincronia
// por construção — ver glpi11_pitfalls.md seção 18.
const PLUGIN_SUBTICKET_VERSION = '1.1.0';

if (!defined('PLUGIN_SUBTICKET_DIR')) {
    define('PLUGIN_SUBTICKET_DIR', Plugin::getPhpDir('subticket'));
}

/**
 * Initialize plugin hooks.
 *
 * @return void
 */
function plugin_init_subticket(): void
{
    /** @var array $PLUGIN_HOOKS */
    /** @var DBmysql $DB */
    global $PLUGIN_HOOKS, $DB;

    $PLUGIN_HOOKS['csrf_compliant']['subticket'] = true;

    if (!Plugin::isPluginActive('subticket')) {
        return;
    }

    // Auto-migrate: add columns that may be missing on installs that pre-date this version.
    if (
        isset($DB)
        && $DB->tableExists('glpi_plugin_subticket_links')
        && !$DB->fieldExists('glpi_plugin_subticket_links', 'mirror_followups')
    ) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_links` ADD `mirror_followups` TINYINT NOT NULL DEFAULT '0' AFTER `notify_parent_on_close`");
    }
    if (
        isset($DB)
        && $DB->tableExists('glpi_plugin_subticket_configs')
        && !$DB->fieldExists('glpi_plugin_subticket_configs', 'default_mirror_followups')
    ) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_configs` ADD `default_mirror_followups` TINYINT NOT NULL DEFAULT '0' AFTER `default_notify_parent_on_close`");
    }

    PluginSubticketConfig::loadInSession();

    if (
        isset($_SESSION['glpiID'])
        && ($_SESSION['glpiactiveprofile']['interface'] ?? '') === 'central'
    ) {
        $uri      = $_SERVER['REQUEST_URI'] ?? '';
        $is_form  = str_contains($uri, 'ticket.form.php') && isset($_GET['id']);
        $is_list  = str_contains($uri, 'front/ticket.php');

        if ($is_form) {
            $PLUGIN_HOOKS['add_css']['subticket'][]        = 'css/subticket.css';
            $PLUGIN_HOOKS['add_javascript']['subticket'][] = 'js/subticket.js.php';
        }
        if ($is_list) {
            $PLUGIN_HOOKS['add_css']['subticket'][]        = 'css/subticket.css';
            $PLUGIN_HOOKS['add_javascript']['subticket'][] = 'js/subticket-list.js.php';
        }
    }

    $PLUGIN_HOOKS['item_update']['subticket'] = [
        'Ticket' => 'plugin_subticket_item_update',
    ];

    $PLUGIN_HOOKS['item_add']['subticket'] = [
        'ITILFollowup' => 'plugin_subticket_item_add',
    ];

    if (Session::haveRight('config', UPDATE)) {
        $PLUGIN_HOOKS['config_page']['subticket'] = 'front/config.form.php';
        $PLUGIN_HOOKS['menu_toadd']['subticket'] = [
            'admin' => PluginSubticketConfig::class,
        ];
    }
}

/**
 * Plugin metadata.
 *
 * @return array
 */
function plugin_version_subticket(): array
{
    return [
        'name'           => __s('Subticket', 'subticket'),
        'version'        => PLUGIN_SUBTICKET_VERSION,
        'author'         => 'Hugo Cobra',
        'homepage'       => '',
        'license'        => 'GPLv2+',
        'requirements'   => [
            'glpi' => [
                'min' => '11.0.0',
            ],
        ],
    ];
}

/**
 * Check plugin prerequisites.
 *
 * @return bool
 */
function plugin_subticket_check_prerequisites(): bool
{
    return true;
}

/**
 * Check plugin configuration.
 *
 * @param bool $verbose Verbose mode
 *
 * @return bool
 */
function plugin_subticket_check_config($verbose = false): bool
{
    return true;
}

