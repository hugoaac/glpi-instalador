<?php

/**
 * -------------------------------------------------------------------------
 * Subticket plugin for GLPI
 * -------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die('Sorry. You cannot access this file directly');
}

/**
 * Install plugin database tables.
 *
 * @return bool
 */
function plugin_subticket_install(): bool
{
    /** @var DBmysql $DB */
    global $DB;

    $migration = new Migration(PLUGIN_SUBTICKET_VERSION);
    $default_key_sign = DBConnection::getDefaultPrimaryKeySignOption();

    if (!$DB->tableExists('glpi_plugin_subticket_configs')) {
        $query = "CREATE TABLE `glpi_plugin_subticket_configs` (
            `id` INT {$default_key_sign} NOT NULL AUTO_INCREMENT,
            `is_active` TINYINT NOT NULL DEFAULT '1',
            `default_auto_close_related` TINYINT NOT NULL DEFAULT '0',
            `default_auto_close_subticket` TINYINT NOT NULL DEFAULT '0',
            `default_auto_close_parent` TINYINT NOT NULL DEFAULT '0',
            `default_notify_parent_on_close` TINYINT NOT NULL DEFAULT '0',
            `default_mirror_followups` TINYINT NOT NULL DEFAULT '0',
            `copy_documents_by_default` TINYINT NOT NULL DEFAULT '0',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $DB->doQuery($query);

        $DB->insert('glpi_plugin_subticket_configs', [
            'is_active'                      => 1,
            'default_auto_close_related'     => 0,
            'default_auto_close_subticket'   => 0,
            'default_auto_close_parent'      => 0,
            'default_notify_parent_on_close' => 0,
            'default_mirror_followups'       => 0,
            'copy_documents_by_default'      => 0,
        ]);
    }

    if (!$DB->tableExists('glpi_plugin_subticket_links')) {
        $query = "CREATE TABLE `glpi_plugin_subticket_links` (
            `id` INT {$default_key_sign} NOT NULL AUTO_INCREMENT,
            `tickets_id_parent` INT {$default_key_sign} NOT NULL DEFAULT '0',
            `tickets_id_child` INT {$default_key_sign} NOT NULL DEFAULT '0',
            `relation_type` VARCHAR(32) NOT NULL DEFAULT 'related',
            `auto_close` TINYINT NOT NULL DEFAULT '0',
            `auto_close_parent` TINYINT NOT NULL DEFAULT '0',
            `notify_parent_on_close` TINYINT NOT NULL DEFAULT '0',
            `mirror_followups` TINYINT NOT NULL DEFAULT '0',
            `users_id_creator` INT {$default_key_sign} NOT NULL DEFAULT '0',
            `date_creation` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `tickets_id_parent` (`tickets_id_parent`),
            KEY `tickets_id_child` (`tickets_id_child`),
            KEY `relation_type` (`relation_type`),
            KEY `auto_close` (`auto_close`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $DB->doQuery($query);
    }

    if ($DB->tableExists('glpi_plugin_subticket_links') && !$DB->fieldExists('glpi_plugin_subticket_links', 'auto_close_parent')) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_links` ADD `auto_close_parent` TINYINT NOT NULL DEFAULT '0' AFTER `auto_close`");
    }

    if ($DB->tableExists('glpi_plugin_subticket_configs') && !$DB->fieldExists('glpi_plugin_subticket_configs', 'default_auto_close_parent')) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_configs` ADD `default_auto_close_parent` TINYINT NOT NULL DEFAULT '0' AFTER `default_auto_close_subticket`");
    }

    if ($DB->tableExists('glpi_plugin_subticket_links') && !$DB->fieldExists('glpi_plugin_subticket_links', 'notify_parent_on_close')) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_links` ADD `notify_parent_on_close` TINYINT NOT NULL DEFAULT '0' AFTER `auto_close_parent`");
    }

    if ($DB->tableExists('glpi_plugin_subticket_configs') && !$DB->fieldExists('glpi_plugin_subticket_configs', 'default_notify_parent_on_close')) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_configs` ADD `default_notify_parent_on_close` TINYINT NOT NULL DEFAULT '0' AFTER `default_auto_close_parent`");
    }

    if ($DB->tableExists('glpi_plugin_subticket_links') && !$DB->fieldExists('glpi_plugin_subticket_links', 'mirror_followups')) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_links` ADD `mirror_followups` TINYINT NOT NULL DEFAULT '0' AFTER `notify_parent_on_close`");
    }

    if ($DB->tableExists('glpi_plugin_subticket_configs') && !$DB->fieldExists('glpi_plugin_subticket_configs', 'default_mirror_followups')) {
        $DB->doQuery("ALTER TABLE `glpi_plugin_subticket_configs` ADD `default_mirror_followups` TINYINT NOT NULL DEFAULT '0' AFTER `default_notify_parent_on_close`");
    }

    $migration->executeMigration();

    return true;
}

/**
 * Uninstall plugin database tables.
 *
 * @return bool
 */
function plugin_subticket_uninstall(): bool
{
    /** @var DBmysql $DB */
    global $DB;

    foreach (['glpi_plugin_subticket_links', 'glpi_plugin_subticket_configs'] as $table) {
        $DB->doQuery(sprintf('DROP TABLE IF EXISTS `%s`', $table));
    }

    return true;
}

/**
 * Handle ticket update hook.
 *
 * @param CommonDBTM $item Updated item
 *
 * @return bool
 */
function plugin_subticket_item_update(CommonDBTM $item): bool
{
    if ($item instanceof Ticket) {
        return PluginSubticketTicket::handleTicketUpdate($item);
    }

    return true;
}

/**
 * Handle item add hook (mirrors follow-ups to parent ticket).
 *
 * @param CommonDBTM $item Added item
 *
 * @return bool
 */
function plugin_subticket_item_add(CommonDBTM $item): bool
{
    if ($item instanceof ITILFollowup) {
        return PluginSubticketTicket::handleFollowupAdd($item);
    }

    return true;
}

/**
 * Inject extra search options for Ticket (subticket count + child status).
 * GLPI auto-discovers this function via Plugin::getAddSearchOptions().
 *
 * @param string $itemtype Item type
 *
 * @return array Search options array
 */
function plugin_subticket_getAddSearchOptions(string $itemtype): array
{
    if ($itemtype !== Ticket::class) {
        return [];
    }

    // IMPORTANT: array must be keyed by option ID.
    // Plugin::getAddSearchOptions() merges with +=, so auto-indexed arrays (keys 0, 1, ...)
    // silently collide with GLPI core Ticket option IDs (e.g. id=1 is the title field).
    return [
        5001 => [
            'id'            => 5001,
            'table'         => 'glpi_plugin_subticket_links',
            'field'         => 'id',
            'name'          => __('Possui subticket', 'subticket'),
            'datatype'      => 'bool',
            'usehaving'     => true,
            'searchtype'    => ['equals'],
            'massiveaction' => false,
            'forcegroupby'  => true,
            'joinparams'    => [
                'jointype'  => 'child',
                'linkfield' => 'tickets_id_parent',
                'condition' => "AND NEWTABLE.`relation_type` = 'subticket'",
            ],
        ],
        5002 => [
            'id'            => 5002,
            'table'         => 'glpi_tickets',
            'field'         => 'status',
            'name'          => __('Status do subticket', 'subticket'),
            'datatype'      => 'specific',
            'searchtype'    => ['equals', 'notequals'],
            'massiveaction' => false,
            'forcegroupby'  => true,
            // Top-level linkfield is what SQLProvider uses for the standard (default) join type.
            // Without this, GLPI would auto-generate getForeignKeyFieldForTable('glpi_tickets') = 'tickets_id',
            // which does not exist in glpi_plugin_subticket_links.
            'linkfield'     => 'tickets_id_child',
            'joinparams'    => [
                'beforejoin' => [
                    'table'      => 'glpi_plugin_subticket_links',
                    'joinparams' => [
                        'jointype'  => 'child',
                        'linkfield' => 'tickets_id_parent',
                        'condition' => "AND NEWTABLE.`relation_type` = 'subticket'",
                    ],
                ],
            ],
        ],
    ];
}

/**
 * Generate custom HAVING clause for the "Possui subticket" search option (ID 5001).
 *
 * GLPI calls this via Plugin::doOneHook('subticket', 'addHaving', ...) because the
 * search option's table starts with glpi_plugin_subticket_*.
 *
 * With forcegroupby+bool, GLPI puts GROUP_CONCAT(id...) AS ITEM_{num} in SELECT.
 * That alias is NULL when the LEFT JOIN finds no subticket rows, and non-NULL otherwise.
 *
 * @param string $link     SQL linking keyword (AND / OR)
 * @param bool   $not      Whether the criterion is negated by the user
 * @param string $itemtype The itemtype being searched (Ticket)
 * @param int    $id       Search option ID
 * @param string $val      Value submitted by the search form ('1' = Sim, '0' = Não)
 * @param string $num      Alias suffix: "{itemtype}_{id}" → e.g. "Ticket_5001"
 *
 * @return string Raw SQL condition for HAVING, or empty string to use default behavior
 */
function plugin_subticket_addHaving(string $link, bool $not, string $itemtype, int $id, string $val, string $num): string
{
    if ($id !== 5001 || $itemtype !== 'Ticket') {
        return '';
    }

    // val=1 (Sim) = wants tickets WITH subtickets → ITEM alias IS NOT NULL
    // val=0 (Não/null) = wants tickets WITHOUT subtickets → ITEM alias IS NULL
    // $not inverts the entire condition (user toggled NOT in the search UI)
    $wants_subticket = ((int) $val === 1) !== $not;

    return $wants_subticket
        ? "`ITEM_{$num}` IS NOT NULL"
        : "`ITEM_{$num}` IS NULL";
}
