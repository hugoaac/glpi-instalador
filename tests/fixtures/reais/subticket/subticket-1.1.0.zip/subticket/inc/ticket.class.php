<?php

/**
 * Ticket business logic for Subticket plugin.
 */
class PluginSubticketTicket extends CommonDBTM
{
    public const TYPE_RELATED = 'related';
    public const TYPE_SUBTICKET = 'subticket';

    /** Teto de ids por chamada de list_statuses (o cliente ja envia em lotes). */
    public const MAX_STATUS_IDS = 500;

    /** Validade, em segundos, do consentimento de bypass das travas de fechamento do pai. */
    private const BYPASS_WAITING_TTL = 300;

    /** Minimo de caracteres antes de a busca de requerente ir ao servidor. */
    public const USER_SEARCH_MIN_CHARS = 2;

    /** Teto de usuarios devolvidos por busca. O cliente pede para refinar acima disso. */
    public const USER_SEARCH_LIMIT = 20;

    /**
     * Fields that can be copied from the source ticket.
     *
     * SEGURANÇA: `entities_id` NÃO entra nesta lista. A entidade do novo chamado é sempre
     * herdada do chamado de origem em buildTicketFields(); o core não valida esse campo em
     * Ticket::add(), então aceitá-lo do input permitiria criar chamado em entidade
     * arbitrária (o formulário sequer expõe o campo).
     *
     * @return array
     */
    public static function getCopyableFields(): array
    {
        return [
            'name',
            'content',
            'itilcategories_id',
            'type',
            'locations_id',
            'requesttypes_id',
        ];
    }

    /**
     * Return basic data from a source ticket for the modal.
     *
     * @param int $tickets_id Source ticket ID
     *
     * @return array
     */
    public static function getSourcePayload(int $tickets_id): array
    {
        $ticket = new Ticket();
        if (!$ticket->getFromDB($tickets_id)) {
            return ['success' => false, 'message' => __s('Chamado de origem não encontrado.', 'subticket')];
        }

        if (!$ticket->can($tickets_id, READ)) {
            return ['success' => false, 'message' => __s('Você não tem permissão para visualizar este chamado.', 'subticket')];
        }

        $requesters = self::getTicketUsers($tickets_id, CommonITILActor::REQUESTER);

        $cat_id = (int) ($ticket->fields['itilcategories_id'] ?? 0);
        $itilcategory_name = '';
        if ($cat_id > 0) {
            $cat = new ITILCategory();
            if ($cat->getFromDB($cat_id)) {
                $itilcategory_name = $cat->fields['completename'] ?? ($cat->fields['name'] ?? '');
            }
        }

        $locations_id = (int) ($ticket->fields['locations_id'] ?? 0);
        $location_name = '';
        if ($locations_id > 0) {
            $loc = new Location();
            if ($loc->getFromDB($locations_id)) {
                $location_name = $loc->fields['completename'] ?? ($loc->fields['name'] ?? '');
            }
        }

        return [
            'success' => true,
            'ticket'  => [
                'id'                 => $tickets_id,
                'name'               => $ticket->fields['name'] ?? '',
                'content'            => $ticket->fields['content'] ?? '',
                'itilcategories_id'  => $cat_id,
                'itilcategory_name'  => $itilcategory_name,
                'type'               => (int) ($ticket->fields['type'] ?? 0),
                'entities_id'        => (int) ($ticket->fields['entities_id'] ?? 0),
                'locations_id'       => $locations_id,
                'location_name'      => $location_name,
                'requesttypes_id'    => (int) ($ticket->fields['requesttypes_id'] ?? 0),
                'requesters'         => $requesters,
            ],
            'config' => PluginSubticketConfig::getConfig(),
        ];
    }

    /**
     * Busca usuários candidatos a requerente pelo termo digitado.
     *
     * Substitui o dump da base inteira que antes era serializado no corpo do JS a cada
     * abertura de ticket.form.php. `User::getSqlSearchResult()` é o mesmo motor do dropdown
     * nativo de requerente (`right = 'all'`, CommonITILObject.php:4867) e já faz, de uma vez:
     *  - recorte de entidade (via glpi_profiles_users — glpi_users não tem entities_id);
     *  - exclusão de inativos, deletados, fora da janela begin_date/end_date e do usuário
     *    de sistema;
     *  - o LIKE sobre `name` (login), `realname`, `firstname`, `registration_number`
     *    (matrícula), `phone`, e-mail padrão e o nome concatenado.
     *
     * O termo passa por `Search::makeTextSearchValue()`, que envolve em `%...%` e trata `^`
     * e `$` como âncoras — quem quiser prefixo exato pode digitar `^joao`.
     *
     * ATENÇÃO: este endpoint é conveniência de UI, NUNCA o portão de autorização. Quem
     * decide se um `requester_id` pode ser gravado é `isRequesterAllowed()`, chamado por
     * `validateFieldScope()` no caminho de criação. Um cliente forjado pode enviar qualquer
     * id sem passar por aqui.
     *
     * @param string $term Termo digitado pelo usuário
     *
     * @return array {success, users: [{id, name, login}], truncated, min_chars}
     */
    public static function searchUsers(string $term): array
    {
        if (!Session::haveRight('ticket', CREATE)) {
            return ['success' => false, 'users' => [], 'message' => __s('Você não tem permissão para criar chamados.', 'subticket')];
        }

        $term = trim($term);
        if (mb_strlen($term) < self::USER_SEARCH_MIN_CHARS) {
            return [
                'success'   => true,
                'users'     => [],
                'truncated' => false,
                'min_chars' => self::USER_SEARCH_MIN_CHARS,
            ];
        }

        // +1 no limite só para descobrir se havia mais resultados do que cabem na lista.
        $iterator = User::getSqlSearchResult(
            false,                          // count
            'all',                          // right — igual ao dropdown nativo de requerente
            -1,                             // entity_restrict — entidades ativas da sessão
            0,                              // value
            [],                             // used
            $term,                          // search
            0,                              // start
            self::USER_SEARCH_LIMIT + 1     // limit
        );

        $users = [];
        foreach ($iterator as $row) {
            $users[] = [
                'id'    => (int) $row['id'],
                'name'  => formatUserName(
                    (int) $row['id'],
                    $row['name'] ?? '',
                    $row['realname'] ?? '',
                    $row['firstname'] ?? ''
                ),
                // O login volta ao payload porque agora só trafegam os usuários que casaram
                // o termo E estão dentro do recorte de entidade — não a instância inteira.
                'login' => (string) ($row['name'] ?? ''),
            ];
        }

        $truncated = count($users) > self::USER_SEARCH_LIMIT;
        if ($truncated) {
            array_pop($users);
        }

        return [
            'success'   => true,
            'users'     => $users,
            'truncated' => $truncated,
            'min_chars' => self::USER_SEARCH_MIN_CHARS,
        ];
    }

    /**
     * Create a related ticket or a subticket from request data.
     *
     * @param array $input Request input
     *
     * @return array
     */
    public static function createFromInput(array $input): array
    {
        /** @var DBmysql $DB */
        global $DB;

        if (!Session::haveRight('ticket', CREATE)) {
            return ['success' => false, 'message' => __s('Você não tem permissão para criar chamados.', 'subticket')];
        }

        $source_id = (int) ($input['tickets_id'] ?? 0);
        $relation_type = (string) ($input['relation_type'] ?? self::TYPE_RELATED);
        if (!in_array($relation_type, [self::TYPE_RELATED, self::TYPE_SUBTICKET], true)) {
            return ['success' => false, 'message' => __s('Tipo de relacionamento inválido.', 'subticket')];
        }

        $source = new Ticket();
        if (!$source_id || !$source->getFromDB($source_id)) {
            return ['success' => false, 'message' => __s('Chamado de origem não encontrado.', 'subticket')];
        }
        // UPDATE, não READ: criar um subticket ALTERA o chamado de origem (pausa em Pendente,
        // followup público, vínculo nativo) e, com auto_close_parent, pode fechá-lo depois.
        // `can(READ)` deixava qualquer perfil que apenas ENXERGA o chamado disparar tudo isso.
        // Ticket::canUpdateItem() (glpi/src/Ticket.php:613) cobre ator do chamado, dono (OWN) e
        // perfil com direito global de atualizar — que é exatamente a premissa do fluxo.
        if (!$source->can($source_id, UPDATE)) {
            return [
                'success' => false,
                'message' => __s(
                    'Você não tem permissão para alterar o chamado de origem. Criar um subticket ou chamado relacionado pausa e comenta o chamado de origem, portanto exige direito de atualização sobre ele.',
                    'subticket'
                ),
            ];
        }

        $fields = self::buildTicketFields($source, $input, $relation_type);
        $scope = self::validateFieldScope($fields);
        if (!$scope['success']) {
            return $scope;
        }
        $validation = self::validateTicketFields($fields, $input);
        if (!$validation['success']) {
            return $validation;
        }
        if ($relation_type === self::TYPE_SUBTICKET && empty($fields['itilcategories_id'])) {
            return ['success' => false, 'message' => __s('Informe a categoria do subticket.', 'subticket')];
        }

        $ticket = new Ticket();
        $_SESSION['plugin_subticket']['creating'] = true;
        $new_id = $ticket->add($fields);
        unset($_SESSION['plugin_subticket']['creating']);

        if (!$new_id) {
            return ['success' => false, 'message' => __s('Não foi possível criar o novo chamado.', 'subticket')];
        }

        self::syncRequester($source_id, (int) $new_id, $input, $relation_type);

        if (self::boolFromInput($input, 'copy_documents')) {
            self::copyDocuments($source_id, (int) $new_id);
        }

        self::addNativeTicketLink($source_id, (int) $new_id, $relation_type);
        self::recordPluginLink(
            $source_id,
            (int) $new_id,
            $relation_type,
            self::boolFromInput($input, 'auto_close'),
            self::boolFromInput($input, 'auto_close_parent'),
            self::boolFromInput($input, 'notify_parent_on_close'),
            self::boolFromInput($input, 'mirror_followups')
        );
        self::addCreationFollowup($source_id, (int) $new_id, $relation_type);
        self::addHistory($source_id, (int) $new_id, $relation_type);

        if ($relation_type === self::TYPE_SUBTICKET) {
            self::addParentFollowup($source_id, (int) $new_id);
            self::setSourceTicketWaiting($source_id);
        }

        return [
            'success' => true,
            'newID'   => (int) $new_id,
            'message' => __s('Chamado criado e relacionado com sucesso.', 'subticket'),
        ];
    }

    /**
     * Build input for Ticket::add().
     *
     * @param Ticket $source        Source ticket
     * @param array  $input         Request input
     * @param string $relation_type Relation type
     *
     * @return array
     */
    private static function buildTicketFields(Ticket $source, array $input, string $relation_type): array
    {
        $copy_fields = self::normalizeCopyFields($input['copy_fields'] ?? []);
        if ($relation_type === self::TYPE_RELATED && $copy_fields === []) {
            $copy_fields = self::getCopyableFields();
        }

        $fields = [];
        foreach (self::getCopyableFields() as $field) {
            if (in_array($field, $copy_fields, true) && array_key_exists($field, $source->fields)) {
                $fields[$field] = $source->fields[$field];
            }
        }

        foreach (self::getCopyableFields() as $field) {
            if (array_key_exists($field, $input) && $input[$field] !== '') {
                $fields[$field] = self::sanitizeFieldValue($field, $input[$field]);
            }
        }

        $fields['status'] = CommonITILObject::INCOMING;
        $fields['_disablenotif'] = (int) self::boolFromInput($input, 'disable_notification');

        // Entidade SEMPRE herdada do chamado de origem, nunca do input (ver getCopyableFields()).
        // A atribuição é incondicional de propósito: qualquer `entities_id` que tenha chegado
        // pelo POST é sobrescrito aqui.
        $fields['entities_id'] = (int) ($source->fields['entities_id'] ?? $_SESSION['glpiactive_entity'] ?? 0);

        $requester_id = (int) ($input['requester_id'] ?? 0);
        if ($requester_id > 0) {
            $fields['_users_id_requester'] = $requester_id;
        } elseif ($relation_type === self::TYPE_RELATED || in_array('requester', $copy_fields, true)) {
            $first_requester = self::getFirstRequesterId((int) $source->getID());
            if ($first_requester > 0) {
                $fields['_users_id_requester'] = $first_requester;
            }
        }

        return $fields;
    }

    /**
     * Recorte de segurança dos campos que vêm do cliente e apontam para outra tabela.
     *
     * O core NÃO valida esses ids em Ticket::add(): sem esta checagem, um POST forjado cria
     * chamado com categoria, localização ou requerente de fora das entidades do usuário.
     * A entidade em si não é validada aqui porque já é herdada do chamado de origem, sobre o
     * qual `can($source_id, UPDATE)` (que chama checkEntity()) já passou.
     *
     * @param array $fields Campos já montados para Ticket::add()
     *
     * @return array {success, message?}
     */
    private static function validateFieldScope(array $fields): array
    {
        $entities_id = (int) ($fields['entities_id'] ?? 0);

        $cat_id = (int) ($fields['itilcategories_id'] ?? 0);
        if ($cat_id > 0) {
            $cat = new ITILCategory();
            if (
                !$cat->getFromDB($cat_id)
                || !Session::haveAccessToEntity(
                    (int) ($cat->fields['entities_id'] ?? -1),
                    (bool) ($cat->fields['is_recursive'] ?? false)
                )
            ) {
                return ['success' => false, 'message' => __s('Categoria inválida ou fora das entidades permitidas.', 'subticket')];
            }
        }

        $loc_id = (int) ($fields['locations_id'] ?? 0);
        if ($loc_id > 0) {
            $loc = new Location();
            if (
                !$loc->getFromDB($loc_id)
                || !Session::haveAccessToEntity(
                    (int) ($loc->fields['entities_id'] ?? -1),
                    (bool) ($loc->fields['is_recursive'] ?? false)
                )
            ) {
                return ['success' => false, 'message' => __s('Localização inválida ou fora das entidades permitidas.', 'subticket')];
            }
        }

        // glpi_requesttypes é global (sem entities_id): valida só existência e atividade.
        $requesttypes_id = (int) ($fields['requesttypes_id'] ?? 0);
        if ($requesttypes_id > 0) {
            $request_type = new RequestType();
            if (!$request_type->getFromDB($requesttypes_id) || !(int) ($request_type->fields['is_active'] ?? 0)) {
                return ['success' => false, 'message' => __s('Origem da requisição inválida.', 'subticket')];
            }
        }

        $type = (int) ($fields['type'] ?? 0);
        if ($type !== 0 && !in_array($type, [Ticket::INCIDENT_TYPE, Ticket::DEMAND_TYPE], true)) {
            return ['success' => false, 'message' => __s('Tipo de chamado inválido.', 'subticket')];
        }

        $requester_id = (int) ($fields['_users_id_requester'] ?? 0);
        if ($requester_id > 0 && !self::isRequesterAllowed($requester_id, $entities_id)) {
            return ['success' => false, 'message' => __s('Requerente inválido ou sem acesso à entidade do chamado.', 'subticket')];
        }

        return ['success' => true];
    }

    /**
     * O usuário pode ser requerente de um chamado nesta entidade?
     *
     * Ativo, não deletado, dentro da janela begin_date/end_date e com algum perfil na
     * entidade de destino (ou numa ancestral, com is_recursive) — mesmas condições que o
     * dropdown nativo de requerente aplica via User::getSqlSearchResult(right='all').
     *
     * A lógica é reimplementada aqui de propósito: `User::isValidUserForEntity()` só existe
     * a partir do GLPI 11.0.8 (glpi/src/User.php:4360) e o plugin declara `min => 11.0.0`.
     * Chamá-la direto daria fatal em 11.0.0–11.0.7 — o container de desenvolvimento local,
     * por exemplo, roda 11.0.7.
     *
     * @param int $users_id    Usuário candidato a requerente
     * @param int $entities_id Entidade do chamado que será criado
     *
     * @return bool
     */
    private static function isRequesterAllowed(int $users_id, int $entities_id): bool
    {
        /** @var DBmysql $DB */
        global $DB;

        $where = [
            'glpi_users.id'         => $users_id,
            'glpi_users.is_active'  => 1,
            'glpi_users.is_deleted' => 0,
            [
                'OR' => [
                    ['glpi_users.begin_date' => null],
                    new QueryExpression('`glpi_users`.`begin_date` < NOW()'),
                ],
            ],
            [
                'OR' => [
                    ['glpi_users.end_date' => null],
                    new QueryExpression('`glpi_users`.`end_date` > NOW()'),
                ],
            ],
        ];

        $entity_criteria = getEntitiesRestrictCriteria('glpi_profiles_users', '', $entities_id, true);
        if (!empty($entity_criteria)) {
            $where['OR'] = $entity_criteria;
        }

        $row = $DB->request([
            'COUNT'     => 'cpt',
            'FROM'      => 'glpi_users',
            'LEFT JOIN' => [
                'glpi_profiles_users' => [
                    'ON' => [
                        'glpi_profiles_users' => 'users_id',
                        'glpi_users'          => 'id',
                    ],
                ],
            ],
            'WHERE'     => $where,
        ])->current();

        return (int) ($row['cpt'] ?? 0) > 0;
    }

    /**
     * Validate minimum ticket fields.
     *
     * @param array $fields Ticket fields
     * @param array $input  Original input
     *
     * @return array
     */
    private static function validateTicketFields(array $fields, array $input): array
    {
        if (empty($fields['name'])) {
            return ['success' => false, 'message' => __s('Informe o título do novo chamado.', 'subticket')];
        }
        if (empty($fields['content'])) {
            return ['success' => false, 'message' => __s('Informe a descrição do novo chamado.', 'subticket')];
        }
        if (empty($fields['_users_id_requester']) && empty($input['copy_requesters'])) {
            return ['success' => false, 'message' => __s('Informe ou copie pelo menos um requerente.', 'subticket')];
        }

        return ['success' => true];
    }

    /**
     * Normalize copy field input.
     *
     * @param mixed $copy_fields Copy field input
     *
     * @return array
     */
    private static function normalizeCopyFields($copy_fields): array
    {
        if (is_string($copy_fields)) {
            $decoded = json_decode($copy_fields, true);
            $copy_fields = is_array($decoded) ? $decoded : explode(',', $copy_fields);
        }
        if (!is_array($copy_fields)) {
            return [];
        }

        $allowed = array_merge(self::getCopyableFields(), ['requester']);
        return array_values(array_intersect($allowed, array_map('strval', $copy_fields)));
    }

    /**
     * Convert field value according to expected type.
     *
     * @param string $field Field name
     * @param mixed  $value Value
     *
     * @return mixed
     */
    private static function sanitizeFieldValue(string $field, $value)
    {
        if (in_array($field, ['itilcategories_id', 'type', 'locations_id', 'requesttypes_id'], true)) {
            return (int) $value;
        }

        if ($field === 'content') {
            // Preservar HTML: o GLPI armazena e renderiza `content` como HTML.
            //
            // ATENÇÃO — o comentário que estava aqui dizia que "o GLPI sanitiza em
            // Ticket::add()". É FALSO e induziu ao erro. No GLPI 11 a proteção é de SAÍDA,
            // não de entrada:
            //   - `Glpi\Toolbox\Sanitizer` existe mas está @deprecated 11.0.0 em todos os
            //     métodos e NÃO é chamado em CommonDBTM/CommonITILObject/Ticket no ciclo de
            //     add/update — nada limpa este valor antes de gravar;
            //   - quem escapa é o template, em
            //     `templates/components/itilobject/timeline/timeline.html.twig:203`
            //     (`{{ entry_i['content']|safe_html }}` → RichText::getSafeHtml, filtro
            //     registrado em `Glpi\Application\View\Extension\DataHelpersExtension:65`).
            //
            // Consequência prática: o que sai daqui vai CRU para o banco. Qualquer consumidor
            // que não passe pelo Twig do core precisa escapar por conta própria — é o caso do
            // `innerHTML = ticket.content` em public/js/subticket.js.php (DOM XSS conhecido,
            // com lote próprio; NÃO corrigir aqui).
            return (string) $value;
        }

        return strip_tags((string) $value);
    }

    /**
     * Copy or override requester actors.
     *
     * @param int    $source_id     Source ticket ID
     * @param int    $new_id        New ticket ID
     * @param array  $input         Request input
     * @param string $relation_type Relation type
     *
     * @return void
     */
    private static function syncRequester(int $source_id, int $new_id, array $input, string $relation_type): void
    {
        $copy_fields = self::normalizeCopyFields($input['copy_fields'] ?? []);
        $copy_requesters = self::boolFromInput($input, 'copy_requesters')
            || in_array('requester', $copy_fields, true)
            || $relation_type === self::TYPE_RELATED;

        if (!$copy_requesters || (int) ($input['requester_id'] ?? 0) > 0) {
            return;
        }

        self::copyTicketUsers($source_id, $new_id, CommonITILActor::REQUESTER);
    }

    /**
     * Create native GLPI link between tickets.
     *
     * @param int    $source_id     Source ticket ID
     * @param int    $new_id        New ticket ID
     * @param string $relation_type Relation type
     *
     * @return void
     */
    private static function addNativeTicketLink(int $source_id, int $new_id, string $relation_type): void
    {
        // Always use LINK_TO for the native Ticket_Ticket record.
        // SON_OF causes GLPI to propagate followups from child to parent automatically,
        // which changes the parent status unexpectedly. The parent-child semantics are
        // managed exclusively by glpi_plugin_subticket_links.
        $ticket_ticket = new Ticket_Ticket();
        $ticket_ticket->add([
            'tickets_id_1' => $source_id,
            'tickets_id_2' => $new_id,
            'link'         => self::getNativeLinkType(),
        ]);
    }

    /**
     * Store plugin metadata for the relationship.
     *
     * @param int    $source_id        Source ticket ID
     * @param int    $new_id           New ticket ID
     * @param string $relation_type    Relation type
     * @param bool   $auto_close       Auto-close children flag
     * @param bool   $auto_close_parent Auto-close parent when child closes flag
     *
     * @return void
     */
    private static function recordPluginLink(int $source_id, int $new_id, string $relation_type, bool $auto_close, bool $auto_close_parent = false, bool $notify_parent_on_close = false, bool $mirror_followups = false): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->insert('glpi_plugin_subticket_links', [
            'tickets_id_parent'      => $source_id,
            'tickets_id_child'       => $new_id,
            'relation_type'          => $relation_type,
            'auto_close'             => (int) $auto_close,
            'auto_close_parent'      => (int) $auto_close_parent,
            'notify_parent_on_close' => (int) $notify_parent_on_close,
            'mirror_followups'       => (int) $mirror_followups,
            'users_id_creator'       => Session::getLoginUserID(),
        ]);
    }

    /**
     * Add a private followup in the new ticket noting its origin.
     * Uses the mirroring flag so this note is never echoed back to the parent.
     */
    private static function addCreationFollowup(int $source_id, int $new_id, string $relation_type): void
    {
        $label = $relation_type === self::TYPE_SUBTICKET
            ? __s('Este chamado foi criado como subticket do chamado', 'subticket')
            : __s('Este chamado foi criado como ticket relacionado ao chamado', 'subticket');

        // Prevent mirror_followups from echoing this auto-note to the parent ticket.
        $_SESSION['plugin_subticket']['mirroring_followup'] = true;

        $followup = new ITILFollowup();
        $followup->add([
            'items_id'        => $new_id,
            'itemtype'        => Ticket::class,
            'users_id'        => Session::getLoginUserID(),
            'content'         => sprintf('%s #%d.', $label, $source_id),
            'is_private'      => 1,
            'requesttypes_id' => 6,
        ]);

        unset($_SESSION['plugin_subticket']['mirroring_followup']);
    }

    /**
     * Solve or close a ticket by adding an ITILSolution copied from a related ticket.
     * GLPI requires a solution description before accepting SOLVED/CLOSED status.
     *
     * @param int    $target_id     Ticket to be solved
     * @param int    $source_id     Ticket whose solution is copied
     * @param int    $source_status Status the source ticket reached
     * @param string $label         Context label used in the solution text
     *
     * @return void
     */
    private static function solveTicketFromRelated(int $target_id, int $source_id, int $source_status, string $relation_type, bool $source_is_parent = true): void
    {
        /** @var array $CFG_GLPI */
        global $CFG_GLPI;

        // "a partir do encerramento do X"
        if ($source_is_parent) {
            $closer_label = 'chamado de origem';
        } else {
            $closer_label = $relation_type === self::TYPE_SUBTICKET ? 'subticket' : 'chamado relacionado';
        }

        $source_url      = ($CFG_GLPI['root_doc'] ?? '') . '/front/ticket.form.php?id=' . $source_id;
        $source_link     = '<a href="' . htmlspecialchars($source_url, ENT_QUOTES | ENT_HTML5) . '">#' . $source_id . '</a>';
        $source_solution = self::getLastSolutionContent($source_id);

        $solution_block = $source_solution !== ''
            ? '<strong>Descrição da solução:</strong><br>' . $source_solution
            : 'Consulte o chamado vinculado para mais detalhes.';

        $content = 'Caro(a) usuário(a),<br><br>'
            . 'Sua solicitação foi atendida com sucesso.<br><br>'
            . $solution_block . '<br><br>'
            . 'Este atendimento foi concluído automaticamente a partir do encerramento do ' . $closer_label . ':<br>'
            . $source_link;

        $solution = new ITILSolution();
        $solution->add([
            'itemtype'         => Ticket::class,
            'items_id'         => $target_id,
            'content'          => $content,
            'solutiontypes_id' => 0,
            'users_id'         => Session::getLoginUserID(),
        ]);

        // If source was fully closed (beyond solved), close the target too
        if ($source_status === CommonITILObject::CLOSED) {
            $ticket = new Ticket();
            if ($ticket->getFromDB($target_id) && (int) $ticket->fields['status'] === CommonITILObject::SOLVED) {
                $ticket->update(['id' => $target_id, 'status' => CommonITILObject::CLOSED]);
            }
        }
    }

    /**
     * Return the content of the last solution of a ticket.
     *
     * @param int $tickets_id Ticket ID
     *
     * @return string
     */
    private static function getLastSolutionContent(int $tickets_id): string
    {
        $solution = new ITILSolution();
        $rows = $solution->find(
            ['itemtype' => Ticket::class, 'items_id' => $tickets_id],
            ['id DESC'],
            1
        );

        return (string) (reset($rows)['content'] ?? '');
    }

    /**
     * Add a private followup in the parent ticket when the subticket is solved/closed.
     * Only called when notify_parent_on_close = 1 (user opted-in at creation time).
     *
     * @param int $parent_id Parent ticket ID
     * @param int $child_id  Child ticket ID
     * @param int $status    New status
     *
     * @return void
     */
    private static function addChildClosedFollowup(int $parent_id, int $child_id, int $status, string $relation_type = self::TYPE_SUBTICKET, bool $remove_pending = false): void
    {
        $status_label = $status === CommonITILObject::SOLVED
            ? __s('Solucionado', 'subticket')
            : __s('Fechado', 'subticket');

        $template = $relation_type === self::TYPE_SUBTICKET
            ? __s('Chamado Filho #%d %s.', 'subticket')
            : __s('Chamado Relacionado #%d %s.', 'subticket');

        $data = [
            'items_id'        => $parent_id,
            'itemtype'        => Ticket::class,
            'users_id'        => Session::getLoginUserID(),
            'content'         => sprintf($template, $child_id, $status_label),
            'is_private'      => 1,
            'requesttypes_id' => 6,
        ];

        if ($remove_pending) {
            $data['pending'] = 0;
        }

        $followup = new ITILFollowup();
        $followup->add($data);
    }

    /**
     * Add a private followup in the parent ticket referencing the new child.
     *
     * @param int    $source_id     Source (parent) ticket ID
     * @param int    $new_id        New (child) ticket ID
     * @param string $relation_type Relation type
     *
     * @return void
     */
    private static function addParentFollowup(int $source_id, int $new_id): void
    {
        /** @var array $CFG_GLPI */
        global $CFG_GLPI;

        $child_url = ($CFG_GLPI['root_doc'] ?? '') . '/front/ticket.form.php?id=' . $new_id;
        $content = sprintf(
            'Chamado Pausado Automaticamente.<br>Motivo: Aguardando atendimento do subticket <a href="%s">#%d</a>',
            htmlspecialchars($child_url, ENT_QUOTES | ENT_HTML5),
            $new_id
        );

        $followup = new ITILFollowup();
        $followup->add([
            'items_id'        => $source_id,
            'itemtype'        => Ticket::class,
            'users_id'        => Session::getLoginUserID(),
            'content'         => $content,
            'is_private'      => 0,
            'requesttypes_id' => 6,
            // pending=1 instrui o GLPI a marcar o chamado como Pendente via ORM,
            // garantindo que SLA e métricas contabilizem o tempo de pausa corretamente.
            'pending'         => 1,
        ]);
    }

    private static function setSourceTicketWaiting(int $source_id): void
    {
        $ticket = new Ticket();
        if (!$ticket->getFromDB($source_id)) {
            return;
        }
        $current = (int) $ticket->fields['status'];
        // O followup com pending=1 já deve ter colocado o chamado em WAITING;
        // este bloco é apenas um fallback caso o status ainda não esteja correto.
        if (in_array($current, [CommonITILObject::SOLVED, CommonITILObject::CLOSED, CommonITILObject::WAITING], true)) {
            return;
        }

        $ticket->update(['id' => $source_id, 'status' => CommonITILObject::WAITING]);
    }

    /**
     * Add a history record in the new ticket.
     *
     * @param int    $source_id     Source ticket ID
     * @param int    $new_id        New ticket ID
     * @param string $relation_type Relation type
     *
     * @return void
     */
    private static function addHistory(int $source_id, int $new_id, string $relation_type): void
    {
        $label = $relation_type === self::TYPE_SUBTICKET ? 'subticket' : 'ticket relacionado';
        Log::history($new_id, Ticket::class, [
            0,
            '',
            sprintf('Criado como %s a partir do chamado #%d', $label, $source_id),
        ], '', 0);
    }

    /**
     * Copy ticket users by actor type.
     *
     * @param int $source_id Source ticket ID
     * @param int $new_id    New ticket ID
     * @param int $type      Actor type
     *
     * @return void
     */
    private static function copyTicketUsers(int $source_id, int $new_id, int $type): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $rows = $DB->request([
            'SELECT' => ['users_id', 'type', 'use_notification', 'alternative_email'],
            'FROM'   => 'glpi_tickets_users',
            'WHERE'  => ['tickets_id' => $source_id, 'type' => $type],
        ]);

        foreach ($rows as $row) {
            $already = countElementsInTable('glpi_tickets_users', [
                'tickets_id'        => $new_id,
                'users_id'          => (int) $row['users_id'],
                'type'              => (int) $row['type'],
                'alternative_email' => $row['alternative_email'],
            ]);
            if ($already > 0) {
                continue;
            }

            $DB->insert('glpi_tickets_users', [
                'tickets_id'        => $new_id,
                'users_id'          => (int) $row['users_id'],
                'type'              => (int) $row['type'],
                'use_notification'  => (int) $row['use_notification'],
                'alternative_email' => $row['alternative_email'],
            ]);
        }
    }

    /**
     * Copy documents attached to ticket.
     *
     * @param int $source_id Source ticket ID
     * @param int $new_id    New ticket ID
     *
     * @return void
     */
    private static function copyDocuments(int $source_id, int $new_id): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $rows = $DB->request([
            'SELECT' => ['documents_id', 'entities_id', 'is_recursive', 'date_mod'],
            'FROM'   => 'glpi_documents_items',
            'WHERE'  => ['items_id' => $source_id, 'itemtype' => 'Ticket'],
        ]);

        foreach ($rows as $row) {
            $DB->insert('glpi_documents_items', [
                'documents_id' => (int) $row['documents_id'],
                'items_id'     => $new_id,
                'itemtype'     => 'Ticket',
                'entities_id'  => (int) $row['entities_id'],
                'is_recursive' => (int) $row['is_recursive'],
                'date_mod'     => $row['date_mod'],
            ]);
        }
    }

    /**
     * Return requesters from a ticket.
     *
     * @param int $tickets_id Ticket ID
     * @param int $type       Actor type
     *
     * @return array
     */
    private static function getTicketUsers(int $tickets_id, int $type): array
    {
        $ticket_user = new Ticket_User();
        $rows = $ticket_user->find([
            'tickets_id' => $tickets_id,
            'type'       => $type,
        ]);

        $users = [];
        $user = new User();
        foreach ($rows as $row) {
            $name = '';
            if ($user->getFromDB((int) $row['users_id'])) {
                $name = formatUserName((int) $row['users_id'], $user->fields['name'] ?? '', $user->fields['realname'] ?? '', $user->fields['firstname'] ?? '');
            }
            $users[] = [
                'id'   => (int) $row['users_id'],
                'name' => $name,
            ];
        }

        return $users;
    }

    /**
     * Return first requester ID.
     *
     * @param int $tickets_id Ticket ID
     *
     * @return int
     */
    private static function getFirstRequesterId(int $tickets_id): int
    {
        $requesters = self::getTicketUsers($tickets_id, CommonITILActor::REQUESTER);
        return (int) ($requesters[0]['id'] ?? 0);
    }

    /**
     * Boolean parser for user input.
     *
     * @param array  $input Request input
     * @param string $key   Key
     *
     * @return bool
     */
    private static function boolFromInput(array $input, string $key): bool
    {
        if (!array_key_exists($key, $input)) {
            return false;
        }

        return in_array($input[$key], [1, '1', true, 'true', 'on', 'yes'], true);
    }

    /**
     * Return native GLPI ticket link type constant.
     *
     * @return int
     */
    private static function getNativeLinkType(): int
    {
        if (defined('CommonITILObject_CommonITILObject::LINK_TO')) {
            return constant('CommonITILObject_CommonITILObject::LINK_TO');
        }
        if (defined('Ticket_Ticket::LINK_TO')) {
            return constant('Ticket_Ticket::LINK_TO');
        }

        return 1;
    }

    /**
     * Return issues that would prevent auto-closing a parent ticket.
     *
     * ⚠️ NÃO FAZ CHECAGEM DE DIREITO. Usa `getFromDB()` direto e devolve metadados de
     * completude de QUALQUER chamado, de qualquer entidade. É intencional: os dois chamadores
     * legítimos já autorizaram antes —
     *   - `checkParentCloseabilityForChild()` exige `can(READ)` no filho;
     *   - `handleTicketUpdate()` roda dentro da atualização de um chamado do próprio usuário.
     * Qualquer chamador NOVO precisa autorizar por conta própria antes de chamar. Foi
     * exatamente a ausência dessa checagem no endpoint `check_parent_issues` que virou achado
     * de segurança.
     *
     * @param int $parent_id Parent ticket ID
     *
     * @return array Human-readable issue strings (empty = no issues)
     */
    public static function getParentAutoCloseIssues(int $parent_id): array
    {
        $parent = new Ticket();
        if (!$parent->getFromDB($parent_id)) {
            return [];
        }

        $issues = [];

        $techCount = countElementsInTable('glpi_tickets_users', [
            'tickets_id' => $parent_id,
            'type'       => CommonITILActor::ASSIGN,
        ]);
        if (!$techCount) {
            $issues[] = __s('Sem técnico atribuído', 'subticket');
        }

        $groupCount = countElementsInTable('glpi_groups_tickets', [
            'tickets_id' => $parent_id,
            'type'       => CommonITILActor::ASSIGN,
        ]);
        if (!$groupCount) {
            $issues[] = __s('Sem grupo atribuído', 'subticket');
        }

        if (!(int) ($parent->fields['itilcategories_id'] ?? 0)) {
            $issues[] = __s('Sem categoria definida', 'subticket');
        }

        if (!(int) ($parent->fields['locations_id'] ?? 0)) {
            $issues[] = __s('Sem localização definida', 'subticket');
        }

        return $issues;
    }

    /**
     * Registra na sessão o consentimento explícito do técnico para ignorar as travas de
     * fechamento automático do chamado PAI — vinculado a UM chamado e com validade curta.
     *
     * Antes era um GET sem CSRF e sem checagem de direito: bastava um `<img src=...>` na
     * descrição de um chamado (o sanitizador do GLPI preserva src relativo) para armar a
     * flag na sessão de qualquer técnico que abrisse aquele chamado. Agora o endpoint é POST
     * (CSRF validado pelo CheckCsrfListener) e este método exige UPDATE sobre o chamado e a
     * existência real de um pai com pendências.
     *
     * @param int $tickets_id Chamado filho que está prestes a ser solucionado
     *
     * @return array {success, message?}
     */
    public static function armBypassWaiting(int $tickets_id): array
    {
        if ($tickets_id <= 0) {
            return ['success' => false, 'message' => __s('Chamado inválido.', 'subticket')];
        }

        $ticket = new Ticket();
        if (!$ticket->getFromDB($tickets_id) || !$ticket->can($tickets_id, UPDATE)) {
            return ['success' => false, 'message' => __s('Você não tem permissão para alterar este chamado.', 'subticket')];
        }

        // Sem pai com auto_close_parent=1 E com pendências, não existe trava a ignorar:
        // recusar aqui impede que a flag seja armada em contexto que não a justifica.
        $check = self::checkParentCloseabilityForChild($tickets_id);
        if (empty($check['has_issues'])) {
            return [
                'success' => false,
                'message' => __s('Este chamado não possui chamado de origem com pendências de fechamento.', 'subticket'),
            ];
        }

        $_SESSION['plugin_subticket']['bypass_waiting'] = [
            'tickets_id' => $tickets_id,
            'time'       => time(),
        ];

        return ['success' => true];
    }

    /**
     * Lê o consentimento de bypass e o remove da sessão — uso único, vinculado ao chamado.
     *
     * O bug antigo: a flag era lida/limpa depois dos early returns de handleTicketUpdate
     * (plugin desativado, guard auto_closing, status não solucionado), então ficava armada
     * indefinidamente e era gasta no primeiro chamado que a pessoa fechasse depois, em outro
     * contexto. Aqui a leitura é a primeira coisa que handleTicketUpdate faz e só casa com o
     * chamado para o qual foi armada.
     *
     * @param int $tickets_id Chamado sendo atualizado agora
     *
     * @return bool
     */
    private static function consumeBypassWaiting(int $tickets_id): bool
    {
        $stored = $_SESSION['plugin_subticket']['bypass_waiting'] ?? null;

        if ($stored === null) {
            return false;
        }

        if (!is_array($stored)) {
            // Formato legado (bool) de sessões abertas antes desta versão: descartar.
            unset($_SESSION['plugin_subticket']['bypass_waiting']);
            return false;
        }

        if ((int) ($stored['tickets_id'] ?? 0) !== $tickets_id) {
            return false;
        }

        unset($_SESSION['plugin_subticket']['bypass_waiting']);

        return (time() - (int) ($stored['time'] ?? 0)) <= self::BYPASS_WAITING_TTL;
    }

    /**
     * Check if a ticket (as child) has a parent with auto_close_parent=1 and pending issues.
     *
     * AUTORIZAÇÃO — duas decisões diferentes, de propósito:
     *
     * 1. **Exige `can(READ)` no FILHO.** Sem isso, qualquer usuário central varria ids
     *    arbitrários e obtinha metadados de completude de chamados de outras entidades
     *    (mesmo padrão BOLA fechado em getSubticketStatusMap). Este é o portão real: ele
     *    prende a consulta a um chamado que a pessoa já enxerga.
     *
     * 2. **NÃO exige `can(READ)` no PAI**, e isso é deliberado:
     *    - a mesma informação já chega a este mesmo usuário pelo caminho legítimo, sem
     *      checagem nenhuma: ao solucionar o filho, handleTicketUpdate() dispara
     *      `Session::addMessageAfterRedirect('Chamado PAI #%d não foi fechado
     *      automaticamente: %s')` com o id do pai E a lista de pendências. Barrar aqui e
     *      manter lá seria teatro;
     *    - `auto_close_parent = 1` é, pela regra de negócio do produto, a autorização
     *      explícita do dono do pai para esse acoplamento — o pai optou por ser fechado
     *      por este filho;
     *    - barrar quebraria o aviso exatamente quando ele é útil: o técnico do filho
     *      solucionaria sem saber por que o pai não fechou junto.
     *
     * 3. **Degradação aplicada:** `parent_id` saiu da resposta. O cliente nunca o usou (o
     *    modal de aviso só lê `has_issues` e `issues`), então devolvê-lo era entregar um
     *    identificador de objeto de outra entidade a troco de nada.
     *
     * @param int $tickets_id Child ticket ID
     *
     * @return array {has_issues, issues[]}
     */
    public static function checkParentCloseabilityForChild(int $tickets_id): array
    {
        /** @var DBmysql $DB */
        global $DB;

        if ($tickets_id <= 0) {
            return ['has_issues' => false];
        }

        $child = new Ticket();
        if (!$child->can($tickets_id, READ)) {
            return ['has_issues' => false];
        }

        $link = $DB->request([
            'SELECT' => ['tickets_id_parent'],
            'FROM'   => 'glpi_plugin_subticket_links',
            'WHERE'  => ['tickets_id_child' => $tickets_id, 'auto_close_parent' => 1],
            'LIMIT'  => 1,
        ])->current();

        if (!$link) {
            return ['has_issues' => false];
        }

        $issues = self::getParentAutoCloseIssues((int) $link['tickets_id_parent']);

        if (empty($issues)) {
            return ['has_issues' => false];
        }

        return [
            'has_issues' => true,
            'issues'     => array_values($issues),
        ];
    }

    /**
     * Mirror a follow-up added to a child ticket onto its parent.
     * If the parent is in WAITING status, its status is preserved after mirroring.
     *
     * @param ITILFollowup $followup Added follow-up
     *
     * @return bool
     */
    public static function handleFollowupAdd(ITILFollowup $followup): bool
    {
        /** @var DBmysql $DB */
        global $DB;

        if (isset($_SESSION['plugin_subticket']['mirroring_followup'])) {
            return true;
        }

        if (($followup->fields['itemtype'] ?? '') !== 'Ticket') {
            return true;
        }

        $child_id = (int) ($followup->fields['items_id'] ?? 0);
        if (!$child_id) {
            return true;
        }

        $link = $DB->request([
            'SELECT' => ['tickets_id_parent', 'relation_type'],
            'FROM'   => 'glpi_plugin_subticket_links',
            'WHERE'  => ['tickets_id_child' => $child_id, 'mirror_followups' => 1],
            'LIMIT'  => 1,
        ])->current();

        if (!$link) {
            return true;
        }

        $parent_id = (int) $link['tickets_id_parent'];

        $parent = new Ticket();
        if (!$parent->getFromDB($parent_id)) {
            return true;
        }
        $parent_was_waiting = ((int) $parent->fields['status']) === CommonITILObject::WAITING;

        // Build origin tag: "Comentário do Subticket / Chamado Relacionado #ID — Título" with link
        /** @var array $CFG_GLPI */
        global $CFG_GLPI;
        $child = new Ticket();
        $child->getFromDB($child_id);
        $child_num   = sprintf('%010d', $child_id);
        $child_title = $child->fields['name'] ?? '';
        $child_url   = ($CFG_GLPI['root_doc'] ?? '') . '/front/ticket.form.php?id=' . $child_id;
        $label_template = ($link['relation_type'] ?? '') === self::TYPE_SUBTICKET
            ? __('Comentário do Subticket #%s — %s', 'subticket')
            : __('Comentário do Chamado Relacionado #%s — %s', 'subticket');
        $origin_label = sprintf($label_template, $child_num, $child_title);
        $origin_tag = '<p style="margin:0 0 8px 0;">'
            . '<a href="' . htmlspecialchars($child_url, ENT_QUOTES | ENT_HTML5) . '" target="_blank"'
            . ' style="display:inline-block;background:#e8f1f8;border:1px solid #b0cfe0;border-radius:4px;'
            . 'padding:2px 10px;font-size:0.82em;color:#2c5f7a;font-weight:600;text-decoration:none;">'
            . '&#128279; ' . htmlspecialchars($origin_label, ENT_QUOTES | ENT_HTML5)
            . '</a></p>';
        $mirrored_content = $origin_tag . ($followup->fields['content'] ?? '');

        $_SESSION['plugin_subticket']['mirroring_followup'] = true;

        $mirror = new ITILFollowup();
        $mirror->add([
            'itemtype'        => 'Ticket',
            'items_id'        => $parent_id,
            'content'         => $mirrored_content,
            'is_private'      => (int) ($followup->fields['is_private'] ?? 0),
            'requesttypes_id' => (int) ($followup->fields['requesttypes_id'] ?? 0),
            'users_id'        => (int) ($followup->fields['users_id'] ?? 0),
        ]);

        unset($_SESSION['plugin_subticket']['mirroring_followup']);

        // Preserve WAITING status — adding a follow-up may transition it away from pending
        if ($parent_was_waiting) {
            $parent_after = new Ticket();
            $parent_after->getFromDB($parent_id);
            if ((int) $parent_after->fields['status'] !== CommonITILObject::WAITING) {
                // Via ORM, não $DB->update() cru: o UPDATE direto não atualizava `date_mod`
                // nem gravava Log::history, deixando a mudança de status invisível no
                // histórico do chamado. `_disablenotif` porque, do ponto de vista do usuário,
                // o chamado não mudou de estado — ele já estava Pendente e só está sendo
                // devolvido ao estado que o espelhamento de comentário tirou dele.
                // Guard auto_closing para o hook item_update não reentrar; o status WAITING
                // já cairia no early return de handleTicketUpdate, isto é cinto e suspensório.
                $was_guarded = isset($_SESSION['plugin_subticket']['auto_closing']);
                if (!$was_guarded) {
                    $_SESSION['plugin_subticket']['auto_closing'] = true;
                }

                $parent_after->update([
                    'id'             => $parent_id,
                    'status'         => CommonITILObject::WAITING,
                    '_disablenotif'  => true,
                ]);

                if (!$was_guarded) {
                    unset($_SESSION['plugin_subticket']['auto_closing']);
                }
            }
        }

        return true;
    }

    /**
     * Critérios de recorte do chamado PAI (alias `sbt_parent`) para a query de badges.
     *
     * Padrão copiado do operationalkanban (`operationalkanban/inc/kanban.class.php:672-731`),
     * de propósito: o badge só faz sentido se o recorte COINCIDIR com o do quadro. Recorte
     * mais estreito faria badges sumirem de cards que o técnico legitimamente vê — trocaria
     * vazamento por regressão diária.
     *
     * Duas camadas, ambas em SQL (nada de `can()` em laço — seriam até MAX_STATUS_IDS
     * chamadas por lote):
     *  1. entidade: getEntitiesRestrictCriteria(..., false) — `glpi_tickets` não tem
     *     `is_recursive`; as subentidades já vêm materializadas em `glpiactiveentities`.
     *  2. visibilidade: Ticket::buildCanViewCondition() (glpi/src/Ticket.php:5658), o mesmo
     *     motor que o core usa na busca. Envolvido em `(0 = 1 ...)` porque a convenção da
     *     função é devolver cada cláusula prefixada por `OR ` — sem nenhum direito aplicável
     *     a condição inteira vale false (fail-closed).
     *
     * `is_deleted` NÃO é filtrado: `can(READ)`/getChildrenForParent() também não filtram, e
     * filtrar aqui faria o badge sumir na lixeira enquanto o modal continuaria abrindo.
     *
     * @return array Lista de critérios prontos para `$where[] = ...`
     */
    private static function getParentScopeCriteria(): array
    {
        $criteria = [];

        if ((int) Session::getLoginUserID() <= 0) {
            return [new QueryExpression('0 = 1')];
        }

        $criteria[] = getEntitiesRestrictCriteria('sbt_parent', 'entities_id', '', false);

        if (Session::haveRight('ticket', Ticket::READALL)) {
            return $criteria;
        }

        if (!isset($_SESSION['glpigroups']) || !is_array($_SESSION['glpigroups'])) {
            // Sessão sem grupos carregados: buildCanViewCondition faria implode() em null.
            return [new QueryExpression('0 = 1')];
        }

        $criteria[] = new QueryExpression(
            '(0 = 1 ' . Ticket::buildCanViewCondition('sbt_parent`.`id') . ')'
        );

        return $criteria;
    }

    /**
     * Return subticket count and worst-priority status for a list of parent ticket IDs.
     * Only considers links with relation_type = 'subticket' (not related tickets).
     *
     * @param int[] $parent_ids Parent ticket IDs to query
     *
     * @return array Map of parent_id => ['count' => int, 'worst_status' => int]
     */
    public static function getLinkStatusMaps(array $parent_ids): array
    {
        return [
            self::TYPE_SUBTICKET => self::getSubticketStatusMap($parent_ids, self::TYPE_SUBTICKET),
            self::TYPE_RELATED   => self::getSubticketStatusMap($parent_ids, self::TYPE_RELATED),
        ];
    }

    public static function getSubticketStatusMap(array $parent_ids, string $relation_type = self::TYPE_SUBTICKET): array
    {
        /** @var DBmysql $DB */
        global $DB;

        if (empty($parent_ids)) {
            return [];
        }

        $where = [
            'glpi_plugin_subticket_links.tickets_id_parent' => $parent_ids,
            'glpi_plugin_subticket_links.relation_type'     => $relation_type,
        ];

        // Recorte aplicado ao chamado PAI (o card que recebe o badge), não aos filhos:
        // é o pai que o técnico está enxergando na lista/kanban, e é o mesmo recorte que
        // getChildrenForParent() usa ao abrir o modal — badge e modal precisam concordar.
        // Sem isto, um POST/GET forjado com ids arbitrários enumera a instância inteira
        // (existe? quantos subtickets? pior status?) em lotes de até MAX_STATUS_IDS.
        foreach (self::getParentScopeCriteria() as $criteria) {
            $where[] = $criteria;
        }

        $rows = $DB->request([
            'SELECT'     => [
                'glpi_plugin_subticket_links.tickets_id_parent',
                'glpi_tickets.status',
                new QueryExpression('COUNT(`glpi_plugin_subticket_links`.`id`) AS `cnt`'),
            ],
            'FROM'       => 'glpi_plugin_subticket_links',
            'INNER JOIN' => [
                'glpi_tickets' => [
                    'FKEY' => [
                        'glpi_tickets'                  => 'id',
                        'glpi_plugin_subticket_links'   => 'tickets_id_child',
                    ],
                ],
                // Segundo join na MESMA tabela, com alias, só para poder filtrar o pai.
                'glpi_tickets AS sbt_parent' => [
                    'FKEY' => [
                        'sbt_parent'                    => 'id',
                        'glpi_plugin_subticket_links'   => 'tickets_id_parent',
                    ],
                ],
            ],
            'WHERE'   => $where,
            'GROUPBY' => [
                'glpi_plugin_subticket_links.tickets_id_parent',
                'glpi_tickets.status',
            ],
        ]);

        // Lower number = more urgent (worst for parent owner to see)
        $priority = [
            CommonITILObject::INCOMING => 1,
            CommonITILObject::ASSIGNED => 2,
            CommonITILObject::PLANNED  => 2,
            CommonITILObject::WAITING  => 3,
            CommonITILObject::SOLVED   => 4,
            CommonITILObject::CLOSED   => 5,
        ];

        $map = [];
        foreach ($rows as $row) {
            $pid    = (int) $row['tickets_id_parent'];
            $status = (int) $row['status'];
            $cnt    = (int) $row['cnt'];

            if (!isset($map[$pid])) {
                $map[$pid] = ['count' => 0, 'worst_status' => $status];
            }
            $map[$pid]['count'] += $cnt;

            $cur_prio = $priority[$map[$pid]['worst_status']] ?? 99;
            $new_prio = $priority[$status] ?? 99;
            if ($new_prio < $cur_prio) {
                $map[$pid]['worst_status'] = $status;
            }
        }

        return $map;
    }

    /**
     * Return the list of subtickets (id, name, status) linked to a parent ticket.
     *
     * @param int $parent_id Parent ticket ID
     *
     * @return array {success, children: [{id, title, status}]}
     */
    public static function getChildrenForParent(int $parent_id, string $relation_type = self::TYPE_SUBTICKET): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $ticket = new Ticket();
        if (!$ticket->can($parent_id, READ)) {
            return ['success' => false, 'children' => []];
        }

        $rows = $DB->request([
            'SELECT' => [
                'glpi_tickets.id',
                'glpi_tickets.name',
                'glpi_tickets.status',
            ],
            'FROM'       => 'glpi_plugin_subticket_links',
            'INNER JOIN' => [
                'glpi_tickets' => [
                    'FKEY' => [
                        'glpi_tickets'                => 'id',
                        'glpi_plugin_subticket_links' => 'tickets_id_child',
                    ],
                ],
            ],
            'WHERE' => [
                'glpi_plugin_subticket_links.tickets_id_parent' => $parent_id,
                'glpi_plugin_subticket_links.relation_type'     => $relation_type,
            ],
            'ORDER' => ['glpi_tickets.id ASC'],
        ]);

        $children = [];
        foreach ($rows as $row) {
            $children[] = [
                'id'     => (int) $row['id'],
                'title'  => $row['name'],
                'status' => (int) $row['status'],
            ];
        }

        return ['success' => true, 'children' => $children];
    }

    /**
     * Handle ticket update to close configured children.
     *
     * @param Ticket $ticket Updated ticket
     *
     * @return bool
     */
    public static function handleTicketUpdate(Ticket $ticket): bool
    {
        /** @var DBmysql $DB */
        global $DB;

        // Consumido ANTES de qualquer early return: se ficar para depois, os returns abaixo
        // deixam a flag armada na sessão e ela é gasta no próximo chamado fechado.
        $bypass_waiting = self::consumeBypassWaiting((int) $ticket->getID());

        $config = PluginSubticketConfig::getConfig();
        if (!(int) ($config['is_active'] ?? 1)) {
            return true;
        }

        if (isset($_SESSION['plugin_subticket']['auto_closing'])) {
            return true;
        }

        $status = (int) ($ticket->input['status'] ?? $ticket->fields['status'] ?? 0);
        if (!in_array($status, [CommonITILObject::SOLVED, CommonITILObject::CLOSED], true)) {
            return true;
        }

        $child_rows = $DB->request([
            'FROM'  => 'glpi_plugin_subticket_links',
            'WHERE' => [
                'tickets_id_parent' => (int) $ticket->getID(),
                'auto_close'        => 1,
            ],
        ]);

        $parent_links = $DB->request([
            'FROM'  => 'glpi_plugin_subticket_links',
            'WHERE' => ['tickets_id_child' => (int) $ticket->getID()],
        ]);

        $_SESSION['plugin_subticket']['auto_closing'] = true;

        // Close children configured for auto-close
        $child = new Ticket();
        foreach ($child_rows as $row) {
            $child_id = (int) $row['tickets_id_child'];
            if (!$child_id || !$child->getFromDB($child_id)) {
                continue;
            }
            if (in_array((int) $child->fields['status'], [CommonITILObject::SOLVED, CommonITILObject::CLOSED], true)) {
                continue;
            }

            self::solveTicketFromRelated(
                $child_id,
                (int) $ticket->getID(),
                $status,
                (string) ($row['relation_type'] ?? self::TYPE_SUBTICKET),
                true
            );
        }

        // When this ticket is a subticket child: notify parent and/or close parent
        $parent = new Ticket();
        foreach ($parent_links as $link) {
            $parent_id = (int) $link['tickets_id_parent'];
            $link_type = (string) ($link['relation_type'] ?? self::TYPE_SUBTICKET);
            $do_notify = (int) $link['notify_parent_on_close'] === 1;
            $do_close  = (int) $link['auto_close_parent'] === 1;

            if ($do_close && $parent->getFromDB($parent_id)) {
                $parent_status = (int) $parent->fields['status'];

                if (!in_array($parent_status, [CommonITILObject::SOLVED, CommonITILObject::CLOSED], true)) {
                    $issues = $bypass_waiting ? [] : self::getParentAutoCloseIssues($parent_id);

                    if (!empty($issues)) {
                        if ($do_notify) {
                            self::addChildClosedFollowup($parent_id, (int) $ticket->getID(), $status, $link_type);
                        }
                        Session::addMessageAfterRedirect(sprintf(
                            __s('Chamado PAI #%d não foi fechado automaticamente: %s', 'subticket'),
                            $parent_id,
                            implode('; ', $issues)
                        ), false, WARNING);
                    } else {
                        $parent_is_waiting = $parent_status === CommonITILObject::WAITING;

                        if ($parent_is_waiting) {
                            if ($do_notify) {
                                // Piggyback pending=0 onto the notify followup — single comment, no duplicate.
                                $_SESSION['plugin_subticket']['mirroring_followup'] = true;
                                self::addChildClosedFollowup($parent_id, (int) $ticket->getID(), $status, $link_type, true);
                                unset($_SESSION['plugin_subticket']['mirroring_followup']);
                            } else {
                                // No notify comment: add a minimal followup just to unblock the pending state.
                                $_SESSION['plugin_subticket']['mirroring_followup'] = true;
                                $unblock = new ITILFollowup();
                                $unblock->add([
                                    'itemtype'        => Ticket::class,
                                    'items_id'        => $parent_id,
                                    'users_id'        => Session::getLoginUserID(),
                                    'content'         => sprintf('Subticket #%d solucionado. Pendente removida automaticamente.', (int) $ticket->getID()),
                                    'is_private'      => 1,
                                    'requesttypes_id' => 6,
                                    'pending'         => 0,
                                ]);
                                unset($_SESSION['plugin_subticket']['mirroring_followup']);
                            }
                            $parent->getFromDB($parent_id);
                        } elseif ($do_notify) {
                            self::addChildClosedFollowup($parent_id, (int) $ticket->getID(), $status, $link_type);
                        }

                        self::solveTicketFromRelated(
                            $parent_id,
                            (int) $ticket->getID(),
                            $status,
                            $link_type,
                            false
                        );
                    }
                }
            } elseif ($do_notify) {
                self::addChildClosedFollowup($parent_id, (int) $ticket->getID(), $status, $link_type);
            }
        }

        unset($_SESSION['plugin_subticket']['auto_closing']);

        return true;
    }
}
