<?php

/**
 * Configuration class for Subticket plugin.
 */
class PluginSubticketConfig extends CommonDBTM
{
    public static function getTypeName($nb = 0)
    {
        return __s('Configuração do Subticket', 'subticket');
    }

    public static function getMenuName()
    {
        return __s('Subticket', 'subticket');
    }

    public static function getIcon()
    {
        return 'ti ti-subtask';
    }

    public static function getTable($classname = null)
    {
        return 'glpi_plugin_subticket_configs';
    }

    public static function getSearchURL($full = true)
    {
        return '/plugins/subticket/front/config.form.php';
    }

    /**
     * Load configuration row into session.
     *
     * @return void
     */
    public static function loadInSession(): void
    {
        if (!isset($_SESSION['glpi_plugins'])) {
            $_SESSION['glpi_plugins'] = [];
        }
        if (!isset($_SESSION['glpi_plugins']['subticket'])) {
            $_SESSION['glpi_plugins']['subticket'] = [];
        }

        $config = new self();
        if (!$config->getFromDB(1)) {
            $_SESSION['glpi_plugins']['subticket']['config'] = self::getDefaultConfig();
            return;
        }

        $_SESSION['glpi_plugins']['subticket']['config'] = array_merge(
            self::getDefaultConfig(),
            $config->fields
        );
    }

    /**
     * Return current plugin configuration.
     *
     * @return array
     */
    public static function getConfig(): array
    {
        if (!isset($_SESSION['glpi_plugins']['subticket']['config'])) {
            self::loadInSession();
        }

        return $_SESSION['glpi_plugins']['subticket']['config'] ?? self::getDefaultConfig();
    }

    /**
     * Default configuration values.
     *
     * @return array
     */
    public static function getDefaultConfig(): array
    {
        return [
            'id'                            => 1,
            'is_active'                     => 1,
            'default_auto_close_related'    => 0,
            'default_auto_close_subticket'  => 0,
            'default_auto_close_parent'         => 0,
            'default_notify_parent_on_close'    => 0,
            'copy_documents_by_default'         => 0,
        ];
    }

    /**
     * Display plugin configuration form.
     *
     * @param int   $ID      Configuration ID
     * @param array $options Options
     *
     * @return bool
     */
    public function showForm($ID, array $options = [])
    {
        if (!$this->getFromDB(1)) {
            $this->fields = self::getDefaultConfig();
        }

        /** @var array $CFG_GLPI */
        global $CFG_GLPI;
        echo "<form method='post' action='" . htmlspecialchars($CFG_GLPI['root_doc'] . '/plugins/subticket/front/config.form.php') . "'>";
        echo "<div class='card'>";
        echo "<div class='card-header'><h3 class='card-title'>" . __s('Configuração do Subticket', 'subticket') . "</h3></div>";
        echo "<div class='card-body'>";

        $fields = [
            'is_active'                    => [
                'label'   => __s('Exibir botão Subticket nos chamados', 'subticket'),
                'value'   => (int) ($this->fields['is_active'] ?? 1),
            ],
            'default_auto_close_related'   => [
                'label'   => __s('Fechar ticket relacionado automaticamente por padrão', 'subticket'),
                'value'   => (int) ($this->fields['default_auto_close_related'] ?? 0),
            ],
            'default_auto_close_subticket' => [
                'label'   => __s('Fechar subticket automaticamente por padrão', 'subticket'),
                'value'   => (int) ($this->fields['default_auto_close_subticket'] ?? 0),
            ],
            'default_auto_close_parent'         => [
                'label'   => __s('Fechar chamado pai automaticamente por padrão', 'subticket'),
                'value'   => (int) ($this->fields['default_auto_close_parent'] ?? 0),
            ],
            'default_notify_parent_on_close'    => [
                'label'   => __s('Notificar chamado pai ao fechar subticket por padrão', 'subticket'),
                'value'   => (int) ($this->fields['default_notify_parent_on_close'] ?? 0),
            ],
            'copy_documents_by_default'         => [
                'label'   => __s('Copiar documentos por padrão', 'subticket'),
                'value'   => (int) ($this->fields['copy_documents_by_default'] ?? 0),
            ],
        ];

        foreach ($fields as $name => $field) {
            echo "<div class='row mb-3 align-items-center'>";
            echo "<label class='col-md-6 col-form-label'>" . $field['label'] . "</label>";
            echo "<div class='col-md-3'>";
            Dropdown::showYesNo($name, $field['value'], -1, ['display_emptychoice' => false]);
            echo "</div>";
            echo "</div>";
        }

        echo "</div>";
        echo "<div class='card-footer'>";
        echo Html::hidden('id', ['value' => 1]);
        echo Html::submit(__s('Salvar', 'subticket'), ['name' => 'update', 'class' => 'btn btn-primary']);
        echo "</div>";
        echo "</div>";
        Html::closeForm();

        return true;
    }
}
