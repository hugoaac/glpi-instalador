<?php

/**
 * Configuration form for Subticket plugin.
 */

include('../../../inc/includes.php');

Session::checkRight('config', UPDATE);

Html::header(
    __s('Subticket', 'subticket'),
    $_SERVER['PHP_SELF'],
    'admin',
    PluginSubticketConfig::class
);

$config = new PluginSubticketConfig();

if (isset($_POST['update'])) {
    $input = [
        'id'                            => 1,
        'is_active'                     => (int) ($_POST['is_active'] ?? 0),
        'default_auto_close_related'    => (int) ($_POST['default_auto_close_related'] ?? 0),
        'default_auto_close_subticket'  => (int) ($_POST['default_auto_close_subticket'] ?? 0),
        'default_auto_close_parent'         => (int) ($_POST['default_auto_close_parent'] ?? 0),
        'default_notify_parent_on_close'    => (int) ($_POST['default_notify_parent_on_close'] ?? 0),
        'copy_documents_by_default'         => (int) ($_POST['copy_documents_by_default'] ?? 0),
    ];

    if ($config->getFromDB(1)) {
        $config->update($input);
    } else {
        $config->add($input);
    }

    PluginSubticketConfig::loadInSession();
    Session::addMessageAfterRedirect(__s('Configuração salva com sucesso.', 'subticket'));
    Html::redirect($_SERVER['PHP_SELF']);
}

$config->showForm(1);

Html::footer();
