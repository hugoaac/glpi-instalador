<?php

/**
 * JavaScript entrypoint for Subticket plugin.
 */

header('Content-Type: application/javascript; charset=UTF-8');
Html::header_nocache();

if (!defined('GLPI_ROOT')) {
    include(dirname(__FILE__, 5) . '/inc/includes.php');
}

Session::checkLoginUser();

if (
    ($_SESSION['glpiactiveprofile']['interface'] ?? '') !== 'central'
    || !Session::haveRight('ticket', CREATE)
    || !Session::haveRight('ticket', UPDATE)
) {
    exit;
}

$config = PluginSubticketConfig::getConfig();
if (!(int) ($config['is_active'] ?? 1)) {
    exit;
}

$default_auto_close_related   = (int) ($config['default_auto_close_related'] ?? 0);
$default_auto_close_subticket = (int) ($config['default_auto_close_subticket'] ?? 0);
$default_auto_close_parent        = (int) ($config['default_auto_close_parent'] ?? 0);
$default_notify_parent_on_close   = (int) ($config['default_notify_parent_on_close'] ?? 0);
$default_mirror_followups         = (int) ($config['default_mirror_followups'] ?? 0);
$copy_documents_by_default        = (int) ($config['copy_documents_by_default'] ?? 0);
$current_user_id                  = (int) Session::getLoginUserID();

/** @var DBmysql $DB */
global $DB;

$request_types = [];
foreach ($DB->request([
    'SELECT' => ['id', 'name'],
    'FROM'   => 'glpi_requesttypes',
    'WHERE'  => ['is_active' => 1],
    'ORDER'  => 'name ASC',
]) as $row) {
    $request_types[] = ['id' => (int) $row['id'], 'name' => $row['name']];
}

$categories = [];
foreach ($DB->request([
    'SELECT' => ['id', 'completename', 'name'],
    'FROM'   => 'glpi_itilcategories',
    'WHERE'  => getEntitiesRestrictCriteria('glpi_itilcategories') + [
        'OR' => [
            'is_incident' => 1,
            'is_request'  => 1,
        ],
    ],
    'ORDER'  => 'completename ASC',
]) as $row) {
    $categories[] = ['id' => (int) $row['id'], 'name' => ($row['completename'] ?: $row['name'])];
}

$locations = [];
foreach ($DB->request([
    'SELECT' => ['id', 'completename', 'name'],
    'FROM'   => 'glpi_locations',
    'WHERE'  => getEntitiesRestrictCriteria('glpi_locations'),
    'ORDER'  => 'completename ASC',
]) as $row) {
    $locations[] = ['id' => (int) $row['id'], 'name' => ($row['completename'] ?: $row['name'])];
}

// A lista de usuarios NAO e mais serializada aqui. Ela era a base inteira (~5,8 mil
// usuarios / ~270 KB) embutida no corpo deste JS em TODA abertura de ticket.form.php, com a
// modal aberta ou nao. Agora a busca vai ao servidor sob demanda, com o termo digitado:
// PluginSubticketTicket::searchUsers() -> ajax/ticket.php?action=search_users.
// Assim o login/matricula volta a ser pesquisavel (como no dropdown nativo do GLPI) sem que
// a instancia inteira trafegue para o navegador.
//
// So o nome do usuario logado continua vindo daqui: refreshMode() o usa para pre-preencher o
// requerente no modo Subticket, e seria absurdo fazer uma requisicao para descobrir isso.
$current_user_name = '';
$current_user_obj  = new User();
if ($current_user_id > 0 && $current_user_obj->getFromDB($current_user_id)) {
    $current_user_name = formatUserName(
        $current_user_id,
        $current_user_obj->fields['name'] ?? '',
        $current_user_obj->fields['realname'] ?? '',
        $current_user_obj->fields['firstname'] ?? ''
    );
}

$labels = [
    'subticket'           => __s('Subticket', 'subticket'),
    'create'              => __s('Criar chamado', 'subticket'),
    'related'             => __s('Ticket relacionado', 'subticket'),
    'child'               => __s('Subticket', 'subticket'),
    'error'               => __s('Erro ao processar solicitação.', 'subticket'),
    'cancel'              => __s('Cancelar', 'subticket'),
    'type_creation'       => __s('Tipo de criação', 'subticket'),
    'type_help'           => __s('O ticket relacionado copia as principais informações por padrão; o subticket permite escolher campo a campo.', 'subticket'),
    'auto_close_label'    => __s('Fechar este chamado automaticamente', 'subticket'),
    'copy_docs_label'     => __s('Copiar documentos anexados', 'subticket'),
    'copy_panel_title'    => __s('Informações a copiar do chamado principal', 'subticket'),
    'field_name'          => __s('Título', 'subticket'),
    'field_content'       => __s('Descrição', 'subticket'),
    'field_requester'     => __s('Requerente', 'subticket'),
    'field_category'      => __s('Categoria', 'subticket'),
    'field_type'          => __s('Tipo', 'subticket'),
    'field_location'      => __s('Localização', 'subticket'),
    'field_origin'        => __s('Origem da requisição', 'subticket'),
    'lbl_title'           => __s('Título', 'subticket'),
    'lbl_requester'       => __s('Requerente', 'subticket'),
    'lbl_description'     => __s('Descrição', 'subticket'),
    'lbl_category'        => __s('Categoria', 'subticket'),
    'lbl_type'            => __s('Tipo', 'subticket'),
    'lbl_origin'          => __s('Origem da requisição', 'subticket'),
    'lbl_location'        => __s('Localização', 'subticket'),
    'no_category'         => __s('(sem categoria)', 'subticket'),
    'no_location'         => __s('(sem localização)', 'subticket'),
    'no_requester'        => __s('(sem requerente)', 'subticket'),
    'no_origin'           => __s('(não definida)', 'subticket'),
    'select_type'                    => __s('Selecione o tipo', 'subticket'),
    'type_required'                  => __s('Informe o tipo do novo chamado (Incidente ou Requisição).', 'subticket'),
    'opt_incident'                   => __s('Incidente', 'subticket'),
    'opt_request'                    => __s('Requisição', 'subticket'),
    'auto_close_parent_label'        => __s('Fechar o chamado de origem automaticamente', 'subticket'),
    'notify_parent_on_close_label'   => __s('Notificar o chamado de origem quando este for solucionado', 'subticket'),
    'mirror_followups_label'         => __s('Espelhar comentários deste chamado no de origem', 'subticket'),
    'section_config'                 => __s('Configurações', 'subticket'),
    'section_fields'                 => __s('Dados do novo chamado', 'subticket'),
    'type_desc_related'              => __s('Chamado independente com contexto em comum. Nenhum bloqueia o fechamento do outro.', 'subticket'),
    'type_desc_subticket'            => __s('Parte deste chamado. O pai só poderá ser fechado quando todos os subtickets forem resolvidos.', 'subticket'),
    'requester_required'             => __s('Informe o requerente do subticket.', 'subticket'),
    'category_required'              => __s('Informe a categoria do subticket.', 'subticket'),
    'parent_warn_title'              => __s('Atenção: Chamado PAI com pendências', 'subticket'),
    'parent_warn_body'               => __s('O Chamado PAI possui pendências que podem impedir o fechamento automático:', 'subticket'),
    'parent_warn_proceed'            => __s('Solucionar mesmo assim', 'subticket'),
    'user_search_hint'               => sprintf(
        __s('Digite ao menos %d caracteres para buscar (nome, login ou matrícula).', 'subticket'),
        PluginSubticketTicket::USER_SEARCH_MIN_CHARS
    ),
    'user_search_loading'            => __s('Buscando…', 'subticket'),
    'user_search_empty'              => __s('Nenhum usuário encontrado.', 'subticket'),
    'user_search_error'              => __s('Erro ao buscar usuários. Tente novamente.', 'subticket'),
    'user_search_truncated'          => __s('Muitos resultados — refine a busca.', 'subticket'),
];

?>
(function () {
   'use strict';

   const pluginUrl                 = CFG_GLPI.root_doc + '/plugins/subticket';
   const defaultAutoCloseRelated   = <?php echo $default_auto_close_related; ?> === 1;
   const defaultAutoCloseSubticket = <?php echo $default_auto_close_subticket; ?> === 1;
   const defaultAutoCloseParent       = <?php echo $default_auto_close_parent; ?> === 1;
   const defaultNotifyParentOnClose   = <?php echo $default_notify_parent_on_close; ?> === 1;
   const defaultMirrorFollowups       = <?php echo $default_mirror_followups; ?> === 1;
   const copyDocumentsByDefault       = <?php echo $copy_documents_by_default; ?> === 1;
   const currentUserId                = <?php echo $current_user_id; ?>;
   const currentUserName              = <?php echo json_encode($current_user_name, JSON_UNESCAPED_UNICODE); ?>;
   const requestTypes              = <?php echo json_encode($request_types, JSON_UNESCAPED_UNICODE); ?>;
   const categories                = <?php echo json_encode($categories,    JSON_UNESCAPED_UNICODE); ?>;
   const locations                 = <?php echo json_encode($locations,     JSON_UNESCAPED_UNICODE); ?>;
   const labels                    = <?php echo json_encode($labels,        JSON_UNESCAPED_UNICODE); ?>;

   // Busca de requerente sob demanda (substitui o dump de usuarios).
   const userSearchMinChars   = <?php echo PluginSubticketTicket::USER_SEARCH_MIN_CHARS; ?>;
   const userSearchDebounceMs = 300;

   function getCsrfToken() {
      return document.querySelector('meta[property="glpi:csrf_token"]')?.content || '';
   }

   function getUrlParameter(name) {
      return new URL(window.location.href).searchParams.get(name);
   }

   function htmlEscape(value) {
      // Escapa TAMBEM as aspas. Este helper e usado dentro de atributos (data-name,
      // data-label, title) e a implementacao anterior, $('<div>').text(v).html(), nao
      // servia ali: a serializacao de um no de texto so troca &, < e >, deixando " e '
      // passarem. Um nome de usuario com aspas -- e o nome vem do banco, via
      // formatUserName() em searchUsers() -- fechava o atributo e virava handler de evento.
      return String(value === null || value === undefined ? '' : value)
         .replace(/&/g, '&amp;')
         .replace(/</g, '&lt;')
         .replace(/>/g, '&gt;')
         .replace(/"/g, '&quot;')
         .replace(/'/g, '&#39;');
   }

   function fetchJSON(url, options) {
      const defaultHeaders = {
         'X-Requested-With': 'XMLHttpRequest',
         'X-Glpi-Csrf-Token': getCsrfToken(),
      };
      const merged = Object.assign({}, options, {
         headers: Object.assign({}, defaultHeaders, options && options.headers),
      });
      return fetch(url, merged).then(function (r) {
         if (!r.ok) { throw new Error('HTTP ' + r.status); }
         return r.json();
      });
   }

   function getTicketId() {
      const id = parseInt(getUrlParameter('id'), 10);
      return Number.isInteger(id) && id > 0 ? id : 0;
   }

   function findActionBar() {
      const mainActions = $('.itil-footer .main-actions, #itil-footer .main-actions').first();
      if (mainActions.length) {
         return mainActions;
      }

      const selectors = [
         '.itil-footer .btn-group',
         '#itil-footer .btn-group',
         '.itil-timeline .d-flex.gap-2',
         '.card-footer .btn-group',
         '#new-itil-object-form .btn-group'
      ];

      for (const selector of selectors) {
         const element = $(selector).first();
         if (element.length) {
            return element;
         }
      }

      const escalateButton = $('button.action-escalation, a.action-escalation').first();
      if (escalateButton.length) {
         return escalateButton.closest('.main-actions, .btn-group, .d-flex').first();
      }

      const footer = $('.itil-footer').first();
      return footer.length ? footer : null;
   }

   function addButton() {
      if ($('#plugin_subticket_button').length || !getTicketId()) {
         return;
      }

      const actionBar = findActionBar();
      if (!actionBar) {
         return;
      }

      const button = $(
         '<button type="button" id="plugin_subticket_button" class="btn btn-primary answer-action plugin-subticket-action" title="' + htmlEscape(labels.subticket) + '">' +
            '<i class="ti ti-subtask me-1"></i>' + htmlEscape(labels.subticket) +
         '</button>'
      );

      actionBar.append(button);
      button.on('click', openModal);
   }

   function buildSelect(id, name, options, cls) {
      cls = cls || 'form-select form-select-sm';
      let html = '<select class="' + cls + '" id="' + id + '" name="' + name + '">';
      options.forEach(function (o) {
         html += '<option value="' + o.value + '">' + htmlEscape(o.label) + '</option>';
      });
      return html + '</select>';
   }

   function buildTypeSelect(id, name) {
      // A opcao vazia existe para que o tipo NAO tenha default. Antes o campo abria com o
      // tipo do chamado de origem e passava batido: chamado que era requisicao nascia
      // Incidente, herdando o SLA errado.
      return buildSelect(id, name, [
         { value: 0, label: labels.select_type },
         { value: 1, label: labels.opt_incident },
         { value: 2, label: labels.opt_request },
      ]);
   }

   function buildOriginSelect(id, name) {
      const opts = [{ value: 0, label: labels.no_origin }];
      requestTypes.forEach(function (rt) { opts.push({ value: rt.id, label: rt.name }); });
      return buildSelect(id, name, opts);
   }

   function buildCombo(selectId, fieldName, placeholder) {
      return '<div class="sbt-combo">' +
         '<div class="form-control sbt-combo-display" id="' + selectId + '_display" tabindex="0">' +
            '<span class="sbt-combo-text sbt-placeholder">' + htmlEscape(placeholder) + '</span>' +
            '<i class="ti ti-chevron-down sbt-combo-arrow"></i>' +
         '</div>' +
         '<input type="hidden" id="' + selectId + '" name="' + fieldName + '" value="0">' +
         '<div class="sbt-combo-panel" id="' + selectId + '_panel">' +
            '<div class="sbt-combo-search-wrap"><input type="text" class="sbt-combo-search" id="' + selectId + '_search" autocomplete="off"></div>' +
            '<div class="sbt-combo-list" id="' + selectId + '_list"></div>' +
         '</div>' +
      '</div>';
   }

   function initCombo(selectId, allItems, placeholder) {
      const $display = $('#' + selectId + '_display');
      const $hidden  = $('#' + selectId);
      const $panel   = $('#' + selectId + '_panel');
      const $search  = $('#' + selectId + '_search');
      const $list    = $('#' + selectId + '_list');
      const $text    = $display.find('.sbt-combo-text');
      let focusedIdx = -1;
      let isOpen     = false;

      function renderList(items) {
         focusedIdx = -1;
         $list.html(items.length
            ? items.map(function (item) {
               return '<div class="sbt-combo-item" data-id="' + item.id + '" data-label="' + htmlEscape(item.label) + '">' + htmlEscape(item.label) + '</div>';
            }).join('')
            : '<div class="sbt-combo-empty">Nenhum resultado</div>'
         );
      }

      function openCombo() {
         if (isOpen || $display.hasClass('bg-light')) return;
         isOpen = true;
         renderList(allItems);
         // Posicionar como fixed relativo ao elemento de disparo
         const rect = $display[0].getBoundingClientRect();
         $panel.css({ top: rect.bottom + 'px', left: rect.left + 'px', width: rect.width + 'px' }).show();
         $display.addClass('open');
         $search.val('').focus();
      }

      function closeCombo() {
         if (!isOpen) return;
         isOpen = false;
         $panel.hide();
         $display.removeClass('open');
         focusedIdx = -1;
      }

      function pickItem(id, label) {
         $hidden.val(id);
         if (parseInt(id) === 0) {
            $text.addClass('sbt-placeholder').text(placeholder);
         } else {
            $text.removeClass('sbt-placeholder').text(label);
         }
         closeCombo();
         $display.focus();
      }

      $display.on('click', function () { isOpen ? closeCombo() : openCombo(); });
      $display.on('keydown', function (e) {
         if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); isOpen ? closeCombo() : openCombo(); }
         else if (e.key === 'Escape') closeCombo();
      });

      $search.on('input', function () {
         const q = this.value.trim().toLowerCase();
         renderList(q ? allItems.filter(function (item) { return item.label.toLowerCase().includes(q); }) : allItems);
      });

      $search.on('keydown', function (e) {
         const $items = $list.find('.sbt-combo-item');
         if (!$items.length) return;
         if (e.key === 'ArrowDown') {
            e.preventDefault();
            focusedIdx = Math.min(focusedIdx + 1, $items.length - 1);
            $items.removeClass('sbt-focused').eq(focusedIdx).addClass('sbt-focused');
            $items.eq(focusedIdx)[0].scrollIntoView({ block: 'nearest' });
         } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            focusedIdx = Math.max(focusedIdx - 1, 0);
            $items.removeClass('sbt-focused').eq(focusedIdx).addClass('sbt-focused');
            $items.eq(focusedIdx)[0].scrollIntoView({ block: 'nearest' });
         } else if (e.key === 'Enter' && focusedIdx >= 0) {
            e.preventDefault();
            const $item = $items.eq(focusedIdx);
            pickItem($item.data('id'), $item.data('label'));
         } else if (e.key === 'Escape') {
            closeCombo();
            $display.focus();
         }
      });

      $search.on('blur', function () { setTimeout(closeCombo, 150); });

      $list.on('mousedown', '.sbt-combo-item', function (e) {
         e.preventDefault();
         pickItem($(this).data('id'), $(this).data('label'));
      });
   }

   function buildRequesterAutocomplete(textId, hiddenId, hiddenName) {
      return '<div class="sbt-autocomplete">' +
         '<input type="text" class="form-control sbt-autocomplete-input" id="' + textId + '" autocomplete="off" placeholder="' + htmlEscape(labels.no_requester) + '">' +
         '<input type="hidden" id="' + hiddenId + '" name="' + hiddenName + '" value="0">' +
         '<div class="sbt-autocomplete-dropdown" id="' + textId + '_dropdown"></div>' +
      '</div>';
   }

   function buildCategorySelect(id, name) {
      const opts = [{ value: 0, label: labels.no_category }];
      categories.forEach(function (c) { opts.push({ value: c.id, label: c.name }); });
      return buildSelect(id, name, opts);
   }

   function buildLocationSelect(id, name) {
      const opts = [{ value: 0, label: labels.no_location }];
      locations.forEach(function (l) { opts.push({ value: l.id, label: l.name }); });
      return buildSelect(id, name, opts);
   }

   function ensureModal() {
      if ($('#plugin_subticket_modal').length) {
         return;
      }

      const modal = $(
         '<div class="modal fade" id="plugin_subticket_modal" tabindex="-1" aria-hidden="true" data-bs-scroll="true">' +
            '<div class="modal-dialog modal-xl modal-dialog-scrollable">' +
               '<div class="modal-content">' +

                  // ── Header ──
                  '<div class="modal-header sbt-header">' +
                     '<div class="sbt-header-icon"><i class="ti ti-subtask"></i></div>' +
                     '<h5 class="modal-title">' + htmlEscape(labels.subticket) + '</h5>' +
                     '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>' +
                  '</div>' +

                  '<div class="modal-body">' +
                     '<div id="plugin_subticket_alert" class="alert alert-danger d-none"></div>' +
                     '<form id="plugin_subticket_form">' +
                        '<input type="hidden" name="tickets_id" id="plugin_subticket_tickets_id">' +
                        '<input type="hidden" name="_glpi_csrf_token" id="plugin_subticket_csrf">' +

                        // ── Seção 1: Tipo de criação ──
                        '<div class="sbt-section">' +
                           '<div class="sbt-section-title"><i class="ti ti-layout-grid"></i>' + htmlEscape(labels.type_creation) + '</div>' +
                           '<div class="sbt-type-selector">' +
                              '<label class="sbt-type-card active" id="sbt-card-subticket">' +
                                 '<input type="radio" name="relation_type" value="subticket" class="d-none" checked>' +
                                 '<div class="sbt-type-icon"><i class="ti ti-subtask"></i></div>' +
                                 '<div>' +
                                    '<div class="sbt-type-name">' + htmlEscape(labels.child) + '</div>' +
                                    '<div class="sbt-type-desc">' + htmlEscape(labels.type_desc_subticket) + '</div>' +
                                 '</div>' +
                              '</label>' +
                              '<label class="sbt-type-card" id="sbt-card-related">' +
                                 '<input type="radio" name="relation_type" value="related" class="d-none">' +
                                 '<div class="sbt-type-icon"><i class="ti ti-link"></i></div>' +
                                 '<div>' +
                                    '<div class="sbt-type-name">' + htmlEscape(labels.related) + '</div>' +
                                    '<div class="sbt-type-desc">' + htmlEscape(labels.type_desc_related) + '</div>' +
                                 '</div>' +
                              '</label>' +
                           '</div>' +
                        '</div>' +

                        // ── Seção 2: Configurações ──
                        '<div class="sbt-section">' +
                           '<div class="sbt-section-title"><i class="ti ti-settings"></i>' + htmlEscape(labels.section_config) + '</div>' +
                           '<div class="sbt-options-grid">' +
                              '<label class="sbt-toggle-item">' +
                                 '<div class="sbt-toggle-label"><i class="ti ti-lock"></i><div><span>' + htmlEscape(labels.auto_close_label) + '</span><span class="sbt-toggle-sublabel" id="sbt-auto-close-sub"></span></div></div>' +
                                 '<div class="sbt-toggle"><input type="checkbox" name="auto_close" id="plugin_subticket_auto_close"><span class="sbt-toggle-slider"></span></div>' +
                              '</label>' +
                              '<label class="sbt-toggle-item">' +
                                 '<div class="sbt-toggle-label"><i class="ti ti-paperclip"></i><span>' + htmlEscape(labels.copy_docs_label) + '</span></div>' +
                                 '<div class="sbt-toggle"><input type="checkbox" name="copy_documents" id="plugin_subticket_copy_documents"><span class="sbt-toggle-slider"></span></div>' +
                              '</label>' +
                              '<label class="sbt-toggle-item d-none" id="plugin_subticket_close_parent_wrap">' +
                                 '<div class="sbt-toggle-label"><i class="ti ti-arrow-up"></i><div><span>' + htmlEscape(labels.auto_close_parent_label) + '</span><span class="sbt-toggle-sublabel" id="sbt-auto-close-parent-sub"></span></div></div>' +
                                 '<div class="sbt-toggle"><input type="checkbox" name="auto_close_parent" id="plugin_subticket_auto_close_parent"><span class="sbt-toggle-slider"></span></div>' +
                              '</label>' +
                              '<label class="sbt-toggle-item d-none" id="plugin_subticket_notify_parent_wrap">' +
                                 '<div class="sbt-toggle-label"><i class="ti ti-bell"></i><span>' + htmlEscape(labels.notify_parent_on_close_label) + '</span></div>' +
                                 '<div class="sbt-toggle"><input type="checkbox" name="notify_parent_on_close" id="plugin_subticket_notify_parent_on_close"><span class="sbt-toggle-slider"></span></div>' +
                              '</label>' +
                              '<label class="sbt-toggle-item d-none" id="plugin_subticket_mirror_followups_wrap">' +
                                 '<div class="sbt-toggle-label"><i class="ti ti-messages"></i><span>' + htmlEscape(labels.mirror_followups_label) + '</span></div>' +
                                 '<div class="sbt-toggle"><input type="checkbox" name="mirror_followups" id="plugin_subticket_mirror_followups"><span class="sbt-toggle-slider"></span></div>' +
                              '</label>' +
                           '</div>' +
                        '</div>' +

                        // ── Seção 3: Campos a copiar (subticket) ──
                        '<div class="sbt-section" id="plugin_subticket_copy_panel">' +
                           '<div class="sbt-section-title"><i class="ti ti-copy"></i>' + htmlEscape(labels.copy_panel_title) + '</div>' +
                           '<div class="sbt-badges-grid">' +
                              buildCopyBadge('name',             labels.field_name) +
                              buildCopyBadge('content',          labels.field_content) +
                              buildCopyBadge('requester',        labels.field_requester) +
                              buildCopyBadge('itilcategories_id',labels.field_category) +
                              buildCopyBadge('type',             labels.field_type) +
                              buildCopyBadge('locations_id',     labels.field_location) +
                              buildCopyBadge('requesttypes_id',  labels.field_origin) +
                           '</div>' +
                        '</div>' +

                        // ── Seção 4: Dados do novo chamado ──
                        '<div class="sbt-section">' +
                           '<div class="sbt-section-title"><i class="ti ti-forms"></i>' + htmlEscape(labels.section_fields) + '</div>' +
                           '<div class="row g-3">' +
                              '<div class="col-md-8">' +
                                 '<label class="sbt-label" for="plugin_subticket_name">' + htmlEscape(labels.lbl_title) + '</label>' +
                                 '<input class="form-control" type="text" name="name" id="plugin_subticket_name">' +
                              '</div>' +
                              '<div class="col-md-4">' +
                                 '<label class="sbt-label" for="plugin_subticket_requester_text">' + htmlEscape(labels.lbl_requester) + '<span class="sbt-required-mark d-none"> *</span></label>' +
                                 buildRequesterAutocomplete('plugin_subticket_requester_text', 'plugin_subticket_requester_id', 'requester_id') +
                              '</div>' +
                              '<div class="col-12">' +
                                 '<label class="sbt-label">' + htmlEscape(labels.lbl_description) + '</label>' +
                                 '<div class="form-control sbt-content-editor" id="plugin_subticket_content" contenteditable="true" spellcheck="false"></div>' +
                              '</div>' +
                              '<div class="col-md-5">' +
                                 '<label class="sbt-label">' + htmlEscape(labels.lbl_category) + '<span class="sbt-required-mark d-none"> *</span></label>' +
                                 buildCombo('plugin_subticket_category', 'itilcategories_id', labels.no_category) +
                              '</div>' +
                              '<div class="col-md-3">' +
                                 '<label class="sbt-label" for="plugin_subticket_type">' + htmlEscape(labels.lbl_type) + '<span class="sbt-required-type d-none"> *</span></label>' +
                                 buildTypeSelect('plugin_subticket_type', 'type') +
                              '</div>' +
                              '<div class="col-md-4">' +
                                 '<label class="sbt-label">' + htmlEscape(labels.lbl_origin) + '</label>' +
                                 buildCombo('plugin_subticket_origin', 'requesttypes_id', labels.no_origin) +
                              '</div>' +
                              '<div class="col-md-6">' +
                                 '<label class="sbt-label">' + htmlEscape(labels.lbl_location) + '</label>' +
                                 buildCombo('plugin_subticket_location', 'locations_id', labels.no_location) +
                              '</div>' +
                           '</div>' +
                        '</div>' +

                     '</form>' +
                  '</div>' +

                  // ── Footer ──
                  '<div class="modal-footer">' +
                     '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"><i class="ti ti-x me-1"></i>' + htmlEscape(labels.cancel) + '</button>' +
                     '<button type="button" class="sbt-submit-btn btn" id="plugin_subticket_submit"><i class="ti ti-device-floppy me-1"></i>' + htmlEscape(labels.create) + '</button>' +
                  '</div>' +

               '</div>' +
            '</div>' +
         '</div>'
      );

      $('body').append(modal);
      initRequesterAutocomplete();
      initCombo('plugin_subticket_category', [{id: 0, label: labels.no_category}].concat(categories.map(function (c) { return {id: c.id, label: c.name}; })), labels.no_category);
      initCombo('plugin_subticket_origin',   [{id: 0, label: labels.no_origin}].concat(requestTypes.map(function (r) { return {id: r.id, label: r.name}; })), labels.no_origin);
      initCombo('plugin_subticket_location', [{id: 0, label: labels.no_location}].concat(locations.map(function (l) { return {id: l.id, label: l.name}; })), labels.no_location);
      $('#plugin_subticket_submit').on('click', submitForm);
      $('input[name="relation_type"]').on('change', refreshMode);
      $('#plugin_subticket_form').on('change', '.plugin-subticket-copy-field', function () {
         $(this).closest('.sbt-badge').toggleClass('active', this.checked);
         if ($(this).val() === 'type') {
            // Nunca herdar tipo em silêncio: ao soltar a cópia o campo volta a ficar em
            // branco e o técnico é obrigado a escolher.
            $('#plugin_subticket_type').val(
               this.checked && sourceTicket ? (parseInt(sourceTicket.type, 10) || 0) : 0
            );
         }
         refreshCopiedFields();
      });
      $('#plugin_subticket_modal').on('hidden.bs.modal', function () {
         // GLPI hides .main-actions when any Bootstrap modal opens — restore it explicitly
         $('.main-actions').css('display', '').show().removeClass('d-none');
         $('body').removeClass('modal-open').css({ overflow: '', 'padding-right': '' });
         setTimeout(addButton, 150);
      });
   }

   function initRequesterAutocomplete() {
      const $text     = $('#plugin_subticket_requester_text');
      const $hidden   = $('#plugin_subticket_requester_id');
      const $dropdown = $('#plugin_subticket_requester_text_dropdown');
      let focusedIdx  = -1;
      let searchTimer = null;
      // Sequencia para descartar resposta que chega fora de ordem: sem isso, uma busca lenta
      // por "jo" pode sobrescrever o resultado de "joao" digitado depois.
      let searchSeq   = 0;

      // Linha de aviso (sem a classe sbt-autocomplete-item, para as setas nao a focarem).
      function renderMessage(text) {
         focusedIdx = -1;
         $dropdown.html('<div class="sbt-autocomplete-empty">' + htmlEscape(text) + '</div>');
         $dropdown.show();
         $text.addClass('open');
      }

      function renderDropdown(items, truncated) {
         focusedIdx = -1;
         if (!items.length) {
            renderMessage(labels.user_search_empty);
            return;
         }
         let html = items.map(function (u) {
            // O login volta como dica: agora so trafegam os usuarios que casaram o termo,
            // dentro do recorte de entidade — nao a instancia inteira.
            const loginHint = u.login ? ' <span class="sbt-ac-login">(' + htmlEscape(u.login) + ')</span>' : '';
            return '<div class="sbt-autocomplete-item" data-id="' + u.id + '" data-name="' + htmlEscape(u.name) + '">' + htmlEscape(u.name) + loginHint + '</div>';
         }).join('');
         if (truncated) {
            html += '<div class="sbt-autocomplete-empty">' + htmlEscape(labels.user_search_truncated) + '</div>';
         }
         $dropdown.html(html);
         $dropdown.show();
         $text.addClass('open');
      }

      function closeDropdown() {
         clearTimeout(searchTimer);
         // Invalida buscas em voo. Sem isto, uma resposta que chega depois de o usuário ter
         // escolhido alguém (ou saído do campo) REABRE o dropdown por cima da seleção.
         searchSeq++;
         $dropdown.hide().empty();
         $text.removeClass('open');
         focusedIdx = -1;
      }

      function pickUser(id, name) {
         $hidden.val(id || 0);
         $text.val(name || '');
         closeDropdown();
      }

      $text.on('input', function () {
         const q = this.value.trim();

         // Digitar invalida a selecao anterior. Sem isto, escolher "Joao" e depois editar o
         // texto para "Maria" mantinha o id do Joao no hidden: o chamado saia com um
         // requerente diferente do que estava escrito na tela.
         $hidden.val(0);

         clearTimeout(searchTimer);

         if (!q.length) {
            // Campo limpo: fecha e não deixa nenhuma busca em voo respingar depois.
            closeDropdown();
            return;
         }

         const seq = ++searchSeq;

         if (q.length < userSearchMinChars) {
            renderMessage(labels.user_search_hint);
            return;
         }

         renderMessage(labels.user_search_loading);

         searchTimer = setTimeout(function () {
            fetchJSON(pluginUrl + '/ajax/ticket.php?action=search_users&q=' + encodeURIComponent(q))
               .then(function (res) {
                  if (seq !== searchSeq) { return; }   // resposta velha, ignorar
                  if (!res || res.success !== true) {
                     renderMessage((res && res.message) ? res.message : labels.user_search_error);
                     return;
                  }
                  renderDropdown(res.users || [], !!res.truncated);
               })
               .catch(function () {
                  if (seq !== searchSeq) { return; }
                  // Falha de busca nao trava o modal: o usuario pode limpar o campo e criar
                  // um chamado relacionado (que copia o requerente da origem) ou tentar de novo.
                  renderMessage(labels.user_search_error);
               });
         }, userSearchDebounceMs);
      });

      $text.on('keydown', function (e) {
         const $items = $dropdown.find('.sbt-autocomplete-item');
         if (!$items.length) return;
         if (e.key === 'ArrowDown') {
            e.preventDefault();
            focusedIdx = Math.min(focusedIdx + 1, $items.length - 1);
            $items.removeClass('sbt-focused').eq(focusedIdx).addClass('sbt-focused');
         } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            focusedIdx = Math.max(focusedIdx - 1, 0);
            $items.removeClass('sbt-focused').eq(focusedIdx).addClass('sbt-focused');
         } else if (e.key === 'Enter' && focusedIdx >= 0) {
            e.preventDefault();
            const $item = $items.eq(focusedIdx);
            pickUser($item.data('id'), $item.data('name'));
         } else if (e.key === 'Escape') {
            closeDropdown();
         }
      });

      $text.on('blur', function () { setTimeout(closeDropdown, 150); });

      $dropdown.on('mousedown', '.sbt-autocomplete-item', function (e) {
         e.preventDefault();
         pickUser($(this).data('id'), $(this).data('name'));
      });
   }

   function buildCopyBadge(field, label) {
      return '<label class="sbt-badge" data-field="' + field + '">' +
         '<input class="plugin-subticket-copy-field" type="checkbox" data-copy-field="' + field + '" value="' + field + '" style="display:none">' +
         '<i class="ti ti-check sbt-badge-check"></i>' +
         htmlEscape(label) +
      '</label>';
   }

   function openModal() {
      ensureModal();
      const ticketId = getTicketId();
      $('#plugin_subticket_tickets_id').val(ticketId);
      $('#sbt-auto-close-sub').text('Quando o chamado de origem #' + ticketId + ' for solucionado, este chamado também será solucionado.');
      $('#sbt-auto-close-parent-sub').text('Ao solucionar este chamado, o chamado #' + ticketId + ' também será solucionado.');
      clearAlert();

      const url = pluginUrl + '/ajax/ticket.php?action=source&tickets_id=' + encodeURIComponent(ticketId);
      fetchJSON(url)
         .then(function (response) {
            if (!response || response.success !== true) {
               showAlert((response && response.message) ? response.message : labels.error);
               bootstrap.Modal.getOrCreateInstance(document.getElementById('plugin_subticket_modal')).show();
               return;
            }
            fillFromSource(response.ticket);
            refreshMode();
            bootstrap.Modal.getOrCreateInstance(document.getElementById('plugin_subticket_modal')).show();
         })
         .catch(function () {
            showAlert(labels.error);
            bootstrap.Modal.getOrCreateInstance(document.getElementById('plugin_subticket_modal')).show();
         });
   }

   let sourceTicket = null;

   function fillFromSource(ticket) {
      sourceTicket = ticket;
      $('#plugin_subticket_name').val(ticket.name || '');
      // innerHTML e proposital: #plugin_subticket_content e um contenteditable que precisa
      // renderizar a formatacao do chamado de origem -- escapar mostraria as tags ao usuario.
      // A garantia vem do SERVIDOR: getSourcePayload() passa o campo por
      // RichText::getSafeHtml(), o mesmo sanitizador que o core aplica no timeline. Se algum
      // dia outra origem alimentar este elemento, ela tem de oferecer a mesma garantia.
      document.getElementById('plugin_subticket_content').innerHTML = ticket.content || '';

      // Tipo: NAO herda do chamado de origem. Quem define o valor e refreshMode(), que
      // deixa em branco quando o campo esta editavel. Ver buildTypeSelect().
      $('#plugin_subticket_type').val(0);

      // Categoria, Origem, Localização (combo)
      function setCombo(selectId, rawId, items, placeholder) {
         const id   = parseInt(rawId, 10) || 0;
         const item = items.find(function (x) { return x.id === id; });
         $('#' + selectId).val(id);
         $('#' + selectId + '_display .sbt-combo-text')
            .toggleClass('sbt-placeholder', !id || !item)
            .text(id && item ? item.name : placeholder);
      }
      setCombo('plugin_subticket_category', ticket.itilcategories_id, categories,   labels.no_category);
      setCombo('plugin_subticket_origin',   ticket.requesttypes_id,  requestTypes,  labels.no_origin);
      setCombo('plugin_subticket_location', ticket.locations_id,     locations,     labels.no_location);

      // Requerente — pré-seleciona o primeiro requerente do ticket de origem.
      // O nome já vem formatado em ticket.requesters (getTicketUsers usa formatUserName),
      // então não é preciso procurar numa lista local — que não existe mais.
      const firstReq = ticket.requesters && ticket.requesters.length > 0 ? ticket.requesters[0] : null;
      if (firstReq) {
         $('#plugin_subticket_requester_id').val(firstReq.id);
         $('#plugin_subticket_requester_text').val(firstReq.name || '');
      } else {
         $('#plugin_subticket_requester_id').val(0);
         $('#plugin_subticket_requester_text').val('');
      }
   }

   function refreshMode() {
      const mode = $('input[name="relation_type"]:checked').val();
      const isRelated = mode === 'related';
      const isSubticket = mode === 'subticket';
      $('#plugin_subticket_auto_close').prop('checked', isRelated ? defaultAutoCloseRelated : defaultAutoCloseSubticket);
      $('#plugin_subticket_copy_documents').prop('checked', copyDocumentsByDefault);
      // Related: só "Tipo" marcado; Subticket: nenhum marcado
      $('.plugin-subticket-copy-field').prop('checked', false);
      if (isRelated) {
         $('.plugin-subticket-copy-field[value="type"]').prop('checked', true);
      }
      $('.plugin-subticket-copy-field').each(function () {
         $(this).closest('.sbt-badge').toggleClass('active', this.checked);
      });
      if (isSubticket) {
         // Requerente = usuário logado; categoria e tipo em branco (obrigatórios)
         $('#plugin_subticket_type').val(0);
         $('#plugin_subticket_requester_id').val(currentUserId);
         $('#plugin_subticket_requester_text').val(currentUserName || '');
         $('#plugin_subticket_category').val(0);
         $('#plugin_subticket_category_display .sbt-combo-text')
            .addClass('sbt-placeholder').text(labels.no_category);
      } else if (isRelated && sourceTicket) {
         // Restaura requerente, categoria e tipo do ticket de origem. O tipo so aparece
         // aqui porque neste modo ele vem marcado como copiado e o campo fica desabilitado:
         // o técnico vê o que será copiado em vez de um campo vazio e inerte.
         $('#plugin_subticket_type').val(parseInt(sourceTicket.type, 10) || 0);
         var firstReq = sourceTicket.requesters && sourceTicket.requesters.length > 0
            ? sourceTicket.requesters[0] : null;
         $('#plugin_subticket_requester_id').val(firstReq ? firstReq.id : 0);
         $('#plugin_subticket_requester_text').val(firstReq ? (firstReq.name || '') : '');
         var catId   = parseInt(sourceTicket.itilcategories_id, 10) || 0;
         var catItem = categories.find(function (c) { return c.id === catId; });
         $('#plugin_subticket_category').val(catId);
         $('#plugin_subticket_category_display .sbt-combo-text')
            .toggleClass('sbt-placeholder', !catId || !catItem)
            .text(catId && catItem ? catItem.name : labels.no_category);
      }
      // Required markers
      $('.sbt-required-mark').toggleClass('d-none', !isSubticket);
      $('#sbt-card-related').toggleClass('active', isRelated);
      $('#sbt-card-subticket').toggleClass('active', isSubticket);
      $('#plugin_subticket_close_parent_wrap').removeClass('d-none');
      $('#plugin_subticket_notify_parent_wrap').removeClass('d-none');
      $('#plugin_subticket_mirror_followups_wrap').removeClass('d-none');
      $('#plugin_subticket_auto_close_parent').prop('checked', isSubticket ? defaultAutoCloseParent : false);
      $('#plugin_subticket_notify_parent_on_close').prop('checked', isSubticket ? defaultNotifyParentOnClose : false);
      $('#plugin_subticket_mirror_followups').prop('checked', isSubticket ? defaultMirrorFollowups : false);
      refreshCopiedFields();
   }

   function refreshCopiedFields() {
      const copied = {};
      $('.plugin-subticket-copy-field:checked').each(function () {
         copied[$(this).data('copy-field')] = true;
      });

      setReadOnly('#plugin_subticket_name', !!copied.name);
      const contentLocked = !!copied.content;
      $('#plugin_subticket_content')
         .attr('contenteditable', contentLocked ? 'false' : 'true')
         .toggleClass('bg-light', contentLocked);
      setReadOnly('#plugin_subticket_requester_text', !!copied.requester);
      setSelectDisabled('#plugin_subticket_type',     !!copied.type);
      // O asterisco do tipo nao segue o modo (como os outros), e sim a copia: o campo e
      // obrigatorio sempre que estiver editavel, inclusive em chamado relacionado.
      $('.sbt-required-type').toggleClass('d-none', !!copied.type);
      setComboDisabled('plugin_subticket_category',   !!copied.itilcategories_id);
      setComboDisabled('plugin_subticket_location',   !!copied.locations_id);
      setComboDisabled('plugin_subticket_origin',     !!copied.requesttypes_id);
   }

   function setReadOnly(selector, readonly) {
      $(selector).prop('readonly', readonly).toggleClass('bg-light', readonly);
   }

   function setSelectDisabled(selector, disabled) {
      $(selector).prop('disabled', disabled).toggleClass('bg-light', disabled);
   }

   function setComboDisabled(selectId, disabled) {
      $('#' + selectId + '_display').toggleClass('bg-light', disabled).prop('tabIndex', disabled ? -1 : 0);
   }

   function collectFormData() {
      $('#plugin_subticket_csrf').val(getCsrfToken());

      // Re-habilita selects desativados para que serializeArray os inclua
      const $disabled = $('#plugin_subticket_form select:disabled');
      $disabled.prop('disabled', false);
      const data = $('#plugin_subticket_form').serializeArray();
      $disabled.prop('disabled', true);

      const copyFields = [];
      $('.plugin-subticket-copy-field:checked').each(function () {
         copyFields.push($(this).val());
      });
      data.push({ name: 'content',         value: document.getElementById('plugin_subticket_content').innerHTML });
      data.push({ name: 'action',          value: 'create' });
      data.push({ name: 'copy_fields',     value: JSON.stringify(copyFields) });
      data.push({ name: 'copy_requesters', value: copyFields.includes('requester') ? '1' : '0' });
      if ($('#plugin_subticket_auto_close').is(':checked')) {
         data.push({ name: 'auto_close', value: '1' });
      }
      if ($('#plugin_subticket_copy_documents').is(':checked')) {
         data.push({ name: 'copy_documents', value: '1' });
      }
      if ($('#plugin_subticket_auto_close_parent').is(':checked')) {
         data.push({ name: 'auto_close_parent', value: '1' });
      }
      if ($('#plugin_subticket_notify_parent_on_close').is(':checked')) {
         data.push({ name: 'notify_parent_on_close', value: '1' });
      }
      if ($('#plugin_subticket_mirror_followups').is(':checked')) {
         data.push({ name: 'mirror_followups', value: '1' });
      }
      return $.param(data);
   }

   function submitForm() {
      clearAlert();
      const isSubticket = $('input[name="relation_type"]:checked').val() === 'subticket';
      if (isSubticket) {
         if (!(parseInt($('#plugin_subticket_requester_id').val(), 10) > 0)) {
            showAlert(labels.requester_required);
            return;
         }
         if (!(parseInt($('#plugin_subticket_category').val(), 10) > 0)) {
            showAlert(labels.category_required);
            return;
         }
      }
      // Tipo vale para os dois modos: em chamado relacionado com a cópia ligada o campo
      // carrega o tipo da origem, entao esta checagem passa sem atrapalhar.
      if (!(parseInt($('#plugin_subticket_type').val(), 10) > 0)) {
         showAlert(labels.type_required);
         return;
      }
      const button = $('#plugin_subticket_submit');
      button.prop('disabled', true);

      fetchJSON(pluginUrl + '/ajax/ticket.php', {
         method: 'POST',
         headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
         body: collectFormData(),
      })
         .then(function (response) {
            if (!response || response.success !== true) {
               showAlert((response && response.message) ? response.message : labels.error);
               button.prop('disabled', false);
               return;
            }
            window.location.href = CFG_GLPI.root_doc + '/front/ticket.form.php?id=' + response.newID;
         })
         .catch(function () {
            showAlert(labels.error);
            button.prop('disabled', false);
         });
   }

   function showAlert(message) {
      $('#plugin_subticket_alert').removeClass('d-none').text(message);
   }

   function clearAlert() {
      $('#plugin_subticket_alert').addClass('d-none').text('');
   }

   // ---------- Parent ticket close validation ----------
   let parentIssues   = null;
   let pendingForm    = null;
   let sbtBypassCheck = false;

   function sbtFormShouldIntercept(form) {
      // Intercept if status = 5 (SOLVED) or 6 (CLOSED)
      const statusEl = form.querySelector('[name="status"]');
      if (statusEl) {
         const v = parseInt(statusEl.value, 10);
         if (v === 5 || v === 6) return true;
      }
      // Also intercept if it looks like an ITILSolution form (GLPI sets status automatically)
      if (form.querySelector('[name="itemtype"][value="ITILSolution"]')) return true;
      if (form.querySelector('[name="_itilsolution"]')) return true;
      if (form.querySelector('[name="solutiontypes_id"]')) return true;
      return false;
   }

   // Capture-phase listener: runs BEFORE GLPI's own submit handlers (which call stopPropagation)
   function sbtCaptureSubmitHandler(e) {
      if (sbtBypassCheck || !parentIssues) return;
      const form = e.target;
      if (!(form instanceof HTMLFormElement)) return;
      if (!sbtFormShouldIntercept(form)) return;

      e.preventDefault();
      e.stopImmediatePropagation();
      pendingForm = form;

      const listHtml = (parentIssues.issues || []).map(function (i) {
         return '<li>' + htmlEscape(i) + '</li>';
      }).join('');
      document.getElementById('sbt_parent_warn_list').innerHTML = listHtml;
      bootstrap.Modal.getOrCreateInstance(document.getElementById('sbt_parent_warn_modal')).show();
   }

   function checkParentIssues() {
      const ticketId = getTicketId();
      if (!ticketId) return;
      fetchJSON(pluginUrl + '/ajax/ticket.php?action=check_parent_issues&tickets_id=' + encodeURIComponent(ticketId))
         .then(function (res) {
            if (res && res.has_issues) {
               parentIssues = res;
               ensureParentWarnModal();
            }
         })
         .catch(function () {});
   }

   function ensureParentWarnModal() {
      if ($('#sbt_parent_warn_modal').length) return;

      const modal = $(
         '<div class="modal fade" id="sbt_parent_warn_modal" tabindex="-1" aria-hidden="true">' +
            '<div class="modal-dialog modal-dialog-centered">' +
               '<div class="modal-content">' +
                  '<div class="modal-header bg-warning-subtle">' +
                     '<h5 class="modal-title"><i class="ti ti-alert-triangle me-2 text-warning"></i>' + htmlEscape(labels.parent_warn_title) + '</h5>' +
                     '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>' +
                  '</div>' +
                  '<div class="modal-body">' +
                     '<p class="mb-1">' + htmlEscape(labels.parent_warn_body) + '</p>' +
                     '<ul id="sbt_parent_warn_list" class="text-start mt-2 mb-0"></ul>' +
                  '</div>' +
                  '<div class="modal-footer">' +
                     '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"><i class="ti ti-x me-1"></i>' + htmlEscape(labels.cancel) + '</button>' +
                     '<button type="button" class="btn btn-warning" id="sbt_parent_warn_proceed"><i class="ti ti-check me-1"></i>' + htmlEscape(labels.parent_warn_proceed) + '</button>' +
                  '</div>' +
               '</div>' +
            '</div>' +
         '</div>'
      );

      $('body').append(modal);

      $('#sbt_parent_warn_proceed').on('click', function () {
         bootstrap.Modal.getInstance(document.getElementById('sbt_parent_warn_modal')).hide();
         if (pendingForm) {
            var form = pendingForm;
            pendingForm = null;
            // Arma a flag de bypass na sessão PHP antes de reenviar o formulário.
            // POST (não GET) para que o CheckCsrfListener do core valide o token: em GET
            // esta ação podia ser disparada por um <img src="..."> na descrição de um
            // chamado, armando o bypass na sessão de quem apenas abrisse o chamado.
            // fetchJSON já injeta X-Requested-With e X-Glpi-Csrf-Token.
            //
            // O token vai TAMBÉM no corpo, e não só no header, porque o CheckCsrfListener
            // escolhe onde procurar com base no X-Requested-With:
            //   com o header  -> lê HTTP_X_GLPI_CSRF_TOKEN (preserve_token: true)
            //   sem o header  -> lê o corpo do POST (preserve_token: false)
            // Um WAF que normalize/remova o X-Requested-With jogaria a requisição no segundo
            // ramo; sem token no corpo ela seria negada com 403 e o botão "Solucionar mesmo
            // assim" simplesmente pararia de funcionar em produção. O cliente tem um F5 na
            // frente que já interferiu neste plugin uma vez. É falha fechada (não abre nada),
            // mas quebra fluxo — e o case 'create' já mandava o token no corpo pelo campo
            // oculto do formulário, então isto só uniformiza.
            // Custo do ramo de fallback: o token é consumido (preserve_token: false). Aqui é
            // irrelevante, porque logo em seguida o formulário é enviado e a página navega.
            var bypassBody = 'action=set_bypass_waiting'
               + '&tickets_id=' + encodeURIComponent(getTicketId())
               + '&_glpi_csrf_token=' + encodeURIComponent(getCsrfToken());
            fetchJSON(pluginUrl + '/ajax/ticket.php', {
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
               body: bypassBody,
            })
               // Falha ao armar não bloqueia o envio: o chamado é solucionado normalmente e
               // o pai apenas NÃO é fechado automaticamente (avisos das travas continuam
               // valendo). Falha fechada do lado da automação, que é o lado perigoso.
               .catch(function () {})
               .then(function () {
                  sbtBypassCheck = true;
                  if (form.requestSubmit) {
                     form.requestSubmit();
                  } else {
                     form.submit();
                  }
               });
         }
      });

      $('#sbt_parent_warn_modal').on('hidden.bs.modal', function () {
         $('.main-actions').css('display', '').show().removeClass('d-none');
         $('body').removeClass('modal-open').css({ overflow: '', 'padding-right': '' });
      });

      // Register capture-phase listener — fires BEFORE GLPI's bubble-phase stopPropagation
      document.addEventListener('submit', sbtCaptureSubmitHandler, true);
   }
   // ---------- End parent ticket close validation ----------

   $(document).on('glpi.tab.loaded', addButton);
   $(document).ready(function () {
      setTimeout(addButton, 250);
      setTimeout(addButton, 1000);
      setTimeout(checkParentIssues, 500);
   });
})();
