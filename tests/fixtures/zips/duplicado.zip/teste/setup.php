<?php evil();
