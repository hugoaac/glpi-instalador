<?php
const PLUGIN_TESTE_VERSION = '1.0.0';
